# Gold Dataset 100 câu về luật lao động (bản ứng viên v0.1)

**Không phải bộ Gold đã được chuyên gia pháp lý phê duyệt.** Đây là bộ nhãn ứng viên để nhóm rà soát, xây phép đo và thử nghiệm.

## Phạm vi
- 100 câu hỏi, 7 nhóm (14/14/14/14/14/15/15).
- 85 ANSWERABLE, 12 NEED_MORE_FACTS, 3 INSUFFICIENT_EVIDENCE (các câu liên quan văn bản tương lai).
- Mốc chuẩn của các câu thông thường: 2026-10-23. Ba câu tương lai có `applicable_date` khác, phải hiểu theo điều kiện **tại mốc chốt dữ liệu 2026-10-23 chưa có căn cứ xác minh**.
- Căn cứ chính: Bộ luật Lao động, văn bản hợp nhất 18/VBHN-VPQH ngày 12/02/2026. URL gốc: https://congbao.chinhphu.vn/van-ban/van-ban-hop-nhat-so-18-vbhn-vpqh-468971.htm
- Mapping ID sang corpus của người dùng: `source_document_id=doc_d98ede4425ed3133`.

## Tệp
- `labor_gold_100.jsonl`: toàn bộ dữ liệu dạng JSON, `gold_evidence_ids` là array.
- `labor_gold_100.csv`: nội dung thuận tiện nhập tool đánh giá; các list là JSON string.
- `labor_gold_100.xlsx`: bảng dễ kiểm tra, sửa nhãn, lọc theo nhóm.
- `evidence_catalog.jsonl`: văn bản bằng chứng và ID thật trong chỉ mục OFFLINE.
- `validation_report.json`: kết quả kiểm thử định dạng, mapping và trạng thái.

## Các trường bắt buộc
`question`, `gold_evidence_ids`, `gold_answer`, `applicable_date`, `expected_status`.
Giá trị của `expected_status`: ANSWERABLE / NEED_MORE_FACTS / INSUFFICIENT_EVIDENCE.

## Phân biệt kiểm tra
1. **Đã kiểm tra bằng máy**: 100 câu duy nhất, id hợp lệ, ID chứng cứ đều tồn tại trong artifact của corpus hiện có, số nhóm khớp, source_url có thật trong metadata và xác nhận trên Công báo.
2. **Đối chiếu căn cứ**: các câu được soạn từ điều khoản trong artifact và tự động map ID.
3. **Chưa hoàn thành**: chuyên gia pháp luật chưa ký duyệt mức độ phù hợp của căn cứ với từng câu, logic trả lời và tình trạng hiệu lực ở cấp điều/khoản/điểm chưa được xác nhận độc lập. Trong corpus `provision_temporal_verified=false`.

## Khuyến nghị thí nghiệm
- Retrieval BM25/Dense/Hybrid/Hybrid+Graph: dùng `gold_evidence_ids` làm qrels, ghi rõ phiên bản corpus. Chấm mức Điều và mức Khoản/Điểm riêng để tránh phạt hệ thống truy xuất Điều chứa đúng Khoản.
- QA/ablation: dùng `gold_answer`, `expected_status` và đánh giá do người có chuyên môn rà soát; không chấm exact-match máy móc.
- Câu NEED_MORE_FACTS: chấm chất lượng yêu cầu làm rõ, không tự đánh giá là sai do chưa kết luận.
- Câu INSUFFICIENT_EVIDENCE: câu hỏi về tương lai và dữ liệu đóng băng; chúng **không phải** Gold Evidence thật cho văn bản tương lai, chỉ có điều luật khung liên quan để giải thích giới hạn.
- Không dùng cả 100 câu để vừa chỉnh prompt vừa báo kết quả; tách dev/test trước khi tuning.
- Nếu dùng Zalo/VLSP, chấm độc lập trên corpus/nhãn của từng bộ, không trộn ID Gold của 18/VBHN vào qrels của họ.
