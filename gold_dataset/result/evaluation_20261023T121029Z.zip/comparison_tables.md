# Bảng đánh giá Pháp Điển AI

> Bốn phép đo có phạm vi và nhãn khác nhau. Không gộp thành một “độ chính xác chung”.
> AI-judge là điểm mô hình chấm, không phải chứng nhận pháp lý. N/A nghĩa là chưa đo/không áp dụng.

| Nhóm | Trạng thái thực thi |
|---|---|
| retrieval | COMPLETE |
| ablation | ERROR |
| zalo | ERROR |
| vlsp | ERROR |

## 1 Labour retrieval

| Cấu hình | Nhãn | group_recall_at_k | mrr_at_k | group_ndcg_at_k | mean_ms | successful_attempts | errors |
|---|---|---:|---:|---:|---:|---:|---:|
| bm25 | PROVISIONAL_DRAFT_GOLD | 0.8176 | 0.5670 | 0.6169 | 4.6973 | 255 | 0 |
| dense | PROVISIONAL_DRAFT_GOLD | 0.9294 | 0.6182 | 0.6926 | 54.7313 | 255 | 0 |
| hybrid | PROVISIONAL_DRAFT_GOLD | 0.9412 | 0.6653 | 0.7272 | 61.1263 | 255 | 0 |
| hybrid_graph | PROVISIONAL_DRAFT_GOLD | 0.5941 | 0.1161 | 0.2219 | 330.7913 | 255 | 0 |

## 2 Ablation

| Cấu hình | Nhãn | ai_correctness | ai_completeness | ai_evidence_support | ai_judged | draft_disposition_match_rate | gold_citation_group_recall | content_answers | mean_ms | errors |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| full | DRAFT | 0.4398 | 0.4306 | 0.4031 | 98 | 0.0303 | 0.2917 | 40 | 61688.6838 | 1 |
| without_graph | DRAFT | 0.4071 | 0.4143 | 0.4107 | 28 | 0.0202 | 0.2750 | 13 | 40470.8421 | 57 |
| without_reranker | DRAFT | N/A | N/A | N/A | 0 | 0.0202 | 0.0909 | 1 | 3850.0758 | 86 |
| without_auditor | DRAFT | 0.2000 | 0.2000 | 0 | 1 | 0.0303 | 0.0000 | 0 | 685.2213 | 53 |
| without_review | DRAFT | 1 | 1 | 1 | 1 | 0.0202 | 0.5000 | 31 | 6829.9446 | 53 |

## 3 Zalo retrieval

| Cấu hình | Nhãn | recall_at_k | precision_at_k | mrr_at_k | ndcg_at_k | elapsed_ms | attempts |
|---|---|---:|---:|---:|---:|---:|---:|
| Chưa có kết quả | NOT_EVALUATED | N/A | N/A | N/A | N/A | N/A | N/A |

## 4 VLSP adapted QA

| Cấu hình | Nhãn | ai_correctness | ai_completeness | ai_judged | content_answers | mean_ms | errors |
|---|---|---:|---:|---:|---:|---:|---:|
| Chưa có kết quả | NOT_EVALUATED | N/A | N/A | N/A | N/A | N/A | N/A |

Lưu ý khi đưa vào báo cáo:
- Gold candidate 100 vẫn là DRAFT. Khớp trạng thái chỉ là nhãn tham khảo; không chứng minh câu trả lời đúng luật.
- Xem gold_import_validation.json và gold_selection.json: 85 câu có đáp án để đo truy xuất, 100 câu để đo QA khi không giới hạn.
- DRAFT/seed sáu câu chỉ kiểm tra công cụ, không đại diện chất lượng luật lao động.
- Labour Graph là mở rộng cố định; ablation là pipeline đầy đủ có tắt từng thành phần trong tiến trình đo riêng.
- Zalo chạy trên corpus riêng; không gộp điểm với corpus lao động.
- VLSP là QA thích nghi, lọc từ khóa lao động và giả định ngày; không phải giao thức/bảng xếp hạng chính thức.
- Đọc số lượt chấm AI, lỗi, câu có nội dung, câu từ chối và các trace trước khi diễn giải điểm.
- Độ trễ QA không gồm thời gian AI judge; không phải thời gian frontend.
- OFFLINE mới có thể làm Gold mất hiệu lực: migration luôn hạ về DRAFT, cần rà soát lại.