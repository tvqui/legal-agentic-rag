# So sánh truy xuất

Trạng thái nhãn: PROVISIONAL_DRAFT_GOLD
Phạm vi: chỉ truy xuất; không chấm độ đúng pháp lý của câu trả lời.

| Phương pháp | Lượt OK/tổng | Recall nhóm@k | MRR@k | nDCG nhóm@k | Trung bình ms | p95 ms |
|---|---:|---:|---:|---:|---:|---:|
| bm25 | 255/255 | 0.8176 | 0.5670 | 0.6169 | 4.6973 | 5.8000 |
| dense | 255/255 | 0.9294 | 0.6182 | 0.6926 | 54.7313 | 59.9150 |
| hybrid | 255/255 | 0.9412 | 0.6653 | 0.7272 | 61.1263 | 66.8640 |
| hybrid_graph | 255/255 | 0.5941 | 0.1161 | 0.2219 | 330.7913 | 928.3830 |

Lỗi được ghi riêng trong responses.jsonl; không được che bằng trung bình các lượt thành công.
Kết quả seed DRAFT chỉ là smoke test; không dùng chọn phương pháp thắng hoặc công bố chính xác.