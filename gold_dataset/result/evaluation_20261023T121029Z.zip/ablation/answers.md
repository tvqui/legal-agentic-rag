# Câu hỏi, câu trả lời và thời gian đo

> Nhãn DRAFT; tham khảo JSONL và trace để thẩm định nguồn.

## HD001 — full — lần 1

Tôi ký hợp đồng làm việc 20 ngày cho công việc thông thường bằng lời nói, có được không?

Thời gian: 239495.44 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Hợp đồng lao động cho công việc thông thường phải được giao kết bằng văn bản theo quy định tại Điều 14, khoản 1 của Văn bản hợp nhất Bộ luật Lao động 18/VBHN-VPQH. [prov_89771ca82d7c7b0f]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có thể giao kết bằng lời nói với hợp đồng dưới một tháng, nếu không thuộc các trường hợp luật bắt buộc lập bằng văn bản.

## HD002 — full — lần 1

Công ty ký hợp đồng lao động 6 tháng với tôi nhưng chỉ thỏa thuận miệng. Như vậy có đúng hình thức không?

Thời gian: 50365.499 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng 6 tháng phải được giao kết bằng văn bản, có thể bằng thông điệp dữ liệu điện tử đủ điều kiện pháp luật.

## HD003 — full — lần 1

Hợp đồng lao động ký qua phương tiện điện tử dưới dạng thông điệp dữ liệu có giá trị như hợp đồng giấy không?

Thời gian: 135507.032 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng lao động điện tử bằng thông điệp dữ liệu theo pháp luật giao dịch điện tử có giá trị như hợp đồng bằng văn bản.

## HD004 — full — lần 1

Khi ký hợp đồng lao động bằng văn bản, người lao động có phải giữ một bản không?

Thời gian: 240130.459 ms. Trạng thái: ERROR.

RequestStopped

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng bằng văn bản được làm thành hai bản, mỗi bên giữ một bản.

## HD005 — full — lần 1

Công ty gọi giấy tờ của tôi là hợp đồng cộng tác viên nhưng tôi được trả lương và chịu quản lý giờ làm. Có thể là hợp đồng lao động không?

Thời gian: 73394.001 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 1 Điều 13: dù thỏa thuận mang tên gọi khác, nếu nội dung thể hiện việc làm có trả công, tiền lương và sự quản lý, điều hành, giám sát của một bên thì được coi là hợp đồng lao động. Tên gọi “thực tập sinh” hoặc “hợp đồng dịch vụ” tự nó chưa đủ để kết luận; cần đối chiếu đủ các dấu hiệu này với thực tế. [prov_c6b64b7574aec2bb]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có thể được coi là hợp đồng lao động dù tên gọi khác, nếu có việc làm có trả công và chịu sự quản lý, điều hành, giám sát của một bên.

## HD006 — full — lần 1

Doanh nghiệp muốn ký hợp đồng lao động xác định thời hạn 48 tháng với nhân viên thông thường. Có hợp lệ về thời hạn không?

Thời gian: 156926.675 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng lao động xác định thời hạn theo quy định chung có thời hạn tối đa 36 tháng.

## HD007 — full — lần 1

Hợp đồng 24 tháng đã hết hạn, tôi tiếp tục làm việc 40 ngày và hai bên không ký hợp đồng mới. Hợp đồng trở thành loại nào?

Thời gian: 91295.112 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Hợp đồng xác định thời hạn đã giao kết chuyển thành hợp đồng lao động không xác định thời hạn sau khi quá 30 ngày mà hai bên không ký mới.

## HD008 — full — lần 1

Hợp đồng có thời hạn vừa hết 10 ngày, tôi vẫn làm mà chưa ký mới. Quyền lợi được áp dụng theo hợp đồng cũ không?

Thời gian: 129956.521 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Trong thời hạn 30 ngày từ khi hợp đồng hết hạn, nếu chưa ký mới thì quyền, nghĩa vụ và lợi ích vẫn theo hợp đồng đã giao kết.

## HD009 — full — lần 1

Tôi đã ký hai hợp đồng xác định thời hạn liên tiếp ở công ty tư nhân thông thường. Nếu tiếp tục làm việc, có thể ký lần thứ ba cùng loại không?

Thời gian: 122767.611 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Thông thường không. Sau lần ký thêm một hợp đồng xác định thời hạn, nếu tiếp tục làm việc thì phải ký hợp đồng không xác định thời hạn, trừ trường hợp luật quy định ngoại lệ.

## HD010 — full — lần 1

Tôi có thể cùng lúc ký hợp đồng lao động với hai công ty khác nhau không?

Thời gian: 73670.918 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có thể giao kết nhiều hợp đồng với nhiều người sử dụng lao động nếu bảo đảm thực hiện đầy đủ nội dung đã ký.

## HD011 — full — lần 1

Công ty giữ bản chính bằng đại học của tôi để bảo đảm tôi không nghỉ việc. Có được không?

Thời gian: 14203.488 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 1 Điều 17: Điều 17. Hành vi người sử dụng lao động không được làm khi giao kết, thực hiện hợp đồng lao động 1. Giữ bản chính giấy tờ tùy thân, văn bằng, chứng chỉ của người lao động. [prov_e401e65d2e15b2ac]
- Việc người sử dụng lao động giữ bản chính giấy tờ tùy thân, văn bằng, chứng chỉ để ràng buộc người lao động là hành vi bị cấm tại khoản 1 Điều 17; cần phân biệt với việc xuất trình để đối chiếu rồi trả lại. [prov_e401e65d2e15b2ac]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được giữ bản chính giấy tờ tùy thân, văn bằng hoặc chứng chỉ của người lao động.

## HD012 — full — lần 1

Công ty yêu cầu tôi đặt cọc hai triệu đồng để nhận việc theo hợp đồng lao động. Có được không?

Thời gian: 2400.52 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 2 Điều 17: Điều 17. Hành vi người sử dụng lao động không được làm khi giao kết, thực hiện hợp đồng lao động 2. Yêu cầu người lao động phải thực hiện biện pháp bảo đảm bằng tiền hoặc tài sản khác cho việc thực hiện hợp đồng lao động. [prov_b44555d589adb6e2]
- Nếu khoản tiền hoặc tài sản thực chất là biện pháp bảo đảm cho việc thực hiện hợp đồng lao động thì thuộc hành vi bị cấm tại khoản 2 Điều 17. Đổi tên thành “phí bảo đảm uy tín” không làm thay đổi bản chất; cần kiểm tra mục đích và điều kiện nộp, hoàn trả thực tế. [prov_b44555d589adb6e2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được yêu cầu bảo đảm bằng tiền hoặc tài sản khác để thực hiện hợp đồng lao động.

## HD013 — full — lần 1

Công ty muốn gia hạn thời hạn hợp đồng bằng phụ lục thay vì ký hợp đồng lao động mới. Có được không?

Thời gian: 75476.756 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Phụ lục có thể sửa đổi, bổ sung một số nội dung nhưng không được sửa đổi thời hạn hợp đồng lao động.

## HD014 — full — lần 1

Nhân viên tiếp cận bí mật công nghệ thì doanh nghiệp có được thỏa thuận riêng bằng văn bản về bảo mật không?

Thời gian: 124038.205 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Hai bên có thể thỏa thuận bằng văn bản về phạm vi, thời hạn, quyền lợi và bồi thường khi vi phạm bảo mật, nếu công việc trực tiếp liên quan bí mật kinh doanh/công nghệ.

## TV001 — full — lần 1

Công ty trả 70% lương của công việc trong thời gian thử việc. Có đúng luật không?

Thời gian: 25392.31 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Với mức lương của công việc đó như bạn nêu, tỷ lệ 70% thấp hơn tối thiểu 85%, nên không đáp ứng quy định về tiền lương thử việc. Điều 26 (18/VBHN-VPQH): “Điều 26. Tiền lương thử việc Tiền lương của người lao động trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó.” [prov_38ac614a6bf6bd16]
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Lương thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc.

## TV002 — full — lần 1

Tôi và công ty thỏa thuận thử việc bằng 85% lương của công việc. Mức này có đáp ứng mức tối thiểu theo Bộ luật Lao động không?

Thời gian: 74967.807 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Dịch vụ kiểm tra câu trả lời tạm thời không phản hồi hoặc gặp lỗi. Chưa thể trả kết luận đã xác minh; vui lòng thử lại sau.

**Đáp án tham khảo (DRAFT):** Có. 85% bằng mức tối thiểu mà Điều 26 quy định cho lương thử việc.

## TV003 — full — lần 1

Mức lương của vị trí là 8 triệu đồng/tháng. Lương thử việc thấp nhất theo luật là bao nhiêu?

Thời gian: 9097.937 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 26: tiền lương trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó. [prov_38ac614a6bf6bd16]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất 6,8 triệu đồng/tháng, tương ứng 85% của 8 triệu đồng/tháng.

## TV004 — full — lần 1

Vị trí chuyên môn đòi hỏi trình độ cao đẳng, công ty thử việc 90 ngày có vượt giới hạn không?

Thời gian: 31632.037 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Với công việc yêu cầu chuyên môn kỹ thuật từ cao đẳng trở lên, thời gian thử việc không quá 60 ngày, nếu không thuộc nhóm quản lý doanh nghiệp theo trường hợp riêng.

## TV005 — full — lần 1

Công việc yêu cầu trình độ cao đẳng và không phải chức danh quản lý, thử việc 45 ngày có nằm trong mức tối đa không?

Thời gian: 2156.619 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Về thời gian: với nhóm công việc bạn nêu, thử việc 45 ngày không vượt mức tối đa 60 ngày. Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Thời gian thử việc tối đa trong trường hợp này là 60 ngày.

## TV006 — full — lần 1

Công việc yêu cầu trình độ trung cấp và không phải quản lý doanh nghiệp, thử việc 45 ngày có phù hợp không?

Thời gian: 9962.554 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Với nhóm công việc yêu cầu trình độ trung cấp hoặc nhân viên nghiệp vụ, thời gian thử việc tối đa là 30 ngày.

## TV007 — full — lần 1

Vị trí công nhân kỹ thuật thông thường bị thử việc 31 ngày. Có vượt giới hạn luật định không?

Thời gian: 4640.864 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Về thời gian: với nhóm công việc bạn nêu, thử việc 31 ngày vượt mức tối đa 30 ngày. Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Đối với công việc công nhân kỹ thuật, giới hạn thử việc là 30 ngày.

## TV008 — full — lần 1

Một công việc phổ thông không thuộc các nhóm yêu cầu trình độ nêu trong Điều 25, thử việc sáu ngày làm việc có đúng mức tối đa không?

Thời gian: 14868.684 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Nhóm công việc khác có thời gian thử việc tối đa 06 ngày làm việc.

## TV009 — full — lần 1

Lao động làm công việc phổ thông thông thường bị thử việc mười ngày làm việc. Có đúng không?

Thời gian: 18682.157 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Giới hạn đối với nhóm công việc khác là sáu ngày làm việc.

## TV010 — full — lần 1

Giám đốc doanh nghiệp thuộc diện người quản lý doanh nghiệp theo Điều 25 được yêu cầu thử việc 200 ngày. Có đúng không?

Thời gian: 10522.472 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Đối với công việc của người quản lý doanh nghiệp thuộc quy định này, thời gian thử việc không quá 180 ngày.

## TV011 — full — lần 1

Công ty yêu cầu tôi thử việc hai lần cho cùng một công việc sau khi lần đầu đã kết thúc. Có phù hợp không?

Thời gian: 21046.767 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 25 của Bộ luật Lao động, thời gian thử việc chỉ được thực hiện một lần đối với một công việc. [prov_0d899ce39134b1a5]
- Sau khi kết thúc thời gian thử việc, nếu đạt yêu cầu, người sử dụng lao động phải tiếp tục thực hiện hợp đồng lao động hoặc giao kết hợp đồng lao động mới. [prov_e984d1788a357c56]
- Trong thời gian thử việc, mỗi bên có quyền hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường. [prov_9e2818163eeff843]
- Do đó, việc công ty yêu cầu bạn thử việc hai lần cho cùng một công việc là không phù hợp với quy định pháp luật. [prov_0d899ce39134b1a5] [prov_e984d1788a357c56] [prov_9e2818163eeff843]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Đối với một công việc, luật chỉ cho phép thử việc một lần.

## TV012 — full — lần 1

Tôi ký hợp đồng lao động thời hạn 20 ngày. Công ty có được áp dụng thử việc không?

Thời gian: 11319.147 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Không áp dụng thử việc đối với người lao động giao kết hợp đồng lao động có thời hạn dưới một tháng.

## TV013 — full — lần 1

Đang trong thời gian thử việc, tôi muốn nghỉ ngay mà không báo trước. Theo Bộ luật Lao động có phải bồi thường không?

Thời gian: 141016.692 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Trong thời gian thử việc, mỗi bên được hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường về việc hủy bỏ đó.

## TV014 — full — lần 1

Tôi thử việc đạt yêu cầu và trước đó ký hợp đồng thử việc riêng. Công ty phải làm gì sau khi hết thử việc?

Thời gian: 23212.756 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khi kết thúc thời gian thử việc, công ty có nghĩa vụ thông báo kết quả thử việc cho người lao động. [prov_e984d1788a357c56]
- Đối với trường hợp đã ký hợp đồng thử việc riêng, nếu người lao động đạt yêu cầu, công ty phải thực hiện giao kết hợp đồng lao động với người lao động. [prov_e984d1788a357c56]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải thông báo kết quả và giao kết hợp đồng lao động nếu đã giao kết hợp đồng thử việc riêng.

## TL001 — full — lần 1

Cùng công việc có giá trị như nhau, công ty trả lương thấp hơn chỉ vì người lao động là nữ. Có đúng luật không?

Thời gian: 97525.33 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động phải bảo đảm trả lương bình đẳng, không phân biệt giới tính với công việc có giá trị như nhau.

## TL002 — full — lần 1

Doanh nghiệp trả lương theo công việc thấp hơn mức lương tối thiểu áp dụng. Có được không?

Thời gian: 71691.951 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Doanh nghiệp không được trả lương theo công việc thấp hơn mức lương tối thiểu. [prov_9145e7a92661e3b3]
- Mức lương tối thiểu là mức lương thấp nhất làm cơ sở để thỏa thuận và trả lương đối với người lao động áp dụng hình thức trả lương theo tháng. [prov_9145e7a92661e3b3]
- Mức lương theo công việc hoặc chức danh của người lao động làm việc đủ thời giờ làm việc bình thường trong tháng và hoàn thành định mức lao động hoặc công việc đã thỏa thuận không được thấp hơn mức lương tối thiểu. [prov_9145e7a92661e3b3]
- Tiền lương là số tiền mà người sử dụng lao động trả cho người lao động theo thỏa thuận để thực hiện công việc, bao gồm mức lương theo công việc hoặc chức danh. [prov_c2e1eb286f6704a7]
- Áp dụng mức lương tối thiểu là quy định bắt buộc đối với doanh nghiệp khi trả lương theo công việc. [prov_9145e7a92661e3b3]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Mức lương theo công việc hoặc chức danh không được thấp hơn mức lương tối thiểu áp dụng.

## TL003 — full — lần 1

Người lao động hưởng lương tháng có thể được trả mỗi tháng một lần không?

Thời gian: 138235.722 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động hưởng lương theo tháng có thể được trả mỗi tháng một lần. [prov_f03fcba5b5ce70b8]
- Thời điểm trả lương phải được ấn định vào một thời điểm có tính chu kỳ. [prov_f03fcba5b5ce70b8]
- Người sử dụng lao động phải trả lương trực tiếp, đầy đủ, đúng hạn cho người lao động. [prov_d57140e19f87efd7]
- Người lao động hưởng lương theo tháng có thể được trả lương theo thỏa thuận của hai bên. [prov_f03fcba5b5ce70b8]
- Người lao động hưởng lương theo tháng được trả một tháng một lần hoặc nửa tháng một lần. [prov_f03fcba5b5ce70b8]
- Người lao động hưởng lương theo tháng được trả lương theo thời gian làm việc theo tháng, tuần, ngày, giờ theo thỏa thuận trong hợp đồng lao động. [prov_f9e41d3b2357499a]
- Người lao động hưởng lương theo tháng được trả lương theo thời gian làm việc theo tháng. [prov_f9e41d3b2357499a]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Người hưởng lương theo tháng được trả một tháng một lần hoặc nửa tháng một lần, theo thời điểm có tính chu kỳ đã thỏa thuận.

## TL004 — full — lần 1

Người hưởng lương tháng được công ty trả hai tháng một lần, không có thỏa thuận đặc biệt nào. Có đúng kỳ hạn luật định không?

Thời gian: 42331.927 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Lương tháng phải được trả một tháng một lần hoặc nửa tháng một lần.

## TL005 — full — lần 1

Công ty vì bất khả kháng, đã khắc phục nhưng vẫn chậm trả lương 20 ngày. Có phải đền bù do chậm trả không?

Thời gian: 86446.908 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 97, khoản 4 của Bộ luật Lao động, trường hợp vì lý do bất khả kháng mà người sử dụng lao động đã tìm mọi biện pháp khắc phục nhưng không thể trả lương đúng hạn thì không được chậm quá 30 ngày. [prov_9bbc86f4b42624cf]
- Nếu trả lương chậm từ 15 ngày trở lên, người sử dụng lao động phải đền bù cho người lao động một khoản tiền ít nhất bằng số tiền lãi của số tiền trả chậm tính theo lãi suất huy động tiền gửi có kỳ hạn 01 tháng do ngân hàng nơi người sử dụng lao động mở tài khoản trả lương cho người lao động công bố tại thời điểm trả lương. [prov_9bbc86f4b42624cf]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Khi trả lương chậm từ 15 ngày trở lên trong trường hợp này, công ty phải đền bù ít nhất theo mức lãi được Điều 97 khoản 4 quy định.

## TL006 — full — lần 1

Do bất khả kháng đã tìm mọi biện pháp khắc phục, doanh nghiệp vẫn trả lương trễ 40 ngày. Có vượt giới hạn không?

Thời gian: 91805.662 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Ngay cả trong tình huống bất khả kháng theo khoản 4 Điều 97, thời hạn trả lương chậm không được quá 30 ngày.

## TL007 — full — lần 1

Công ty trả lương qua ngân hàng và bắt nhân viên chịu phí mở tài khoản, phí chuyển lương. Ai phải trả?

Thời gian: 82392.681 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người sử dụng lao động có nghĩa vụ chi trả các loại phí liên quan đến việc mở tài khoản và chuyển tiền lương khi thực hiện trả lương qua tài khoản cá nhân của người lao động. [prov_8897aff05cd379d3] [prov_389daa823c099a65] [prov_77a1146dda103c8b]
- Người sử dụng lao động không được ép buộc người lao động chi tiêu lương vào việc mua hàng hóa, sử dụng dịch vụ của người sử dụng lao động hoặc của đơn vị khác mà người sử dụng lao động chỉ định. [prov_7674e595f4783c17]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải trả các loại phí liên quan đến mở tài khoản và chuyển tiền lương khi trả lương qua tài khoản cá nhân.

## TL008 — full — lần 1

Tiền lương trả qua tài khoản ngân hàng đứng tên người lao động có được không?

Thời gian: 74957.388 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Tiền lương có thể trả bằng tiền mặt hoặc qua tài khoản cá nhân của người lao động được mở tại ngân hàng.

## TL009 — full — lần 1

Doanh nghiệp ép nhân viên dùng lương mua sản phẩm do chính công ty bán. Có phù hợp không?

Thời gian: 62371.723 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Việc doanh nghiệp ép nhân viên dùng lương mua sản phẩm do chính công ty bán không phù hợp với quy định pháp luật lao động. [prov_dc40fd02a106b46f] [prov_7674e595f4783c17]
- Theo Điều 94 Bộ luật Lao động, người sử dụng lao động không được ép buộc người lao động chi tiêu lương vào việc mua hàng hóa, sử dụng dịch vụ của người sử dụng lao động hoặc của đơn vị khác mà người sử dụng lao động chỉ định. [prov_dc40fd02a106b46f] [prov_7674e595f4783c17]
- Việc ép nhân viên dùng lương mua sản phẩm do công ty bán can thiệp vào quyền tự quyết chi tiêu lương của người lao động. [prov_dc40fd02a106b46f] [prov_7674e595f4783c17]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được ép buộc người lao động dùng tiền lương để mua hàng hóa, dịch vụ do họ chỉ định.

## TL010 — full — lần 1

Tiền lương làm thêm vào ngày làm việc bình thường tối thiểu bằng bao nhiêu phần trăm mức lương giờ tương ứng?

Thời gian: 8265.237 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 98 khoản 1 (18/VBHN-VPQH): “Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau:” [prov_ecbe024a3498e5dc]
- Điều 98 khoản 1 điểm a (45/2019/QH14): “Điều 98. Tỉền Iương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền luơng hoặc tiền lương thực trả theo công việc đang làm như sau: a) Vào ngày thường, ít nhất bằng 150%;” [prov_5285a6e4366d573f]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất bằng 150% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL011 — full — lần 1

Tôi làm thêm vào ngày nghỉ hằng tuần, mức lương làm thêm thấp nhất là bao nhiêu phần trăm?

Thời gian: 9.605 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 200% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL012 — full — lần 1

Tôi làm thêm vào ngày lễ, tết: mức lương làm thêm tối thiểu theo Điều 98 là bao nhiêu?

Thời gian: 8.976 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 300% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm; đối với người hưởng lương ngày, mức này chưa kể tiền lương ngày lễ được hưởng.

## TL013 — full — lần 1

Làm việc vào ban đêm nhưng không làm thêm giờ, có khoản trả thêm tối thiểu bao nhiêu?

Thời gian: 57800.649 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Được trả thêm ít nhất 30% tiền lương tính theo đơn giá hoặc tiền lương thực trả của ngày làm việc bình thường.

## TL014 — full — lần 1

Nhà máy phải ngừng việc hoàn toàn do lỗi của người sử dụng lao động. Người lao động có được trả đủ lương hợp đồng không?

Thời gian: 84616.338 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Nếu ngừng việc do lỗi của người sử dụng lao động thì người lao động được trả đủ tiền lương theo hợp đồng lao động.

## TG001 — full — lần 1

Theo chế độ thời giờ làm việc bình thường tính theo ngày, luật giới hạn tối đa mấy giờ một ngày và một tuần?

Thời gian: 105742.755 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo chế độ thời giờ làm việc bình thường tính theo ngày, luật quy định thời giờ làm việc không quá 08 giờ trong 01 ngày và không quá 48 giờ trong 01 tuần. [prov_bc9006e498dbe731] [prov_1d6455baf3b29261]
- Trường hợp người sử dụng lao động quy định thời giờ làm việc theo tuần, thời giờ làm việc bình thường không quá 10 giờ trong 01 ngày và không quá 48 giờ trong 01 tuần. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
- Tổng số giờ làm việc bình thường và số giờ làm thêm trong một tuần không quá 72 giờ. [prov_346847ce84c9f616]
- Trường hợp áp dụng quy định thời giờ làm việc bình thường theo tuần thì tổng số giờ làm việc bình thường và số giờ làm thêm không quá 12 giờ trong 01 ngày. [prov_8355bef5495c22f5]
- Nhà nước khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ đối với người lao động. [prov_91e75398d7e4027f]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không quá 8 giờ/ngày và 48 giờ/tuần theo chế độ làm việc bình thường.

## TG002 — full — lần 1

Nếu doanh nghiệp tổ chức giờ làm việc bình thường theo tuần, có thể bố trí 10 giờ một ngày và tối đa 48 giờ một tuần không?

Thời gian: 156270.084 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 105, khoản 2 của Bộ luật Lao động (số 45/2019/QH14), người sử dụng lao động có quyền quy định thời giờ làm việc theo ngày hoặc tuần, nhưng trường hợp theo tuần thì thời giờ làm việc bình thường không quá 10 giờ trong 01 ngày và không quá 48 giờ trong 01 tuần. [prov_ece436d459ebc177]
- Theo Điều 105, khoản 2 của Văn bản hợp nhất Bộ luật Lao động (số 18/VBHN-VPQH), người sử dụng lao động có quyền quy định thời giờ làm việc theo ngày hoặc tuần, nhưng trường hợp theo tuần thì thời giờ làm việc bình thường không quá 10 giờ trong 01 ngày và không quá 48 giờ trong 01 tuần. [prov_91e75398d7e4027f]
- Doanh nghiệp có thể bố trí giờ làm việc bình thường theo tuần là 10 giờ một ngày và tối đa 48 giờ một tuần, vì đây là giới hạn được quy định tại Điều 105, khoản 2 của Bộ luật Lao động và Văn bản hợp nhất Bộ luật Lao động. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
- Tuy nhiên, doanh nghiệp không được vượt quá giới hạn 48 giờ làm việc bình thường trong một tuần, vì đây là quy định bắt buộc theo Điều 105, khoản 2 của Bộ luật Lao động và Văn bản hợp nhất Bộ luật Lao động. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
- Vì vậy, doanh nghiệp có thể bố trí giờ làm việc bình thường theo tuần là 10 giờ một ngày và tối đa 48 giờ một tuần, miễn là không vượt quá giới hạn quy định tại Điều 105, khoản 2 của Bộ luật Lao động và Văn bản hợp nhất Bộ luật Lao động. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
- Điều này không vi phạm các quy định pháp luật lao động, vì giới hạn 48 giờ làm việc bình thường trong một tuần là được pháp luật cho phép. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
- Ngoài ra, doanh nghiệp cần thông báo cho người lao động về thời giờ làm việc theo quy định tại Điều 105, khoản 2 của Bộ luật Lao động và Văn bản hợp nhất Bộ luật Lao động. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
- Doanh nghiệp có thể bố trí giờ làm việc bình thường theo tuần là 10 giờ một ngày và tối đa 48 giờ một tuần, vì đây là giới hạn được pháp luật cho phép. [prov_ece436d459ebc177] [prov_91e75398d7e4027f]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có, nếu áp dụng chế độ tính theo tuần, thông báo cho người lao động và không vượt 10 giờ/ngày, 48 giờ/tuần.

## TG003 — full — lần 1

Nhà nước có khuyến khích doanh nghiệp áp dụng tuần làm việc 40 giờ không?

Thời gian: 117425.21 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Nhà nước khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ đối với người lao động. [prov_91e75398d7e4027f] [prov_ece436d459ebc177]
- Theo Điều 105 Bộ luật Lao động, thời giờ làm việc bình thường không quá 08 giờ trong 01 ngày và không quá 48 giờ trong 01 tuần. [prov_bc9006e498dbe731] [prov_1d6455baf3b29261]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Bộ luật khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ.

## TG004 — full — lần 1

Thời gian từ 23 giờ đến 5 giờ sáng hôm sau có thuộc giờ làm việc ban đêm không?

Thời gian: 110064.876 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Thời gian từ 23 giờ đến 5 giờ sáng hôm sau thuộc giờ làm việc ban đêm. [prov_576ede8fe50aa138]
- Giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau theo Điều 106 của Bộ luật Lao động. [prov_576ede8fe50aa138]
- Thời gian từ 23 giờ đến 5 giờ sáng hôm sau nằm trong khoảng từ 22 giờ đến 06 giờ sáng ngày hôm sau. [prov_576ede8fe50aa138]
- Theo Điều 106 của Bộ luật Lao động, giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau. [prov_576ede8fe50aa138]
- Thời gian từ 23 giờ đến 5 giờ sáng hôm sau thuộc giờ làm việc ban đêm theo quy định tại Điều 106 của Bộ luật Lao động. [prov_576ede8fe50aa138]
- Giờ làm việc ban đêm theo Điều 106 của Bộ luật Lao động bắt đầu từ 22 giờ và kết thúc vào 06 giờ sáng ngày hôm sau. [prov_576ede8fe50aa138]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau.

## TG005 — full — lần 1

Trong trường hợp làm thêm giờ thông thường, công ty có cần được sự đồng ý của người lao động không?

Thời gian: 141338.17 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Người sử dụng lao động phải có sự đồng ý của người lao động, trừ những trường hợp làm thêm đặc biệt do luật quy định.

## TG006 — full — lần 1

Theo cách bố trí giờ làm việc bình thường theo ngày, giới hạn làm thêm trong ngày theo Điều 107 là bao nhiêu?

Thời gian: 5330.114 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Số giờ làm thêm không quá 50% số giờ làm việc bình thường trong ngày, đồng thời phải tuân thủ các giới hạn tháng và năm tương ứng.

## TG007 — full — lần 1

Trong trường hợp làm thêm giờ thông thường, một người lao động được làm thêm tối đa bao nhiêu giờ trong một tháng?

Thời gian: 8078.57 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không quá 40 giờ làm thêm trong một tháng.

## TG008 — full — lần 1

Theo giới hạn làm thêm giờ chung, một năm được làm thêm tối đa bao nhiêu giờ nếu không thuộc ngoại lệ?

Thời gian: 12762.915 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không quá 200 giờ trong một năm, trừ các trường hợp luật cho phép tối đa 300 giờ.

## TG009 — full — lần 1

Trong một số ngành sản xuất như dệt may xuất khẩu, luật có cho phép làm thêm đến 300 giờ một năm không?

Thời gian: 153169.603 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có thể được bố trí làm thêm đến 300 giờ trong năm khi thuộc trường hợp được luật cho phép và đáp ứng các điều kiện liên quan.

## TG010 — full — lần 1

Một người làm ban đêm theo thời giờ bình thường 7 giờ trong ngày được nghỉ giữa giờ ít nhất bao lâu?

Thời gian: 131581.682 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc ban đêm theo thời giờ bình thường 7 giờ trong ngày được nghỉ giữa giờ ít nhất 45 phút liên tục. [prov_9e62cb20a3b4e144] [prov_46a09284a2885406] [prov_3e64de55e3685bbd]
- Thời gian nghỉ giữa giờ được tính vào giờ làm việc đối với trường hợp làm việc theo ca liên tục quy định tại khoản 3 Điều 63 Nghị định này ít nhất 30 phút, riêng trường hợp làm việc ban đêm thì được tính ít nhất 45 phút. [prov_ddb27796b7ed46a0]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất 45 phút liên tục khi làm việc ban đêm từ 6 giờ trở lên trong ngày.

## TG011 — full — lần 1

Người làm việc ban ngày 8 giờ/ngày được nghỉ giữa giờ ít nhất bao nhiêu phút?

Thời gian: 85628.74 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc ban ngày 8 giờ/ngày được nghỉ giữa giờ ít nhất 30 phút liên tục. [prov_3e64de55e3685bbd] [prov_46a09284a2885406]
- Thời gian nghỉ giữa giờ được tính vào giờ làm việc khi người lao động làm việc theo ca liên tục từ 06 giờ trở lên. [prov_3e64de55e3685bbd] [prov_46a09284a2885406]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất 30 phút liên tục khi thời gian làm việc trong ngày từ 6 giờ trở lên.

## TG012 — full — lần 1

Người làm ca liên tục 8 giờ/ngày, thời gian nghỉ giữa giờ có được tính vào giờ làm việc không?

Thời gian: 85491.712 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Nếu làm việc theo ca liên tục từ 6 giờ trở lên, thời gian nghỉ giữa giờ được tính vào giờ làm việc.

## TG013 — full — lần 1

Người lao động làm việc theo ca cần được nghỉ ít nhất bao nhiêu giờ trước khi chuyển sang ca khác?

Thời gian: 121633.801 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc theo ca liên tục từ 06 giờ trở lên thì được nghỉ giữa giờ ít nhất 30 phút liên tục, làm việc ban đêm thì được nghỉ giữa giờ ít nhất 45 phút liên tục. [prov_3e64de55e3685bbd] [prov_46a09284a2885406]
- Thời gian nghỉ giữa giờ được tính vào giờ làm việc đối với trường hợp làm việc theo ca liên tục quy định tại khoản 3 Điều 63 Nghị định này ít nhất 30 phút, riêng trường hợp làm việc ban đêm thì được tính ít nhất 45 phút. [prov_ddb27796b7ed46a0]
- Việc nghỉ trong giờ làm việc, nghỉ chuyển ca đối với từng người lao động thực hiện theo quy định của Bộ luật Lao động và Nghị định số 145/2020/NĐ-CP. [prov_65eaf80d61f17e29]
- Nội quy lao động không được trái với pháp luật về lao động và quy định của pháp luật có liên quan. [prov_4ea024998b7282f0]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Chưa có đủ căn cứ để trả lời toàn bộ các phần của câu hỏi; phần còn thiếu được ghi trong limitations.

**Đáp án tham khảo (DRAFT):** Ít nhất 12 giờ trước khi chuyển sang ca làm việc khác.

## TG014 — full — lần 1

Trong thiên tai cần bảo vệ ngay tính mạng con người, doanh nghiệp có thể yêu cầu làm thêm giờ đặc biệt vượt giới hạn thông thường không?

Thời gian: 12305.396 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có thể yêu cầu làm thêm giờ trong trường hợp bảo vệ tính mạng và khắc phục hậu quả theo Điều 108, trừ khi có nguy cơ ảnh hưởng tính mạng, sức khỏe của người lao động theo pháp luật an toàn, vệ sinh lao động.

## NP001 — full — lần 1

Theo quy định chung, một tuần người lao động phải được nghỉ ít nhất bao nhiêu giờ liên tục?

Thời gian: 120353.678 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Ít nhất 24 giờ liên tục trong một tuần.

## NP002 — full — lần 1

Doanh nghiệp có thể chọn ngày nghỉ hằng tuần là thứ Hai thay vì Chủ nhật không?

Thời gian: 138889.836 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Ngày nghỉ hằng tuần có thể là Chủ nhật hoặc một ngày khác xác định trong tuần và phải ghi trong nội quy lao động.

## NP003 — full — lần 1

Nếu ngày nghỉ hằng tuần trùng ngày nghỉ lễ, người lao động có được nghỉ bù không?

Thời gian: 40377.882 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ bù ngày nghỉ hằng tuần vào ngày làm việc kế tiếp.

## NP004 — full — lần 1

Do chu kỳ lao động đặc biệt không thể bố trí nghỉ hằng tuần, người lao động phải được nghỉ bình quân ít nhất bao nhiêu ngày một tháng?

Thời gian: 84356.048 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc theo chu kỳ lao động đặc biệt không thể bố trí nghỉ hằng tuần thì phải được nghỉ bình quân ít nhất 04 ngày một tháng. [prov_15de10dea407c364] [prov_f846a88fc5a3b25e] [prov_1276e3f3d79483fe]
- Trong trường hợp không thể nghỉ hằng tuần, người lao động được nghỉ tính bình quân 01 tháng ít nhất 04 ngày. [prov_15de10dea407c364] [prov_f846a88fc5a3b25e] [prov_1276e3f3d79483fe]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải bảo đảm bình quân một tháng ít nhất bốn ngày nghỉ trong trường hợp đặc biệt đó.

## NP005 — full — lần 1

Người làm đủ 12 tháng trong điều kiện bình thường có bao nhiêu ngày nghỉ hằng năm hưởng nguyên lương?

Thời gian: 66607.508 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không thể tạo câu trả lời có trích dẫn được xác minh.

**Đáp án tham khảo (DRAFT):** 12 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP006 — full — lần 1

Người làm nghề nặng nhọc, độc hại, nguy hiểm đủ 12 tháng được nghỉ phép năm bao nhiêu ngày?

Thời gian: 1924.226 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Mức nghỉ cơ sở được xác định theo nhóm áp dụng tại khoản 1 Điều 113; không cộng chồng các mức nghỉ vì tuổi, khuyết tật và điều kiện công việc. Mức nền phù hợp là 14 ngày; thâm niên 0 năm làm tăng 0 ngày theo từng chu kỳ đủ 05 năm. Tổng tối thiểu là 14 ngày. [prov_42bcd849a0a30ecd]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** 14 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP007 — full — lần 1

Người làm nghề đặc biệt nặng nhọc, độc hại, nguy hiểm đủ 12 tháng có bao nhiêu ngày phép năm?

Thời gian: 6715.769 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không thể tạo câu trả lời có trích dẫn được xác minh.

**Đáp án tham khảo (DRAFT):** 16 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP008 — full — lần 1

Người làm việc chưa đủ 12 tháng có được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc không?

Thời gian: 53585.179 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Số ngày nghỉ hằng năm được tính theo tỷ lệ tương ứng với số tháng làm việc.

## NP009 — full — lần 1

Tôi đã làm việc đủ 5 năm cho cùng một công ty. Số ngày nghỉ hằng năm có tăng thêm không?

Thời gian: 5128.228 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Nếu làm đủ 12 tháng trong năm cho cùng người sử dụng lao động và thuộc nhóm đã nêu, mức nền là 14 ngày, cộng 1 ngày cho 5 năm thâm niên: 15 ngày. Chưa có số tháng làm việc trong năm nên không xác nhận số ngày thực tế của năm đó. [prov_42bcd849a0a30ecd] [prov_a0c75b34c1abb058]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Cứ đủ 5 năm làm việc cho một người sử dụng lao động, số ngày nghỉ hằng năm tăng thêm một ngày.

## NP010 — full — lần 1

Người lao động thôi việc mà chưa sử dụng hết ngày nghỉ hằng năm có được thanh toán ngày chưa nghỉ không?

Thời gian: 24.826 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Khi thôi việc hoặc bị mất việc mà còn ngày nghỉ hằng năm chưa nghỉ, người sử dụng lao động phải thanh toán tiền lương cho những ngày đó.

## NP011 — full — lần 1

Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa mấy năm một lần?

Thời gian: 55479.22 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 113 Bộ luật Lao động, người lao động làm việc đủ 12 tháng cho một người sử dụng lao động thì được nghỉ hằng năm, hưởng nguyên lương theo hợp đồng lao động, với thời lượng nghỉ được quy định cụ thể tùy theo điều kiện lao động. [prov_3bb8e6ed783463fe] [prov_42bcd849a0a30ecd] [prov_1fab8366c4ce639b]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Chưa có đủ căn cứ để trả lời toàn bộ các phần của câu hỏi; phần còn thiếu được ghi trong limitations.

**Đáp án tham khảo (DRAFT):** Có thể thỏa thuận nghỉ gộp tối đa ba năm một lần.

## NP012 — full — lần 1

Tôi kết hôn thì được nghỉ việc riêng hưởng nguyên lương mấy ngày?

Thời gian: 68832.048 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 115, người lao động kết hôn được nghỉ việc riêng hưởng nguyên lương 03 ngày. [prov_80e299cace3d3f78]
- Người lao động phải thông báo với người sử dụng lao động khi nghỉ việc riêng do kết hôn. [prov_80e299cace3d3f78]
- Người lao động được nghỉ việc riêng hưởng nguyên lương trong trường hợp kết hôn theo quy định tại Điều 115. [prov_80e299cace3d3f78]
- Người lao động được nghỉ việc riêng hưởng nguyên lương 03 ngày khi kết hôn, theo Điều 115. [prov_80e299cace3d3f78]
- Người lao động được nghỉ việc riêng hưởng nguyên lương 03 ngày trong trường hợp kết hôn, theo Điều 115. [prov_80e299cace3d3f78]
- Người lao động được nghỉ việc riêng hưởng nguyên lương 03 ngày khi kết hôn, theo Điều 115 của Bộ luật Lao động. [prov_80e299cace3d3f78]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Được nghỉ ba ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP013 — full — lần 1

Con đẻ của tôi kết hôn thì tôi được nghỉ hưởng nguyên lương bao nhiêu ngày?

Thời gian: 109266.232 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo quy định tại Điều 115, khoản 1, điểm b, Văn bản hợp nhất 18/VBHN-VPQH, người lao động được nghỉ 01 ngày hưởng nguyên lương khi con đẻ kết hôn. [prov_221173ca085623ba]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Được nghỉ một ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP014 — full — lần 1

Anh ruột của tôi qua đời, tôi có quyền nghỉ một ngày không hưởng lương không?

Thời gian: 74100.515 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ một ngày không hưởng lương và phải thông báo cho người sử dụng lao động.

## CD001 — full — lần 1

Tôi làm theo hợp đồng không xác định thời hạn, muốn đơn phương nghỉ việc bình thường. Cần báo trước tối thiểu bao nhiêu ngày?

Thời gian: 19131.562 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm theo hợp đồng không xác định thời hạn có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước ít nhất 45 ngày. [prov_e091631d0168c360]
- Theo Điều 35, khoản 1, điểm a của Bộ luật Lao động, người lao động phải báo trước ít nhất 45 ngày khi đơn phương chấm dứt hợp đồng lao động không xác định thời hạn. [prov_e091631d0168c360]
- Người lao động cần báo trước ít nhất 45 ngày trước khi đơn phương nghỉ việc theo hợp đồng không xác định thời hạn. [prov_e091631d0168c360]
- Theo quy định tại Điều 35, khoản 1, điểm a của Văn bản hợp nhất Bộ luật Lao động, người lao động làm theo hợp đồng không xác định thời hạn phải báo trước ít nhất 45 ngày khi đơn phương chấm dứt hợp đồng lao động. [prov_e091631d0168c360]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Thông thường phải báo trước ít nhất 45 ngày, trừ ngành nghề/công việc đặc thù hoặc trường hợp được nghỉ không báo trước.

## CD002 — full — lần 1

Tôi có hợp đồng xác định thời hạn 24 tháng, muốn đơn phương nghỉ việc trong trường hợp thông thường. Phải báo trước bao lâu?

Thời gian: 95184.72 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 35, điểm b, bạn phải báo trước ít nhất 30 ngày nếu làm việc theo hợp đồng lao động xác định thời hạn có thời hạn từ 12 tháng đến 36 tháng. [prov_c75b6504b5c1069f]
- Đối với một số ngành, nghề, công việc đặc thù, thời hạn báo trước được thực hiện theo quy định của Chính phủ. [prov_bfc5906f1e003421]
- Người lao động có quyền đơn phương chấm dứt hợp đồng lao động không cần báo trước trong một số trường hợp đặc biệt theo quy định tại Điều 35, khoản 2. [prov_186d81901fe081bc]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất 30 ngày, trừ trường hợp được quyền nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD003 — full — lần 1

Tôi có hợp đồng xác định thời hạn 9 tháng, đơn phương nghỉ bình thường. Phải báo trước tối thiểu mấy ngày?

Thời gian: 239261.12 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Ít nhất 3 ngày làm việc, trừ trường hợp được nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD004 — full — lần 1

Công ty không trả lương đúng hạn mà không thuộc ngoại lệ bất khả kháng của khoản 4 Điều 97. Tôi có quyền nghỉ mà không báo trước không?

Thời gian: 18.646 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động được đơn phương chấm dứt hợp đồng không cần báo trước nếu không được trả đủ hoặc đúng hạn, trừ trường hợp ngoại lệ quy định ở khoản 4 Điều 97.

## CD005 — full — lần 1

Người lao động bị người sử dụng lao động đánh đập, nhục mạ thì có thể chấm dứt hợp đồng không cần báo trước không?

Thời gian: 41673.968 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động có quyền đơn phương chấm dứt hợp đồng lao động không cần báo trước nếu bị người sử dụng lao động đánh đập, nhục mạ. [prov_186d81901fe081bc]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Chưa có đủ căn cứ để trả lời toàn bộ các phần của câu hỏi; phần còn thiếu được ghi trong limitations.

**Đáp án tham khảo (DRAFT):** Có. Đây là trường hợp người lao động được đơn phương chấm dứt hợp đồng mà không cần báo trước.

## CD006 — full — lần 1

Công ty không bố trí đúng công việc đã thỏa thuận và không thuộc trường hợp điều chuyển hợp pháp ở Điều 29. Người lao động có được nghỉ không cần báo trước không?

Thời gian: 20.032 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có quyền đơn phương chấm dứt không cần báo trước nếu không được bố trí đúng công việc, địa điểm hoặc điều kiện đã thỏa thuận, trừ ngoại lệ Điều 29.

## CD007 — full — lần 1

Doanh nghiệp có thể đơn phương cho thôi việc do nhân viên thường xuyên không hoàn thành công việc theo tiêu chí đánh giá hợp lệ không?

Thời gian: 62785.006 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có thể, nếu thật sự thường xuyên không hoàn thành công việc theo tiêu chí quy chế đánh giá hợp lệ, bảo đảm nghĩa vụ tham khảo ý kiến khi áp dụng và thời hạn báo trước tương ứng.

## CD008 — full — lần 1

Người lao động tự ý bỏ việc không lý do chính đáng trong 5 ngày làm việc liên tục. Công ty có cần báo trước khi đơn phương chấm dứt không?

Thời gian: 118837.679 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Đây là trường hợp người sử dụng lao động có thể đơn phương chấm dứt không cần báo trước theo Điều 36.

## CD009 — full — lần 1

Người lao động nữ đang mang thai, công ty có được đơn phương chấm dứt hợp đồng chỉ vì lý do mang thai không?

Thời gian: 18.189 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Bộ luật Lao động có quy định bảo vệ người lao động nữ mang thai, không cho người sử dụng lao động thực hiện quyền đơn phương chấm dứt trong trường hợp này.

## CD010 — full — lần 1

Người lao động đang nghỉ phép năm đã được công ty chấp thuận, công ty có được đơn phương chấm dứt hợp đồng trong thời gian nghỉ đó không?

Thời gian: 19.478 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được thực hiện quyền đơn phương chấm dứt khi người lao động đang nghỉ hằng năm, nghỉ việc riêng hoặc nghỉ khác được chấp thuận.

## CD011 — full — lần 1

Người lao động tự ý đơn phương nghỉ việc trái luật và không báo trước. Người đó có thể phải bồi thường nửa tháng lương cộng phần tiền của ngày không báo trước không?

Thời gian: 20.771 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Trường hợp đơn phương chấm dứt trái pháp luật, người lao động phải bồi thường nửa tháng tiền lương theo hợp đồng và khoản tương ứng các ngày không báo trước.

## CD012 — full — lần 1

Công ty đơn phương chấm dứt hợp đồng trái pháp luật và người lao động muốn quay lại làm việc. Công ty có nghĩa vụ bồi thường ít nhất hai tháng tiền lương không?

Thời gian: 28.848 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Theo khoản 1 Điều 41, công ty phải nhận lại người lao động, thanh toán quyền lợi liên quan trong thời gian không làm việc và trả thêm ít nhất hai tháng lương hợp đồng.

## CD013 — full — lần 1

Sau khi chấm dứt hợp đồng thông thường, thời hạn thanh toán các khoản quyền lợi liên quan là bao nhiêu ngày làm việc?

Thời gian: 97463.994 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Thông thường hai bên phải thanh toán đầy đủ trong 14 ngày làm việc kể từ ngày chấm dứt hợp đồng.

## CD014 — full — lần 1

Trong trường hợp thuộc ngoại lệ luật định khi doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng có thể kéo dài tối đa bao nhiêu ngày?

Thời gian: 114093.054 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Trong trường hợp doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng lao động có thể kéo dài tối đa 30 ngày. [prov_875506191a25ffab] [prov_cb96c82086af65db]
- Trong trường hợp doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng lao động được quy định trong Điều 48 Bộ luật Lao động. [prov_875506191a25ffab] [prov_cb96c82086af65db]
- Trong trường hợp doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng lao động không được vượt quá 30 ngày. [prov_875506191a25ffab] [prov_cb96c82086af65db]
- Trong trường hợp doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng lao động có thể kéo dài nhưng không quá 30 ngày. [prov_875506191a25ffab] [prov_cb96c82086af65db]
- Trong trường hợp doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng lao động được quy định là không quá 30 ngày. [prov_875506191a25ffab] [prov_cb96c82086af65db]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có thể kéo dài nhưng không quá 30 ngày nếu đúng trường hợp ngoại lệ thuộc Điều 48 khoản 1.

## CD015 — full — lần 1

Người lao động làm việc thường xuyên 8 tháng rồi chấm dứt hợp đồng: có đương nhiên đủ điều kiện thời gian để nhận trợ cấp thôi việc theo Điều 46 không?

Thời gian: 638.126 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Chưa. Điều 46 đặt điều kiện đã làm việc thường xuyên từ đủ 12 tháng trở lên và phải thuộc trường hợp chấm dứt quy định, có các trường hợp loại trừ.

## TD001 — full — lần 1

Tôi muốn nghỉ việc, tôi phải báo trước cho công ty bao nhiêu ngày?

Thời gian: 16964.842 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Nếu bạn làm việc theo hợp đồng lao động không xác định thời hạn, bạn phải báo trước ít nhất 45 ngày. [prov_e091631d0168c360]
- Nếu bạn làm việc theo hợp đồng lao động xác định thời hạn có thời hạn từ 12 tháng đến 36 tháng, bạn phải báo trước ít nhất 30 ngày. [prov_c75b6504b5c1069f]
- Nếu bạn làm việc theo hợp đồng lao động xác định thời hạn có thời hạn dưới 12 tháng, bạn phải báo trước ít nhất 03 ngày làm việc. [prov_85a2c41c4237c73d]
- Trong một số ngành, nghề, công việc đặc thù, thời hạn báo trước được thực hiện theo quy định của Chính phủ. [prov_bfc5906f1e003421]
- Người lao động có quyền đơn phương chấm dứt hợp đồng lao động không cần báo trước trong một số trường hợp cụ thể. [prov_186d81901fe081bc]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, thời hạn hợp đồng, ngành nghề đặc thù và lý do nghỉ để xác định thời hạn báo trước hoặc quyền nghỉ không báo trước.

## TD002 — full — lần 1

Tôi được tuyển vào công ty, công ty có thể thử việc tôi tối đa bao lâu?

Thời gian: 5520.966 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Cần biết chức danh và trình độ chuyên môn kỹ thuật thực sự cần cho công việc; các nhóm có giới hạn thử việc khác nhau.

## TD003 — full — lần 1

Công ty trả tôi lương 6 triệu đồng một tháng, như vậy có thấp hơn mức lương tối thiểu không?

Thời gian: 49371.47 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết địa bàn vùng lương tối thiểu, kỳ áp dụng và cách trả lương; chỉ với số 6 triệu đồng chưa đủ để kết luận.

## TD004 — full — lần 1

Tôi đang làm tại một doanh nghiệp, năm nay tôi được nghỉ bao nhiêu ngày phép năm?

Thời gian: 19781.908 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc đủ 12 tháng cho một người sử dụng lao động trong điều kiện bình thường được nghỉ hằng năm 12 ngày làm việc. [prov_3bb8e6ed783463fe]
- Người lao động chưa thành niên, người khuyết tật, hoặc người làm nghề, công việc nặng nhọc, độc hại, nguy hiểm làm việc đủ 12 tháng cho một người sử dụng lao động được nghỉ hằng năm 14 ngày làm việc. [prov_42bcd849a0a30ecd]
- Người làm nghề, công việc đặc biệt nặng nhọc, độc hại, nguy hiểm làm việc đủ 12 tháng cho một người sử dụng lao động được nghỉ hằng năm 16 ngày làm việc. [prov_1fab8366c4ce639b]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Chưa có đủ căn cứ để trả lời toàn bộ các phần của câu hỏi; phần còn thiếu được ghi trong limitations.

**Đáp án tham khảo (DRAFT):** Cần biết thời gian làm việc, nhóm điều kiện công việc và thâm niên để tính số ngày nghỉ hằng năm.

## TD005 — full — lần 1

Sếp yêu cầu tăng ca nhưng tôi chưa rõ số giờ. Như vậy có vi phạm giới hạn làm thêm giờ không?

Thời gian: 496.435 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết giờ làm bình thường, số giờ làm thêm trong ngày/tháng/năm, sự đồng ý và có thuộc ngoại lệ hay không.

## TD006 — full — lần 1

Tôi tự ý nghỉ việc, công ty yêu cầu bồi thường. Tôi có phải bồi thường không?

Thời gian: 19426.459 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 39 của Bộ luật Lao động, việc bạn tự ý nghỉ việc mà không có sự thỏa thuận với công ty được coi là đơn phương chấm dứt hợp đồng lao động trái pháp luật. [prov_3b1d15590711065e]
- Theo Điều 40, khoản 2 của Bộ luật Lao động, bạn phải bồi thường cho công ty nửa tháng tiền lương theo hợp đồng lao động và một khoản tiền tương ứng với tiền lương theo hợp đồng lao động trong những ngày không báo trước. [prov_ef06e74f0e045edb]
- Theo Điều 40, khoản 3 của Bộ luật Lao động, bạn phải hoàn trả cho công ty chi phí đào tạo quy định tại Điều 62 của Bộ luật này. [prov_d198a164e4e1cf1b]
- Theo Điều 40, khoản 1 của Bộ luật Lao động, bạn không được hưởng trợ cấp thôi việc. [prov_9af862b61486f6a1]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, lý do nghỉ, thời hạn báo trước và tình tiết được nghỉ không cần báo trước để xác định có nghỉ trái luật hay không.

## TD007 — full — lần 1

Sau khi nghỉ việc tôi có được nhận trợ cấp thôi việc hay không?

Thời gian: 17.118 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Cần biết cách chấm dứt hợp đồng, thời gian làm việc, thời gian đóng bảo hiểm thất nghiệp và các khoản trợ cấp đã nhận.

## TD008 — full — lần 1

Công ty điều chuyển tôi sang công việc khác 40 ngày. Như vậy có hợp pháp không?

Thời gian: 74381.201 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần làm rõ lý do điều chuyển, số ngày chuyển cộng dồn trong năm, thông báo trước và chế độ lương khi chuyển.

## TD009 — full — lần 1

Ngày nghỉ lễ tôi được hưởng khoản tiền làm thêm như thế nào?

Thời gian: 129082.639 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Nội dung nguồn có lỗi đọc chữ đáng ngờ. Cần đối chiếu bản gốc trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết bạn có thực tế làm việc vào ngày lễ không, có làm thêm giờ hay không và hình thức trả lương để áp dụng đúng mức.

## TD010 — full — lần 1

Tôi tăng ca vào thứ Bảy thì có được trả ít nhất 200% không?

Thời gian: 109903.817 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Đối với người lao động hưởng lương theo sản phẩm, đơn giá tiền lương sản phẩm vào ban ngày của ngày nghỉ hằng tuần được tính ít nhất bằng 200% so với đơn giá tiền lương sản phẩm của ngày làm việc bình thường. [prov_ae9142da54868126]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Chưa có đủ căn cứ để trả lời toàn bộ các phần của câu hỏi; phần còn thiếu được ghi trong limitations.

**Đáp án tham khảo (DRAFT):** Cần biết thứ Bảy có phải ngày nghỉ hằng tuần theo nội quy/lịch của bạn hay là ngày làm việc bình thường.

## TD011 — full — lần 1

Lương thử việc của tôi là 6 triệu đồng mỗi tháng, có hợp pháp không?

Thời gian: 11782.538 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không thể tạo câu trả lời có trích dẫn được xác minh.

**Đáp án tham khảo (DRAFT):** Cần biết mức lương của chính công việc đó khi làm chính thức; lương thử việc phải từ 85% mức ấy trở lên.

## TD012 — full — lần 1

Công ty và tôi chỉ thỏa thuận miệng để làm việc; hợp đồng như vậy hợp lệ không?

Thời gian: 122238.029 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết thời hạn hợp đồng và liệu công việc có thuộc trường hợp bắt buộc phải lập văn bản hay không.

## TD013 — full — lần 1

Vào ngày 01/01/2028, mức lương tối thiểu vùng I chính xác là bao nhiêu?

Thời gian: 26897.024 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Chưa thể khẳng định mức cụ thể cho ngày 01/01/2028 từ bộ dữ liệu được chốt năm 2026. Cần văn bản quy định mức lương tối thiểu có hiệu lực tại thời điểm tương lai này.

## TD014 — full — lần 1

Năm 2028 lịch nghỉ Tết Âm lịch chính thức theo quyết định của Thủ tướng sẽ rơi vào những ngày dương lịch nào?

Thời gian: 38971.259 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Nội dung nguồn có lỗi đọc chữ đáng ngờ. Cần đối chiếu bản gốc trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không đủ căn cứ để nêu lịch nghỉ cụ thể của năm 2028 từ bộ dữ liệu đang chốt năm 2026; lịch thực hiện phải đối chiếu quyết định chính thức áp dụng cho năm đó.

## TD015 — full — lần 1

Năm 2029 Chính phủ sẽ nâng số giờ làm thêm tối đa thông thường lên mức nào, nếu có thay đổi luật?

Thời gian: 34207.301 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 107 khoản 2 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: a) Phải được sự đồng ý của người lao động;” [prov_2315c425c1eaa518]
- Điều 107 khoản 2 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: b) Bảo đảm số giờ làm thêm của người lao động không quá 50% số giờ làm việc bình thường trong 01 ngày; trường hợp áp dụng quy định thời giờ làm việc bình thường theo tuần thì tổng số giờ làm việc bình thường và số giờ làm thêm không quá 12 giờ trong 01 ngày; không quá 40 giờ trong 01 tháng;” [prov_4ae9d3f661c91bf1]
- Điều 107 khoản 2 điểm c (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: c) Bảo đảm số giờ làm thêm của người lao động không quá 200 giờ trong 01 năm, trừ trường hợp quy định tại khoản 3 Điều này.” [prov_7ebbd1a871c548bc]
- Điều 107 khoản 3 (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây:” [prov_ea4944bd15922c19]
- Điều 107 khoản 3 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: a) Sản xuất, gia công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông, lâm, diêm nghiệp, thủy sản;” [prov_26921bbfe43debe0]
- Điều 107 khoản 3 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: b) Sản xuất, cung cấp điện, viễn thông, lọc dầu; cấp, thoát nước;” [prov_0328018d8169ca6e]
- Điều 107 khoản 3 điểm c (45/2019/QH14): “Điều 107. Làm thêm giờ 3. Nguời sử dụng lao động được sử dụng nguời lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc truờng hợp sau đây: công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông; lâm; diêm nghiệp, thủy sản; c) Trường hợp giải quyết công việc đòi hỏi lao động có trình độ chuyên môn, kỹ thuật cao mà thị trường lao động không cung ứng đầy đủ, kịp thời;” [prov_07018d0a70f8d54b]
- Điều 107 khoản 3 điểm d (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: d) Trường hợp phải giải quyết công việc cấp bách, không thể trì hoãn do tính chất thời vụ, thời điểm của nguyên liệu, sản phẩm hoặc để giải quyết công việc phát sinh do yếu tố khách quan không dự liệu trước, do hậu quả thời tiết, thiên tai, hỏa hoạn, địch họa, thiếu điện, thiếu nguyên liệu, sự cố kỹ thuật của dây chuyền sản xuất;” [prov_99f19670e4f6b29c]
- Điều 107 khoản 3 điểm đ (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: đ) Trường hợp khác do Chính phủ quy định.” [prov_ef37b4b2ec39c720]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Chưa có đủ căn cứ để trả lời toàn bộ các phần của câu hỏi; phần còn thiếu được ghi trong limitations.

**Đáp án tham khảo (DRAFT):** Không có căn cứ pháp lý đã ban hành và được xác minh về một sửa đổi giả định năm 2029; không thể đưa ra con số chính xác chỉ dựa vào dự báo.

## HD001 — without_graph — lần 1

Tôi ký hợp đồng làm việc 20 ngày cho công việc thông thường bằng lời nói, có được không?

Thời gian: 91182.837 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Hợp đồng lao động cho công việc thông thường phải được giao kết bằng văn bản theo quy định tại Điều 14, khoản 1 của Văn bản hợp nhất Bộ luật Lao động 18/VBHN-VPQH. [prov_89771ca82d7c7b0f]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có thể giao kết bằng lời nói với hợp đồng dưới một tháng, nếu không thuộc các trường hợp luật bắt buộc lập bằng văn bản.

## HD002 — without_graph — lần 1

Công ty ký hợp đồng lao động 6 tháng với tôi nhưng chỉ thỏa thuận miệng. Như vậy có đúng hình thức không?

Thời gian: 51540.855 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng 6 tháng phải được giao kết bằng văn bản, có thể bằng thông điệp dữ liệu điện tử đủ điều kiện pháp luật.

## HD003 — without_graph — lần 1

Hợp đồng lao động ký qua phương tiện điện tử dưới dạng thông điệp dữ liệu có giá trị như hợp đồng giấy không?

Thời gian: 160178.582 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng lao động điện tử bằng thông điệp dữ liệu theo pháp luật giao dịch điện tử có giá trị như hợp đồng bằng văn bản.

## HD004 — without_graph — lần 1

Khi ký hợp đồng lao động bằng văn bản, người lao động có phải giữ một bản không?

Thời gian: 88223.692 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khi ký hợp đồng lao động bằng văn bản, người lao động có phải giữ một bản không? [prov_89771ca82d7c7b0f] [prov_17bb52034b7da75a]
- Theo Điều 14, hợp đồng lao động phải được giao kết bằng văn bản và được làm thành 02 bản, người lao động giữ 01 bản, người sử dụng lao động giữ 01 bản. [prov_89771ca82d7c7b0f] [prov_17bb52034b7da75a]
- Hợp đồng lao động được giao kết thông qua phương tiện điện tử dưới hình thức thông điệp dữ liệu có giá trị như hợp đồng lao động bằng văn bản. [prov_89771ca82d7c7b0f]
- Hợp đồng lao động được giao kết bằng văn bản và được làm thành 02 bản, người lao động giữ 01 bản, người sử dụng lao động giữ 01 bản. [prov_17bb52034b7da75a]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng bằng văn bản được làm thành hai bản, mỗi bên giữ một bản.

## HD005 — without_graph — lần 1

Công ty gọi giấy tờ của tôi là hợp đồng cộng tác viên nhưng tôi được trả lương và chịu quản lý giờ làm. Có thể là hợp đồng lao động không?

Thời gian: 74639.577 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 1 Điều 13: dù thỏa thuận mang tên gọi khác, nếu nội dung thể hiện việc làm có trả công, tiền lương và sự quản lý, điều hành, giám sát của một bên thì được coi là hợp đồng lao động. Tên gọi “thực tập sinh” hoặc “hợp đồng dịch vụ” tự nó chưa đủ để kết luận; cần đối chiếu đủ các dấu hiệu này với thực tế. [prov_c6b64b7574aec2bb]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có thể được coi là hợp đồng lao động dù tên gọi khác, nếu có việc làm có trả công và chịu sự quản lý, điều hành, giám sát của một bên.

## HD006 — without_graph — lần 1

Doanh nghiệp muốn ký hợp đồng lao động xác định thời hạn 48 tháng với nhân viên thông thường. Có hợp lệ về thời hạn không?

Thời gian: 96682.137 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng lao động xác định thời hạn theo quy định chung có thời hạn tối đa 36 tháng.

## HD007 — without_graph — lần 1

Hợp đồng 24 tháng đã hết hạn, tôi tiếp tục làm việc 40 ngày và hai bên không ký hợp đồng mới. Hợp đồng trở thành loại nào?

Thời gian: 68009.465 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Hợp đồng xác định thời hạn đã giao kết chuyển thành hợp đồng lao động không xác định thời hạn sau khi quá 30 ngày mà hai bên không ký mới.

## HD008 — without_graph — lần 1

Hợp đồng có thời hạn vừa hết 10 ngày, tôi vẫn làm mà chưa ký mới. Quyền lợi được áp dụng theo hợp đồng cũ không?

Thời gian: 144517.347 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Trong thời hạn 30 ngày từ khi hợp đồng hết hạn, nếu chưa ký mới thì quyền, nghĩa vụ và lợi ích vẫn theo hợp đồng đã giao kết.

## HD009 — without_graph — lần 1

Tôi đã ký hai hợp đồng xác định thời hạn liên tiếp ở công ty tư nhân thông thường. Nếu tiếp tục làm việc, có thể ký lần thứ ba cùng loại không?

Thời gian: 123932.896 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Thông thường không. Sau lần ký thêm một hợp đồng xác định thời hạn, nếu tiếp tục làm việc thì phải ký hợp đồng không xác định thời hạn, trừ trường hợp luật quy định ngoại lệ.

## HD010 — without_graph — lần 1

Tôi có thể cùng lúc ký hợp đồng lao động với hai công ty khác nhau không?

Thời gian: 70937.266 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có thể giao kết nhiều hợp đồng với nhiều người sử dụng lao động nếu bảo đảm thực hiện đầy đủ nội dung đã ký.

## HD011 — without_graph — lần 1

Công ty giữ bản chính bằng đại học của tôi để bảo đảm tôi không nghỉ việc. Có được không?

Thời gian: 25750.86 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 1 Điều 17: Điều 17. Hành vi người sử dụng lao động không được làm khi giao kết, thực hiện hợp đồng lao động 1. Giữ bản chính giấy tờ tùy thân, văn bằng, chứng chỉ của người lao động. [prov_e401e65d2e15b2ac]
- Việc người sử dụng lao động giữ bản chính giấy tờ tùy thân, văn bằng, chứng chỉ để ràng buộc người lao động là hành vi bị cấm tại khoản 1 Điều 17; cần phân biệt với việc xuất trình để đối chiếu rồi trả lại. [prov_e401e65d2e15b2ac]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được giữ bản chính giấy tờ tùy thân, văn bằng hoặc chứng chỉ của người lao động.

## HD012 — without_graph — lần 1

Công ty yêu cầu tôi đặt cọc hai triệu đồng để nhận việc theo hợp đồng lao động. Có được không?

Thời gian: 42065.219 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 2 Điều 17: Điều 17. Hành vi người sử dụng lao động không được làm khi giao kết, thực hiện hợp đồng lao động 2. Yêu cầu người lao động phải thực hiện biện pháp bảo đảm bằng tiền hoặc tài sản khác cho việc thực hiện hợp đồng lao động. [prov_b44555d589adb6e2]
- Nếu khoản tiền hoặc tài sản thực chất là biện pháp bảo đảm cho việc thực hiện hợp đồng lao động thì thuộc hành vi bị cấm tại khoản 2 Điều 17. Đổi tên thành “phí bảo đảm uy tín” không làm thay đổi bản chất; cần kiểm tra mục đích và điều kiện nộp, hoàn trả thực tế. [prov_b44555d589adb6e2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được yêu cầu bảo đảm bằng tiền hoặc tài sản khác để thực hiện hợp đồng lao động.

## HD013 — without_graph — lần 1

Công ty muốn gia hạn thời hạn hợp đồng bằng phụ lục thay vì ký hợp đồng lao động mới. Có được không?

Thời gian: 82002.434 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Phụ lục có thể sửa đổi, bổ sung một số nội dung nhưng không được sửa đổi thời hạn hợp đồng lao động.

## HD014 — without_graph — lần 1

Nhân viên tiếp cận bí mật công nghệ thì doanh nghiệp có được thỏa thuận riêng bằng văn bản về bảo mật không?

Thời gian: 62276.94 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Hai bên có thể thỏa thuận bằng văn bản về phạm vi, thời hạn, quyền lợi và bồi thường khi vi phạm bảo mật, nếu công việc trực tiếp liên quan bí mật kinh doanh/công nghệ.

## TV001 — without_graph — lần 1

Công ty trả 70% lương của công việc trong thời gian thử việc. Có đúng luật không?

Thời gian: 50156.002 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Với mức lương của công việc đó như bạn nêu, tỷ lệ 70% thấp hơn tối thiểu 85%, nên không đáp ứng quy định về tiền lương thử việc. Điều 26 (18/VBHN-VPQH): “Điều 26. Tiền lương thử việc Tiền lương của người lao động trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó.” [prov_38ac614a6bf6bd16]
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Lương thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc.

## TV002 — without_graph — lần 1

Tôi và công ty thỏa thuận thử việc bằng 85% lương của công việc. Mức này có đáp ứng mức tối thiểu theo Bộ luật Lao động không?

Thời gian: 5089.658 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 26: tiền lương trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó. Với mức lương của công việc đó như bạn nêu, tỷ lệ 85% đáp ứng mức tối thiểu 85%; điều này không xác nhận các điều kiện thử việc khác. [prov_38ac614a6bf6bd16]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. 85% bằng mức tối thiểu mà Điều 26 quy định cho lương thử việc.

## TV003 — without_graph — lần 1

Mức lương của vị trí là 8 triệu đồng/tháng. Lương thử việc thấp nhất theo luật là bao nhiêu?

Thời gian: 9803.194 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 26: tiền lương trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó. [prov_38ac614a6bf6bd16]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất 6,8 triệu đồng/tháng, tương ứng 85% của 8 triệu đồng/tháng.

## TV004 — without_graph — lần 1

Vị trí chuyên môn đòi hỏi trình độ cao đẳng, công ty thử việc 90 ngày có vượt giới hạn không?

Thời gian: 27184.803 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Với công việc yêu cầu chuyên môn kỹ thuật từ cao đẳng trở lên, thời gian thử việc không quá 60 ngày, nếu không thuộc nhóm quản lý doanh nghiệp theo trường hợp riêng.

## TV005 — without_graph — lần 1

Công việc yêu cầu trình độ cao đẳng và không phải chức danh quản lý, thử việc 45 ngày có nằm trong mức tối đa không?

Thời gian: 6898.583 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Về thời gian: với nhóm công việc bạn nêu, thử việc 45 ngày không vượt mức tối đa 60 ngày. Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Thời gian thử việc tối đa trong trường hợp này là 60 ngày.

## TV006 — without_graph — lần 1

Công việc yêu cầu trình độ trung cấp và không phải quản lý doanh nghiệp, thử việc 45 ngày có phù hợp không?

Thời gian: 11073.914 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Với nhóm công việc yêu cầu trình độ trung cấp hoặc nhân viên nghiệp vụ, thời gian thử việc tối đa là 30 ngày.

## TV007 — without_graph — lần 1

Vị trí công nhân kỹ thuật thông thường bị thử việc 31 ngày. Có vượt giới hạn luật định không?

Thời gian: 15496.039 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Về thời gian: với nhóm công việc bạn nêu, thử việc 31 ngày vượt mức tối đa 30 ngày. Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Đối với công việc công nhân kỹ thuật, giới hạn thử việc là 30 ngày.

## TV008 — without_graph — lần 1

Một công việc phổ thông không thuộc các nhóm yêu cầu trình độ nêu trong Điều 25, thử việc sáu ngày làm việc có đúng mức tối đa không?

Thời gian: 12180.704 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Có. Nhóm công việc khác có thời gian thử việc tối đa 06 ngày làm việc.

## TV009 — without_graph — lần 1

Lao động làm công việc phổ thông thông thường bị thử việc mười ngày làm việc. Có đúng không?

Thời gian: 19928.34 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Giới hạn đối với nhóm công việc khác là sáu ngày làm việc.

## TV010 — without_graph — lần 1

Giám đốc doanh nghiệp thuộc diện người quản lý doanh nghiệp theo Điều 25 được yêu cầu thử việc 200 ngày. Có đúng không?

Thời gian: 87402.165 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Không. Đối với công việc của người quản lý doanh nghiệp thuộc quy định này, thời gian thử việc không quá 180 ngày.

## TV011 — without_graph — lần 1

Công ty yêu cầu tôi thử việc hai lần cho cùng một công việc sau khi lần đầu đã kết thúc. Có phù hợp không?

Thời gian: 20284.923 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Theo Điều 25 của Bộ luật Lao động, thời gian thử việc chỉ được thực hiện một lần đối với một công việc. [prov_0d899ce39134b1a5]
- Sau khi kết thúc thời gian thử việc, nếu đạt yêu cầu, người sử dụng lao động phải tiếp tục thực hiện hợp đồng lao động hoặc giao kết hợp đồng lao động mới. [prov_e984d1788a357c56]
- Trong thời gian thử việc, mỗi bên có quyền hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường. [prov_9e2818163eeff843]
- Do đó, việc công ty yêu cầu bạn thử việc hai lần cho cùng một công việc là không phù hợp với quy định pháp luật. [prov_0d899ce39134b1a5] [prov_e984d1788a357c56] [prov_9e2818163eeff843]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Đối với một công việc, luật chỉ cho phép thử việc một lần.

## TV012 — without_graph — lần 1

Tôi ký hợp đồng lao động thời hạn 20 ngày. Công ty có được áp dụng thử việc không?

Thời gian: 40313.788 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Không áp dụng thử việc đối với người lao động giao kết hợp đồng lao động có thời hạn dưới một tháng.

## TV013 — without_graph — lần 1

Đang trong thời gian thử việc, tôi muốn nghỉ ngay mà không báo trước. Theo Bộ luật Lao động có phải bồi thường không?

Thời gian: 59144.005 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Chưa xác minh được ý nghĩa pháp lý của câu trả lời. Không thể coi việc có trích dẫn là đủ để kết luận.

**Đáp án tham khảo (DRAFT):** Trong thời gian thử việc, mỗi bên được hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường về việc hủy bỏ đó.

## TV014 — without_graph — lần 1

Tôi thử việc đạt yêu cầu và trước đó ký hợp đồng thử việc riêng. Công ty phải làm gì sau khi hết thử việc?

Thời gian: 42934.888 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khi kết thúc thời gian thử việc, công ty có nghĩa vụ thông báo kết quả thử việc cho người lao động. [prov_e984d1788a357c56]
- Đối với trường hợp đã ký hợp đồng thử việc riêng, nếu người lao động đạt yêu cầu, công ty phải thực hiện giao kết hợp đồng lao động với người lao động. [prov_e984d1788a357c56]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải thông báo kết quả và giao kết hợp đồng lao động nếu đã giao kết hợp đồng thử việc riêng.

## TL001 — without_graph — lần 1

Cùng công việc có giá trị như nhau, công ty trả lương thấp hơn chỉ vì người lao động là nữ. Có đúng luật không?

Thời gian: 114501.184 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Dịch vụ kiểm tra câu trả lời tạm thời không phản hồi hoặc gặp lỗi. Chưa thể trả kết luận đã xác minh; vui lòng thử lại sau.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động phải bảo đảm trả lương bình đẳng, không phân biệt giới tính với công việc có giá trị như nhau.

## TL002 — without_graph — lần 1

Doanh nghiệp trả lương theo công việc thấp hơn mức lương tối thiểu áp dụng. Có được không?

Thời gian: 49696.805 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Mức lương theo công việc hoặc chức danh không được thấp hơn mức lương tối thiểu áp dụng.

## TL003 — without_graph — lần 1

Người lao động hưởng lương tháng có thể được trả mỗi tháng một lần không?

Thời gian: 4620.42 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người hưởng lương theo tháng được trả một tháng một lần hoặc nửa tháng một lần, theo thời điểm có tính chu kỳ đã thỏa thuận.

## TL004 — without_graph — lần 1

Người hưởng lương tháng được công ty trả hai tháng một lần, không có thỏa thuận đặc biệt nào. Có đúng kỳ hạn luật định không?

Thời gian: 4658.418 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Lương tháng phải được trả một tháng một lần hoặc nửa tháng một lần.

## TL005 — without_graph — lần 1

Công ty vì bất khả kháng, đã khắc phục nhưng vẫn chậm trả lương 20 ngày. Có phải đền bù do chậm trả không?

Thời gian: 9333.328 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Khi trả lương chậm từ 15 ngày trở lên trong trường hợp này, công ty phải đền bù ít nhất theo mức lãi được Điều 97 khoản 4 quy định.

## TL006 — without_graph — lần 1

Do bất khả kháng đã tìm mọi biện pháp khắc phục, doanh nghiệp vẫn trả lương trễ 40 ngày. Có vượt giới hạn không?

Thời gian: 9328.886 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngay cả trong tình huống bất khả kháng theo khoản 4 Điều 97, thời hạn trả lương chậm không được quá 30 ngày.

## TL007 — without_graph — lần 1

Công ty trả lương qua ngân hàng và bắt nhân viên chịu phí mở tài khoản, phí chuyển lương. Ai phải trả?

Thời gian: 4632.773 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải trả các loại phí liên quan đến mở tài khoản và chuyển tiền lương khi trả lương qua tài khoản cá nhân.

## TL008 — without_graph — lần 1

Tiền lương trả qua tài khoản ngân hàng đứng tên người lao động có được không?

Thời gian: 4664.767 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Tiền lương có thể trả bằng tiền mặt hoặc qua tài khoản cá nhân của người lao động được mở tại ngân hàng.

## TL009 — without_graph — lần 1

Doanh nghiệp ép nhân viên dùng lương mua sản phẩm do chính công ty bán. Có phù hợp không?

Thời gian: 4679.187 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được ép buộc người lao động dùng tiền lương để mua hàng hóa, dịch vụ do họ chỉ định.

## TL010 — without_graph — lần 1

Tiền lương làm thêm vào ngày làm việc bình thường tối thiểu bằng bao nhiêu phần trăm mức lương giờ tương ứng?

Thời gian: 4655.369 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất bằng 150% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL011 — without_graph — lần 1

Tôi làm thêm vào ngày nghỉ hằng tuần, mức lương làm thêm thấp nhất là bao nhiêu phần trăm?

Thời gian: 9.158 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 200% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL012 — without_graph — lần 1

Tôi làm thêm vào ngày lễ, tết: mức lương làm thêm tối thiểu theo Điều 98 là bao nhiêu?

Thời gian: 9.604 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 300% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm; đối với người hưởng lương ngày, mức này chưa kể tiền lương ngày lễ được hưởng.

## TL013 — without_graph — lần 1

Làm việc vào ban đêm nhưng không làm thêm giờ, có khoản trả thêm tối thiểu bao nhiêu?

Thời gian: 56022.729 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được trả thêm ít nhất 30% tiền lương tính theo đơn giá hoặc tiền lương thực trả của ngày làm việc bình thường.

## TL014 — without_graph — lần 1

Nhà máy phải ngừng việc hoàn toàn do lỗi của người sử dụng lao động. Người lao động có được trả đủ lương hợp đồng không?

Thời gian: 4662.88 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu ngừng việc do lỗi của người sử dụng lao động thì người lao động được trả đủ tiền lương theo hợp đồng lao động.

## TG001 — without_graph — lần 1

Theo chế độ thời giờ làm việc bình thường tính theo ngày, luật giới hạn tối đa mấy giờ một ngày và một tuần?

Thời gian: 4676.823 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 8 giờ/ngày và 48 giờ/tuần theo chế độ làm việc bình thường.

## TG002 — without_graph — lần 1

Nếu doanh nghiệp tổ chức giờ làm việc bình thường theo tuần, có thể bố trí 10 giờ một ngày và tối đa 48 giờ một tuần không?

Thời gian: 4653.479 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có, nếu áp dụng chế độ tính theo tuần, thông báo cho người lao động và không vượt 10 giờ/ngày, 48 giờ/tuần.

## TG003 — without_graph — lần 1

Nhà nước có khuyến khích doanh nghiệp áp dụng tuần làm việc 40 giờ không?

Thời gian: 4644.468 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Bộ luật khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ.

## TG004 — without_graph — lần 1

Thời gian từ 23 giờ đến 5 giờ sáng hôm sau có thuộc giờ làm việc ban đêm không?

Thời gian: 4696.299 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau.

## TG005 — without_graph — lần 1

Trong trường hợp làm thêm giờ thông thường, công ty có cần được sự đồng ý của người lao động không?

Thời gian: 4622.978 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người sử dụng lao động phải có sự đồng ý của người lao động, trừ những trường hợp làm thêm đặc biệt do luật quy định.

## TG006 — without_graph — lần 1

Theo cách bố trí giờ làm việc bình thường theo ngày, giới hạn làm thêm trong ngày theo Điều 107 là bao nhiêu?

Thời gian: 4682.29 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Số giờ làm thêm không quá 50% số giờ làm việc bình thường trong ngày, đồng thời phải tuân thủ các giới hạn tháng và năm tương ứng.

## TG007 — without_graph — lần 1

Trong trường hợp làm thêm giờ thông thường, một người lao động được làm thêm tối đa bao nhiêu giờ trong một tháng?

Thời gian: 4646.857 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 40 giờ làm thêm trong một tháng.

## TG008 — without_graph — lần 1

Theo giới hạn làm thêm giờ chung, một năm được làm thêm tối đa bao nhiêu giờ nếu không thuộc ngoại lệ?

Thời gian: 4676.593 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 200 giờ trong một năm, trừ các trường hợp luật cho phép tối đa 300 giờ.

## TG009 — without_graph — lần 1

Trong một số ngành sản xuất như dệt may xuất khẩu, luật có cho phép làm thêm đến 300 giờ một năm không?

Thời gian: 4656.991 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được bố trí làm thêm đến 300 giờ trong năm khi thuộc trường hợp được luật cho phép và đáp ứng các điều kiện liên quan.

## TG010 — without_graph — lần 1

Một người làm ban đêm theo thời giờ bình thường 7 giờ trong ngày được nghỉ giữa giờ ít nhất bao lâu?

Thời gian: 4670.829 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 45 phút liên tục khi làm việc ban đêm từ 6 giờ trở lên trong ngày.

## TG011 — without_graph — lần 1

Người làm việc ban ngày 8 giờ/ngày được nghỉ giữa giờ ít nhất bao nhiêu phút?

Thời gian: 4665.393 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 30 phút liên tục khi thời gian làm việc trong ngày từ 6 giờ trở lên.

## TG012 — without_graph — lần 1

Người làm ca liên tục 8 giờ/ngày, thời gian nghỉ giữa giờ có được tính vào giờ làm việc không?

Thời gian: 4664.047 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu làm việc theo ca liên tục từ 6 giờ trở lên, thời gian nghỉ giữa giờ được tính vào giờ làm việc.

## TG013 — without_graph — lần 1

Người lao động làm việc theo ca cần được nghỉ ít nhất bao nhiêu giờ trước khi chuyển sang ca khác?

Thời gian: 4666.11 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 12 giờ trước khi chuyển sang ca làm việc khác.

## TG014 — without_graph — lần 1

Trong thiên tai cần bảo vệ ngay tính mạng con người, doanh nghiệp có thể yêu cầu làm thêm giờ đặc biệt vượt giới hạn thông thường không?

Thời gian: 610.488 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Có thể yêu cầu làm thêm giờ trong trường hợp bảo vệ tính mạng và khắc phục hậu quả theo Điều 108, trừ khi có nguy cơ ảnh hưởng tính mạng, sức khỏe của người lao động theo pháp luật an toàn, vệ sinh lao động.

## NP001 — without_graph — lần 1

Theo quy định chung, một tuần người lao động phải được nghỉ ít nhất bao nhiêu giờ liên tục?

Thời gian: 4643.406 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 24 giờ liên tục trong một tuần.

## NP002 — without_graph — lần 1

Doanh nghiệp có thể chọn ngày nghỉ hằng tuần là thứ Hai thay vì Chủ nhật không?

Thời gian: 4671.895 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngày nghỉ hằng tuần có thể là Chủ nhật hoặc một ngày khác xác định trong tuần và phải ghi trong nội quy lao động.

## NP003 — without_graph — lần 1

Nếu ngày nghỉ hằng tuần trùng ngày nghỉ lễ, người lao động có được nghỉ bù không?

Thời gian: 4667.479 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ bù ngày nghỉ hằng tuần vào ngày làm việc kế tiếp.

## NP004 — without_graph — lần 1

Do chu kỳ lao động đặc biệt không thể bố trí nghỉ hằng tuần, người lao động phải được nghỉ bình quân ít nhất bao nhiêu ngày một tháng?

Thời gian: 4679.354 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải bảo đảm bình quân một tháng ít nhất bốn ngày nghỉ trong trường hợp đặc biệt đó.

## NP005 — without_graph — lần 1

Người làm đủ 12 tháng trong điều kiện bình thường có bao nhiêu ngày nghỉ hằng năm hưởng nguyên lương?

Thời gian: 4662.645 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 12 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP006 — without_graph — lần 1

Người làm nghề nặng nhọc, độc hại, nguy hiểm đủ 12 tháng được nghỉ phép năm bao nhiêu ngày?

Thời gian: 4663.863 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 14 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP007 — without_graph — lần 1

Người làm nghề đặc biệt nặng nhọc, độc hại, nguy hiểm đủ 12 tháng có bao nhiêu ngày phép năm?

Thời gian: 4718.269 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 16 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP008 — without_graph — lần 1

Người làm việc chưa đủ 12 tháng có được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc không?

Thời gian: 32686.432 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Số ngày nghỉ hằng năm được tính theo tỷ lệ tương ứng với số tháng làm việc.

## NP009 — without_graph — lần 1

Tôi đã làm việc đủ 5 năm cho cùng một công ty. Số ngày nghỉ hằng năm có tăng thêm không?

Thời gian: 4679.498 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Cứ đủ 5 năm làm việc cho một người sử dụng lao động, số ngày nghỉ hằng năm tăng thêm một ngày.

## NP010 — without_graph — lần 1

Người lao động thôi việc mà chưa sử dụng hết ngày nghỉ hằng năm có được thanh toán ngày chưa nghỉ không?

Thời gian: 25.551 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Khi thôi việc hoặc bị mất việc mà còn ngày nghỉ hằng năm chưa nghỉ, người sử dụng lao động phải thanh toán tiền lương cho những ngày đó.

## NP011 — without_graph — lần 1

Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa mấy năm một lần?

Thời gian: 10183.959 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể thỏa thuận nghỉ gộp tối đa ba năm một lần.

## NP012 — without_graph — lần 1

Tôi kết hôn thì được nghỉ việc riêng hưởng nguyên lương mấy ngày?

Thời gian: 4689.42 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ ba ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP013 — without_graph — lần 1

Con đẻ của tôi kết hôn thì tôi được nghỉ hưởng nguyên lương bao nhiêu ngày?

Thời gian: 4700.959 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ một ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP014 — without_graph — lần 1

Anh ruột của tôi qua đời, tôi có quyền nghỉ một ngày không hưởng lương không?

Thời gian: 4642.255 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ một ngày không hưởng lương và phải thông báo cho người sử dụng lao động.

## CD001 — without_graph — lần 1

Tôi làm theo hợp đồng không xác định thời hạn, muốn đơn phương nghỉ việc bình thường. Cần báo trước tối thiểu bao nhiêu ngày?

Thời gian: 11703.818 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường phải báo trước ít nhất 45 ngày, trừ ngành nghề/công việc đặc thù hoặc trường hợp được nghỉ không báo trước.

## CD002 — without_graph — lần 1

Tôi có hợp đồng xác định thời hạn 24 tháng, muốn đơn phương nghỉ việc trong trường hợp thông thường. Phải báo trước bao lâu?

Thời gian: 30701.814 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 30 ngày, trừ trường hợp được quyền nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD003 — without_graph — lần 1

Tôi có hợp đồng xác định thời hạn 9 tháng, đơn phương nghỉ bình thường. Phải báo trước tối thiểu mấy ngày?

Thời gian: 4688.679 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 3 ngày làm việc, trừ trường hợp được nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD004 — without_graph — lần 1

Công ty không trả lương đúng hạn mà không thuộc ngoại lệ bất khả kháng của khoản 4 Điều 97. Tôi có quyền nghỉ mà không báo trước không?

Thời gian: 18.287 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động được đơn phương chấm dứt hợp đồng không cần báo trước nếu không được trả đủ hoặc đúng hạn, trừ trường hợp ngoại lệ quy định ở khoản 4 Điều 97.

## CD005 — without_graph — lần 1

Người lao động bị người sử dụng lao động đánh đập, nhục mạ thì có thể chấm dứt hợp đồng không cần báo trước không?

Thời gian: 30515.641 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Đây là trường hợp người lao động được đơn phương chấm dứt hợp đồng mà không cần báo trước.

## CD006 — without_graph — lần 1

Công ty không bố trí đúng công việc đã thỏa thuận và không thuộc trường hợp điều chuyển hợp pháp ở Điều 29. Người lao động có được nghỉ không cần báo trước không?

Thời gian: 19.415 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có quyền đơn phương chấm dứt không cần báo trước nếu không được bố trí đúng công việc, địa điểm hoặc điều kiện đã thỏa thuận, trừ ngoại lệ Điều 29.

## CD007 — without_graph — lần 1

Doanh nghiệp có thể đơn phương cho thôi việc do nhân viên thường xuyên không hoàn thành công việc theo tiêu chí đánh giá hợp lệ không?

Thời gian: 21197.027 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể, nếu thật sự thường xuyên không hoàn thành công việc theo tiêu chí quy chế đánh giá hợp lệ, bảo đảm nghĩa vụ tham khảo ý kiến khi áp dụng và thời hạn báo trước tương ứng.

## CD008 — without_graph — lần 1

Người lao động tự ý bỏ việc không lý do chính đáng trong 5 ngày làm việc liên tục. Công ty có cần báo trước khi đơn phương chấm dứt không?

Thời gian: 4644.4 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Đây là trường hợp người sử dụng lao động có thể đơn phương chấm dứt không cần báo trước theo Điều 36.

## CD009 — without_graph — lần 1

Người lao động nữ đang mang thai, công ty có được đơn phương chấm dứt hợp đồng chỉ vì lý do mang thai không?

Thời gian: 18.493 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Bộ luật Lao động có quy định bảo vệ người lao động nữ mang thai, không cho người sử dụng lao động thực hiện quyền đơn phương chấm dứt trong trường hợp này.

## CD010 — without_graph — lần 1

Người lao động đang nghỉ phép năm đã được công ty chấp thuận, công ty có được đơn phương chấm dứt hợp đồng trong thời gian nghỉ đó không?

Thời gian: 19.256 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được thực hiện quyền đơn phương chấm dứt khi người lao động đang nghỉ hằng năm, nghỉ việc riêng hoặc nghỉ khác được chấp thuận.

## CD011 — without_graph — lần 1

Người lao động tự ý đơn phương nghỉ việc trái luật và không báo trước. Người đó có thể phải bồi thường nửa tháng lương cộng phần tiền của ngày không báo trước không?

Thời gian: 19.576 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Trường hợp đơn phương chấm dứt trái pháp luật, người lao động phải bồi thường nửa tháng tiền lương theo hợp đồng và khoản tương ứng các ngày không báo trước.

## CD012 — without_graph — lần 1

Công ty đơn phương chấm dứt hợp đồng trái pháp luật và người lao động muốn quay lại làm việc. Công ty có nghĩa vụ bồi thường ít nhất hai tháng tiền lương không?

Thời gian: 44.217 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Theo khoản 1 Điều 41, công ty phải nhận lại người lao động, thanh toán quyền lợi liên quan trong thời gian không làm việc và trả thêm ít nhất hai tháng lương hợp đồng.

## CD013 — without_graph — lần 1

Sau khi chấm dứt hợp đồng thông thường, thời hạn thanh toán các khoản quyền lợi liên quan là bao nhiêu ngày làm việc?

Thời gian: 4663.452 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường hai bên phải thanh toán đầy đủ trong 14 ngày làm việc kể từ ngày chấm dứt hợp đồng.

## CD014 — without_graph — lần 1

Trong trường hợp thuộc ngoại lệ luật định khi doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng có thể kéo dài tối đa bao nhiêu ngày?

Thời gian: 4655.283 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể kéo dài nhưng không quá 30 ngày nếu đúng trường hợp ngoại lệ thuộc Điều 48 khoản 1.

## CD015 — without_graph — lần 1

Người lao động làm việc thường xuyên 8 tháng rồi chấm dứt hợp đồng: có đương nhiên đủ điều kiện thời gian để nhận trợ cấp thôi việc theo Điều 46 không?

Thời gian: 659.187 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Chưa. Điều 46 đặt điều kiện đã làm việc thường xuyên từ đủ 12 tháng trở lên và phải thuộc trường hợp chấm dứt quy định, có các trường hợp loại trừ.

## TD001 — without_graph — lần 1

Tôi muốn nghỉ việc, tôi phải báo trước cho công ty bao nhiêu ngày?

Thời gian: 14542.627 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, thời hạn hợp đồng, ngành nghề đặc thù và lý do nghỉ để xác định thời hạn báo trước hoặc quyền nghỉ không báo trước.

## TD002 — without_graph — lần 1

Tôi được tuyển vào công ty, công ty có thể thử việc tôi tối đa bao lâu?

Thời gian: 4655.361 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết chức danh và trình độ chuyên môn kỹ thuật thực sự cần cho công việc; các nhóm có giới hạn thử việc khác nhau.

## TD003 — without_graph — lần 1

Công ty trả tôi lương 6 triệu đồng một tháng, như vậy có thấp hơn mức lương tối thiểu không?

Thời gian: 4636.974 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết địa bàn vùng lương tối thiểu, kỳ áp dụng và cách trả lương; chỉ với số 6 triệu đồng chưa đủ để kết luận.

## TD004 — without_graph — lần 1

Tôi đang làm tại một doanh nghiệp, năm nay tôi được nghỉ bao nhiêu ngày phép năm?

Thời gian: 4691.849 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thời gian làm việc, nhóm điều kiện công việc và thâm niên để tính số ngày nghỉ hằng năm.

## TD005 — without_graph — lần 1

Sếp yêu cầu tăng ca nhưng tôi chưa rõ số giờ. Như vậy có vi phạm giới hạn làm thêm giờ không?

Thời gian: 482.299 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết giờ làm bình thường, số giờ làm thêm trong ngày/tháng/năm, sự đồng ý và có thuộc ngoại lệ hay không.

## TD006 — without_graph — lần 1

Tôi tự ý nghỉ việc, công ty yêu cầu bồi thường. Tôi có phải bồi thường không?

Thời gian: 12636.662 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, lý do nghỉ, thời hạn báo trước và tình tiết được nghỉ không cần báo trước để xác định có nghỉ trái luật hay không.

## TD007 — without_graph — lần 1

Sau khi nghỉ việc tôi có được nhận trợ cấp thôi việc hay không?

Thời gian: 16.762 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Cần biết cách chấm dứt hợp đồng, thời gian làm việc, thời gian đóng bảo hiểm thất nghiệp và các khoản trợ cấp đã nhận.

## TD008 — without_graph — lần 1

Công ty điều chuyển tôi sang công việc khác 40 ngày. Như vậy có hợp pháp không?

Thời gian: 4676.063 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần làm rõ lý do điều chuyển, số ngày chuyển cộng dồn trong năm, thông báo trước và chế độ lương khi chuyển.

## TD009 — without_graph — lần 1

Ngày nghỉ lễ tôi được hưởng khoản tiền làm thêm như thế nào?

Thời gian: 4692.313 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết bạn có thực tế làm việc vào ngày lễ không, có làm thêm giờ hay không và hình thức trả lương để áp dụng đúng mức.

## TD010 — without_graph — lần 1

Tôi tăng ca vào thứ Bảy thì có được trả ít nhất 200% không?

Thời gian: 4632.685 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thứ Bảy có phải ngày nghỉ hằng tuần theo nội quy/lịch của bạn hay là ngày làm việc bình thường.

## TD011 — without_graph — lần 1

Lương thử việc của tôi là 6 triệu đồng mỗi tháng, có hợp pháp không?

Thời gian: 4652.038 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết mức lương của chính công việc đó khi làm chính thức; lương thử việc phải từ 85% mức ấy trở lên.

## TD012 — without_graph — lần 1

Công ty và tôi chỉ thỏa thuận miệng để làm việc; hợp đồng như vậy hợp lệ không?

Thời gian: 4649.774 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thời hạn hợp đồng và liệu công việc có thuộc trường hợp bắt buộc phải lập văn bản hay không.

## TD013 — without_graph — lần 1

Vào ngày 01/01/2028, mức lương tối thiểu vùng I chính xác là bao nhiêu?

Thời gian: 4688.349 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Chưa thể khẳng định mức cụ thể cho ngày 01/01/2028 từ bộ dữ liệu được chốt năm 2026. Cần văn bản quy định mức lương tối thiểu có hiệu lực tại thời điểm tương lai này.

## TD014 — without_graph — lần 1

Năm 2028 lịch nghỉ Tết Âm lịch chính thức theo quyết định của Thủ tướng sẽ rơi vào những ngày dương lịch nào?

Thời gian: 33961.62 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Nội dung nguồn có lỗi đọc chữ đáng ngờ. Cần đối chiếu bản gốc trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không đủ căn cứ để nêu lịch nghỉ cụ thể của năm 2028 từ bộ dữ liệu đang chốt năm 2026; lịch thực hiện phải đối chiếu quyết định chính thức áp dụng cho năm đó.

## TD015 — without_graph — lần 1

Năm 2029 Chính phủ sẽ nâng số giờ làm thêm tối đa thông thường lên mức nào, nếu có thay đổi luật?

Thời gian: 4667.156 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không có căn cứ pháp lý đã ban hành và được xác minh về một sửa đổi giả định năm 2029; không thể đưa ra con số chính xác chỉ dựa vào dự báo.

## HD001 — without_reranker — lần 1

Tôi ký hợp đồng làm việc 20 ngày cho công việc thông thường bằng lời nói, có được không?

Thời gian: 235.681 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể giao kết bằng lời nói với hợp đồng dưới một tháng, nếu không thuộc các trường hợp luật bắt buộc lập bằng văn bản.

## HD002 — without_reranker — lần 1

Công ty ký hợp đồng lao động 6 tháng với tôi nhưng chỉ thỏa thuận miệng. Như vậy có đúng hình thức không?

Thời gian: 4671.136 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng 6 tháng phải được giao kết bằng văn bản, có thể bằng thông điệp dữ liệu điện tử đủ điều kiện pháp luật.

## HD003 — without_reranker — lần 1

Hợp đồng lao động ký qua phương tiện điện tử dưới dạng thông điệp dữ liệu có giá trị như hợp đồng giấy không?

Thời gian: 4659.442 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng lao động điện tử bằng thông điệp dữ liệu theo pháp luật giao dịch điện tử có giá trị như hợp đồng bằng văn bản.

## HD004 — without_reranker — lần 1

Khi ký hợp đồng lao động bằng văn bản, người lao động có phải giữ một bản không?

Thời gian: 4671.47 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng bằng văn bản được làm thành hai bản, mỗi bên giữ một bản.

## HD005 — without_reranker — lần 1

Công ty gọi giấy tờ của tôi là hợp đồng cộng tác viên nhưng tôi được trả lương và chịu quản lý giờ làm. Có thể là hợp đồng lao động không?

Thời gian: 4702.301 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được coi là hợp đồng lao động dù tên gọi khác, nếu có việc làm có trả công và chịu sự quản lý, điều hành, giám sát của một bên.

## HD006 — without_reranker — lần 1

Doanh nghiệp muốn ký hợp đồng lao động xác định thời hạn 48 tháng với nhân viên thông thường. Có hợp lệ về thời hạn không?

Thời gian: 4608.186 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng lao động xác định thời hạn theo quy định chung có thời hạn tối đa 36 tháng.

## HD007 — without_reranker — lần 1

Hợp đồng 24 tháng đã hết hạn, tôi tiếp tục làm việc 40 ngày và hai bên không ký hợp đồng mới. Hợp đồng trở thành loại nào?

Thời gian: 4653.672 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Hợp đồng xác định thời hạn đã giao kết chuyển thành hợp đồng lao động không xác định thời hạn sau khi quá 30 ngày mà hai bên không ký mới.

## HD008 — without_reranker — lần 1

Hợp đồng có thời hạn vừa hết 10 ngày, tôi vẫn làm mà chưa ký mới. Quyền lợi được áp dụng theo hợp đồng cũ không?

Thời gian: 4679.414 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Trong thời hạn 30 ngày từ khi hợp đồng hết hạn, nếu chưa ký mới thì quyền, nghĩa vụ và lợi ích vẫn theo hợp đồng đã giao kết.

## HD009 — without_reranker — lần 1

Tôi đã ký hai hợp đồng xác định thời hạn liên tiếp ở công ty tư nhân thông thường. Nếu tiếp tục làm việc, có thể ký lần thứ ba cùng loại không?

Thời gian: 4686.953 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường không. Sau lần ký thêm một hợp đồng xác định thời hạn, nếu tiếp tục làm việc thì phải ký hợp đồng không xác định thời hạn, trừ trường hợp luật quy định ngoại lệ.

## HD010 — without_reranker — lần 1

Tôi có thể cùng lúc ký hợp đồng lao động với hai công ty khác nhau không?

Thời gian: 4651.702 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người lao động có thể giao kết nhiều hợp đồng với nhiều người sử dụng lao động nếu bảo đảm thực hiện đầy đủ nội dung đã ký.

## HD011 — without_reranker — lần 1

Công ty giữ bản chính bằng đại học của tôi để bảo đảm tôi không nghỉ việc. Có được không?

Thời gian: 5009.105 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được giữ bản chính giấy tờ tùy thân, văn bằng hoặc chứng chỉ của người lao động.

## HD012 — without_reranker — lần 1

Công ty yêu cầu tôi đặt cọc hai triệu đồng để nhận việc theo hợp đồng lao động. Có được không?

Thời gian: 4644.054 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được yêu cầu bảo đảm bằng tiền hoặc tài sản khác để thực hiện hợp đồng lao động.

## HD013 — without_reranker — lần 1

Công ty muốn gia hạn thời hạn hợp đồng bằng phụ lục thay vì ký hợp đồng lao động mới. Có được không?

Thời gian: 4673.304 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Phụ lục có thể sửa đổi, bổ sung một số nội dung nhưng không được sửa đổi thời hạn hợp đồng lao động.

## HD014 — without_reranker — lần 1

Nhân viên tiếp cận bí mật công nghệ thì doanh nghiệp có được thỏa thuận riêng bằng văn bản về bảo mật không?

Thời gian: 4662.653 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hai bên có thể thỏa thuận bằng văn bản về phạm vi, thời hạn, quyền lợi và bồi thường khi vi phạm bảo mật, nếu công việc trực tiếp liên quan bí mật kinh doanh/công nghệ.

## TV001 — without_reranker — lần 1

Công ty trả 70% lương của công việc trong thời gian thử việc. Có đúng luật không?

Thời gian: 4652.263 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Lương thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc.

## TV002 — without_reranker — lần 1

Tôi và công ty thỏa thuận thử việc bằng 85% lương của công việc. Mức này có đáp ứng mức tối thiểu theo Bộ luật Lao động không?

Thời gian: 4668.846 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. 85% bằng mức tối thiểu mà Điều 26 quy định cho lương thử việc.

## TV003 — without_reranker — lần 1

Mức lương của vị trí là 8 triệu đồng/tháng. Lương thử việc thấp nhất theo luật là bao nhiêu?

Thời gian: 4671.933 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 6,8 triệu đồng/tháng, tương ứng 85% của 8 triệu đồng/tháng.

## TV004 — without_reranker — lần 1

Vị trí chuyên môn đòi hỏi trình độ cao đẳng, công ty thử việc 90 ngày có vượt giới hạn không?

Thời gian: 4644.28 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Với công việc yêu cầu chuyên môn kỹ thuật từ cao đẳng trở lên, thời gian thử việc không quá 60 ngày, nếu không thuộc nhóm quản lý doanh nghiệp theo trường hợp riêng.

## TV005 — without_reranker — lần 1

Công việc yêu cầu trình độ cao đẳng và không phải chức danh quản lý, thử việc 45 ngày có nằm trong mức tối đa không?

Thời gian: 4669.95 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Thời gian thử việc tối đa trong trường hợp này là 60 ngày.

## TV006 — without_reranker — lần 1

Công việc yêu cầu trình độ trung cấp và không phải quản lý doanh nghiệp, thử việc 45 ngày có phù hợp không?

Thời gian: 4654.122 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Với nhóm công việc yêu cầu trình độ trung cấp hoặc nhân viên nghiệp vụ, thời gian thử việc tối đa là 30 ngày.

## TV007 — without_reranker — lần 1

Vị trí công nhân kỹ thuật thông thường bị thử việc 31 ngày. Có vượt giới hạn luật định không?

Thời gian: 4663.768 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Đối với công việc công nhân kỹ thuật, giới hạn thử việc là 30 ngày.

## TV008 — without_reranker — lần 1

Một công việc phổ thông không thuộc các nhóm yêu cầu trình độ nêu trong Điều 25, thử việc sáu ngày làm việc có đúng mức tối đa không?

Thời gian: 4665.457 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nhóm công việc khác có thời gian thử việc tối đa 06 ngày làm việc.

## TV009 — without_reranker — lần 1

Lao động làm công việc phổ thông thông thường bị thử việc mười ngày làm việc. Có đúng không?

Thời gian: 4673.931 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Giới hạn đối với nhóm công việc khác là sáu ngày làm việc.

## TV010 — without_reranker — lần 1

Giám đốc doanh nghiệp thuộc diện người quản lý doanh nghiệp theo Điều 25 được yêu cầu thử việc 200 ngày. Có đúng không?

Thời gian: 4646.7 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Đối với công việc của người quản lý doanh nghiệp thuộc quy định này, thời gian thử việc không quá 180 ngày.

## TV011 — without_reranker — lần 1

Công ty yêu cầu tôi thử việc hai lần cho cùng một công việc sau khi lần đầu đã kết thúc. Có phù hợp không?

Thời gian: 14161.321 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Đối với một công việc, luật chỉ cho phép thử việc một lần.

## TV012 — without_reranker — lần 1

Tôi ký hợp đồng lao động thời hạn 20 ngày. Công ty có được áp dụng thử việc không?

Thời gian: 4654.149 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Không áp dụng thử việc đối với người lao động giao kết hợp đồng lao động có thời hạn dưới một tháng.

## TV013 — without_reranker — lần 1

Đang trong thời gian thử việc, tôi muốn nghỉ ngay mà không báo trước. Theo Bộ luật Lao động có phải bồi thường không?

Thời gian: 48672.753 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Trong thời gian thử việc, mỗi bên được hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường về việc hủy bỏ đó.

## TV014 — without_reranker — lần 1

Tôi thử việc đạt yêu cầu và trước đó ký hợp đồng thử việc riêng. Công ty phải làm gì sau khi hết thử việc?

Thời gian: 14960.624 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải thông báo kết quả và giao kết hợp đồng lao động nếu đã giao kết hợp đồng thử việc riêng.

## TL001 — without_reranker — lần 1

Cùng công việc có giá trị như nhau, công ty trả lương thấp hơn chỉ vì người lao động là nữ. Có đúng luật không?

Thời gian: 4666.068 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động phải bảo đảm trả lương bình đẳng, không phân biệt giới tính với công việc có giá trị như nhau.

## TL002 — without_reranker — lần 1

Doanh nghiệp trả lương theo công việc thấp hơn mức lương tối thiểu áp dụng. Có được không?

Thời gian: 4663.446 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Mức lương theo công việc hoặc chức danh không được thấp hơn mức lương tối thiểu áp dụng.

## TL003 — without_reranker — lần 1

Người lao động hưởng lương tháng có thể được trả mỗi tháng một lần không?

Thời gian: 4682.217 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người hưởng lương theo tháng được trả một tháng một lần hoặc nửa tháng một lần, theo thời điểm có tính chu kỳ đã thỏa thuận.

## TL004 — without_reranker — lần 1

Người hưởng lương tháng được công ty trả hai tháng một lần, không có thỏa thuận đặc biệt nào. Có đúng kỳ hạn luật định không?

Thời gian: 5161.459 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Lương tháng phải được trả một tháng một lần hoặc nửa tháng một lần.

## TL005 — without_reranker — lần 1

Công ty vì bất khả kháng, đã khắc phục nhưng vẫn chậm trả lương 20 ngày. Có phải đền bù do chậm trả không?

Thời gian: 4641.135 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Khi trả lương chậm từ 15 ngày trở lên trong trường hợp này, công ty phải đền bù ít nhất theo mức lãi được Điều 97 khoản 4 quy định.

## TL006 — without_reranker — lần 1

Do bất khả kháng đã tìm mọi biện pháp khắc phục, doanh nghiệp vẫn trả lương trễ 40 ngày. Có vượt giới hạn không?

Thời gian: 4194.322 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngay cả trong tình huống bất khả kháng theo khoản 4 Điều 97, thời hạn trả lương chậm không được quá 30 ngày.

## TL007 — without_reranker — lần 1

Công ty trả lương qua ngân hàng và bắt nhân viên chịu phí mở tài khoản, phí chuyển lương. Ai phải trả?

Thời gian: 63723.324 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải trả các loại phí liên quan đến mở tài khoản và chuyển tiền lương khi trả lương qua tài khoản cá nhân.

## TL008 — without_reranker — lần 1

Tiền lương trả qua tài khoản ngân hàng đứng tên người lao động có được không?

Thời gian: 4650.575 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Tiền lương có thể trả bằng tiền mặt hoặc qua tài khoản cá nhân của người lao động được mở tại ngân hàng.

## TL009 — without_reranker — lần 1

Doanh nghiệp ép nhân viên dùng lương mua sản phẩm do chính công ty bán. Có phù hợp không?

Thời gian: 4689.92 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được ép buộc người lao động dùng tiền lương để mua hàng hóa, dịch vụ do họ chỉ định.

## TL010 — without_reranker — lần 1

Tiền lương làm thêm vào ngày làm việc bình thường tối thiểu bằng bao nhiêu phần trăm mức lương giờ tương ứng?

Thời gian: 4624.408 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất bằng 150% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL011 — without_reranker — lần 1

Tôi làm thêm vào ngày nghỉ hằng tuần, mức lương làm thêm thấp nhất là bao nhiêu phần trăm?

Thời gian: 8.965 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 200% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL012 — without_reranker — lần 1

Tôi làm thêm vào ngày lễ, tết: mức lương làm thêm tối thiểu theo Điều 98 là bao nhiêu?

Thời gian: 9.789 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 300% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm; đối với người hưởng lương ngày, mức này chưa kể tiền lương ngày lễ được hưởng.

## TL013 — without_reranker — lần 1

Làm việc vào ban đêm nhưng không làm thêm giờ, có khoản trả thêm tối thiểu bao nhiêu?

Thời gian: 39981.988 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được trả thêm ít nhất 30% tiền lương tính theo đơn giá hoặc tiền lương thực trả của ngày làm việc bình thường.

## TL014 — without_reranker — lần 1

Nhà máy phải ngừng việc hoàn toàn do lỗi của người sử dụng lao động. Người lao động có được trả đủ lương hợp đồng không?

Thời gian: 9351.691 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu ngừng việc do lỗi của người sử dụng lao động thì người lao động được trả đủ tiền lương theo hợp đồng lao động.

## TG001 — without_reranker — lần 1

Theo chế độ thời giờ làm việc bình thường tính theo ngày, luật giới hạn tối đa mấy giờ một ngày và một tuần?

Thời gian: 4644.523 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 8 giờ/ngày và 48 giờ/tuần theo chế độ làm việc bình thường.

## TG002 — without_reranker — lần 1

Nếu doanh nghiệp tổ chức giờ làm việc bình thường theo tuần, có thể bố trí 10 giờ một ngày và tối đa 48 giờ một tuần không?

Thời gian: 4669.589 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có, nếu áp dụng chế độ tính theo tuần, thông báo cho người lao động và không vượt 10 giờ/ngày, 48 giờ/tuần.

## TG003 — without_reranker — lần 1

Nhà nước có khuyến khích doanh nghiệp áp dụng tuần làm việc 40 giờ không?

Thời gian: 5169.221 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Bộ luật khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ.

## TG004 — without_reranker — lần 1

Thời gian từ 23 giờ đến 5 giờ sáng hôm sau có thuộc giờ làm việc ban đêm không?

Thời gian: 4157.111 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau.

## TG005 — without_reranker — lần 1

Trong trường hợp làm thêm giờ thông thường, công ty có cần được sự đồng ý của người lao động không?

Thời gian: 4644.678 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người sử dụng lao động phải có sự đồng ý của người lao động, trừ những trường hợp làm thêm đặc biệt do luật quy định.

## TG006 — without_reranker — lần 1

Theo cách bố trí giờ làm việc bình thường theo ngày, giới hạn làm thêm trong ngày theo Điều 107 là bao nhiêu?

Thời gian: 4652.896 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Số giờ làm thêm không quá 50% số giờ làm việc bình thường trong ngày, đồng thời phải tuân thủ các giới hạn tháng và năm tương ứng.

## TG007 — without_reranker — lần 1

Trong trường hợp làm thêm giờ thông thường, một người lao động được làm thêm tối đa bao nhiêu giờ trong một tháng?

Thời gian: 4688.429 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 40 giờ làm thêm trong một tháng.

## TG008 — without_reranker — lần 1

Theo giới hạn làm thêm giờ chung, một năm được làm thêm tối đa bao nhiêu giờ nếu không thuộc ngoại lệ?

Thời gian: 4650.285 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 200 giờ trong một năm, trừ các trường hợp luật cho phép tối đa 300 giờ.

## TG009 — without_reranker — lần 1

Trong một số ngành sản xuất như dệt may xuất khẩu, luật có cho phép làm thêm đến 300 giờ một năm không?

Thời gian: 4673.613 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được bố trí làm thêm đến 300 giờ trong năm khi thuộc trường hợp được luật cho phép và đáp ứng các điều kiện liên quan.

## TG010 — without_reranker — lần 1

Một người làm ban đêm theo thời giờ bình thường 7 giờ trong ngày được nghỉ giữa giờ ít nhất bao lâu?

Thời gian: 16371.849 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 45 phút liên tục khi làm việc ban đêm từ 6 giờ trở lên trong ngày.

## TG011 — without_reranker — lần 1

Người làm việc ban ngày 8 giờ/ngày được nghỉ giữa giờ ít nhất bao nhiêu phút?

Thời gian: 5218.149 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 30 phút liên tục khi thời gian làm việc trong ngày từ 6 giờ trở lên.

## TG012 — without_reranker — lần 1

Người làm ca liên tục 8 giờ/ngày, thời gian nghỉ giữa giờ có được tính vào giờ làm việc không?

Thời gian: 4100.522 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu làm việc theo ca liên tục từ 6 giờ trở lên, thời gian nghỉ giữa giờ được tính vào giờ làm việc.

## TG013 — without_reranker — lần 1

Người lao động làm việc theo ca cần được nghỉ ít nhất bao nhiêu giờ trước khi chuyển sang ca khác?

Thời gian: 4658.061 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 12 giờ trước khi chuyển sang ca làm việc khác.

## TG014 — without_reranker — lần 1

Trong thiên tai cần bảo vệ ngay tính mạng con người, doanh nghiệp có thể yêu cầu làm thêm giờ đặc biệt vượt giới hạn thông thường không?

Thời gian: 5316.178 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể yêu cầu làm thêm giờ trong trường hợp bảo vệ tính mạng và khắc phục hậu quả theo Điều 108, trừ khi có nguy cơ ảnh hưởng tính mạng, sức khỏe của người lao động theo pháp luật an toàn, vệ sinh lao động.

## NP001 — without_reranker — lần 1

Theo quy định chung, một tuần người lao động phải được nghỉ ít nhất bao nhiêu giờ liên tục?

Thời gian: 4045.097 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 24 giờ liên tục trong một tuần.

## NP002 — without_reranker — lần 1

Doanh nghiệp có thể chọn ngày nghỉ hằng tuần là thứ Hai thay vì Chủ nhật không?

Thời gian: 4630.588 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngày nghỉ hằng tuần có thể là Chủ nhật hoặc một ngày khác xác định trong tuần và phải ghi trong nội quy lao động.

## NP003 — without_reranker — lần 1

Nếu ngày nghỉ hằng tuần trùng ngày nghỉ lễ, người lao động có được nghỉ bù không?

Thời gian: 4664.841 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ bù ngày nghỉ hằng tuần vào ngày làm việc kế tiếp.

## NP004 — without_reranker — lần 1

Do chu kỳ lao động đặc biệt không thể bố trí nghỉ hằng tuần, người lao động phải được nghỉ bình quân ít nhất bao nhiêu ngày một tháng?

Thời gian: 5225.234 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải bảo đảm bình quân một tháng ít nhất bốn ngày nghỉ trong trường hợp đặc biệt đó.

## NP005 — without_reranker — lần 1

Người làm đủ 12 tháng trong điều kiện bình thường có bao nhiêu ngày nghỉ hằng năm hưởng nguyên lương?

Thời gian: 4101.275 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 12 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP006 — without_reranker — lần 1

Người làm nghề nặng nhọc, độc hại, nguy hiểm đủ 12 tháng được nghỉ phép năm bao nhiêu ngày?

Thời gian: 4685.776 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 14 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP007 — without_reranker — lần 1

Người làm nghề đặc biệt nặng nhọc, độc hại, nguy hiểm đủ 12 tháng có bao nhiêu ngày phép năm?

Thời gian: 5166.297 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 16 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP008 — without_reranker — lần 1

Người làm việc chưa đủ 12 tháng có được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc không?

Thời gian: 19563.199 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc chưa đủ 12 tháng được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc. [prov_1c22b690b094979c]
- Số ngày nghỉ hằng năm của người lao động làm việc chưa đủ 12 tháng được tính bằng cách lấy số ngày nghỉ hằng năm cộng với số ngày được nghỉ tăng thêm theo thâm niên (nếu có), chia cho 12 tháng, nhân với số tháng làm việc thực tế trong năm. [prov_5dfc4b46a7ec5560]
- Người lao động làm việc đủ 12 tháng được nghỉ hằng năm 12 ngày làm việc đối với người làm công việc trong điều kiện bình thường. [prov_4634c77f09c25fc0]
- Người lao động làm việc đủ 12 tháng được nghỉ hằng năm 14 ngày làm việc đối với người lao động chưa thành niên, lao động là người khuyết tật, người làm nghề, công việc nặng nhọc, độc hại, nguy hiểm. [prov_42bcd849a0a30ecd]
- Người lao động làm việc đủ 12 tháng được nghỉ hằng năm 16 ngày làm việc đối với người làm nghề, công việc đặc biệt nặng nhọc, độc hại, nguy hiểm. [prov_1fab8366c4ce639b]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Số ngày nghỉ hằng năm được tính theo tỷ lệ tương ứng với số tháng làm việc.

## NP009 — without_reranker — lần 1

Tôi đã làm việc đủ 5 năm cho cùng một công ty. Số ngày nghỉ hằng năm có tăng thêm không?

Thời gian: 4678.835 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Cứ đủ 5 năm làm việc cho một người sử dụng lao động, số ngày nghỉ hằng năm tăng thêm một ngày.

## NP010 — without_reranker — lần 1

Người lao động thôi việc mà chưa sử dụng hết ngày nghỉ hằng năm có được thanh toán ngày chưa nghỉ không?

Thời gian: 24.48 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Khi thôi việc hoặc bị mất việc mà còn ngày nghỉ hằng năm chưa nghỉ, người sử dụng lao động phải thanh toán tiền lương cho những ngày đó.

## NP011 — without_reranker — lần 1

Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa mấy năm một lần?

Thời gian: 42198.132 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể thỏa thuận nghỉ gộp tối đa ba năm một lần.

## NP012 — without_reranker — lần 1

Tôi kết hôn thì được nghỉ việc riêng hưởng nguyên lương mấy ngày?

Thời gian: 5179.446 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ ba ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP013 — without_reranker — lần 1

Con đẻ của tôi kết hôn thì tôi được nghỉ hưởng nguyên lương bao nhiêu ngày?

Thời gian: 4144.451 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ một ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP014 — without_reranker — lần 1

Anh ruột của tôi qua đời, tôi có quyền nghỉ một ngày không hưởng lương không?

Thời gian: 4642.276 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ một ngày không hưởng lương và phải thông báo cho người sử dụng lao động.

## CD001 — without_reranker — lần 1

Tôi làm theo hợp đồng không xác định thời hạn, muốn đơn phương nghỉ việc bình thường. Cần báo trước tối thiểu bao nhiêu ngày?

Thời gian: 11423.533 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường phải báo trước ít nhất 45 ngày, trừ ngành nghề/công việc đặc thù hoặc trường hợp được nghỉ không báo trước.

## CD002 — without_reranker — lần 1

Tôi có hợp đồng xác định thời hạn 24 tháng, muốn đơn phương nghỉ việc trong trường hợp thông thường. Phải báo trước bao lâu?

Thời gian: 34301.752 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 30 ngày, trừ trường hợp được quyền nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD003 — without_reranker — lần 1

Tôi có hợp đồng xác định thời hạn 9 tháng, đơn phương nghỉ bình thường. Phải báo trước tối thiểu mấy ngày?

Thời gian: 4666.461 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 3 ngày làm việc, trừ trường hợp được nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD004 — without_reranker — lần 1

Công ty không trả lương đúng hạn mà không thuộc ngoại lệ bất khả kháng của khoản 4 Điều 97. Tôi có quyền nghỉ mà không báo trước không?

Thời gian: 20.57 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động được đơn phương chấm dứt hợp đồng không cần báo trước nếu không được trả đủ hoặc đúng hạn, trừ trường hợp ngoại lệ quy định ở khoản 4 Điều 97.

## CD005 — without_reranker — lần 1

Người lao động bị người sử dụng lao động đánh đập, nhục mạ thì có thể chấm dứt hợp đồng không cần báo trước không?

Thời gian: 30658.245 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Đây là trường hợp người lao động được đơn phương chấm dứt hợp đồng mà không cần báo trước.

## CD006 — without_reranker — lần 1

Công ty không bố trí đúng công việc đã thỏa thuận và không thuộc trường hợp điều chuyển hợp pháp ở Điều 29. Người lao động có được nghỉ không cần báo trước không?

Thời gian: 20.125 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có quyền đơn phương chấm dứt không cần báo trước nếu không được bố trí đúng công việc, địa điểm hoặc điều kiện đã thỏa thuận, trừ ngoại lệ Điều 29.

## CD007 — without_reranker — lần 1

Doanh nghiệp có thể đơn phương cho thôi việc do nhân viên thường xuyên không hoàn thành công việc theo tiêu chí đánh giá hợp lệ không?

Thời gian: 4680.994 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể, nếu thật sự thường xuyên không hoàn thành công việc theo tiêu chí quy chế đánh giá hợp lệ, bảo đảm nghĩa vụ tham khảo ý kiến khi áp dụng và thời hạn báo trước tương ứng.

## CD008 — without_reranker — lần 1

Người lao động tự ý bỏ việc không lý do chính đáng trong 5 ngày làm việc liên tục. Công ty có cần báo trước khi đơn phương chấm dứt không?

Thời gian: 4661.976 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Đây là trường hợp người sử dụng lao động có thể đơn phương chấm dứt không cần báo trước theo Điều 36.

## CD009 — without_reranker — lần 1

Người lao động nữ đang mang thai, công ty có được đơn phương chấm dứt hợp đồng chỉ vì lý do mang thai không?

Thời gian: 18.342 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Bộ luật Lao động có quy định bảo vệ người lao động nữ mang thai, không cho người sử dụng lao động thực hiện quyền đơn phương chấm dứt trong trường hợp này.

## CD010 — without_reranker — lần 1

Người lao động đang nghỉ phép năm đã được công ty chấp thuận, công ty có được đơn phương chấm dứt hợp đồng trong thời gian nghỉ đó không?

Thời gian: 19.948 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được thực hiện quyền đơn phương chấm dứt khi người lao động đang nghỉ hằng năm, nghỉ việc riêng hoặc nghỉ khác được chấp thuận.

## CD011 — without_reranker — lần 1

Người lao động tự ý đơn phương nghỉ việc trái luật và không báo trước. Người đó có thể phải bồi thường nửa tháng lương cộng phần tiền của ngày không báo trước không?

Thời gian: 22.011 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Trường hợp đơn phương chấm dứt trái pháp luật, người lao động phải bồi thường nửa tháng tiền lương theo hợp đồng và khoản tương ứng các ngày không báo trước.

## CD012 — without_reranker — lần 1

Công ty đơn phương chấm dứt hợp đồng trái pháp luật và người lao động muốn quay lại làm việc. Công ty có nghĩa vụ bồi thường ít nhất hai tháng tiền lương không?

Thời gian: 27.124 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Theo khoản 1 Điều 41, công ty phải nhận lại người lao động, thanh toán quyền lợi liên quan trong thời gian không làm việc và trả thêm ít nhất hai tháng lương hợp đồng.

## CD013 — without_reranker — lần 1

Sau khi chấm dứt hợp đồng thông thường, thời hạn thanh toán các khoản quyền lợi liên quan là bao nhiêu ngày làm việc?

Thời gian: 5213.11 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường hai bên phải thanh toán đầy đủ trong 14 ngày làm việc kể từ ngày chấm dứt hợp đồng.

## CD014 — without_reranker — lần 1

Trong trường hợp thuộc ngoại lệ luật định khi doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng có thể kéo dài tối đa bao nhiêu ngày?

Thời gian: 4624.459 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể kéo dài nhưng không quá 30 ngày nếu đúng trường hợp ngoại lệ thuộc Điều 48 khoản 1.

## CD015 — without_reranker — lần 1

Người lao động làm việc thường xuyên 8 tháng rồi chấm dứt hợp đồng: có đương nhiên đủ điều kiện thời gian để nhận trợ cấp thôi việc theo Điều 46 không?

Thời gian: 126.476 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Chưa. Điều 46 đặt điều kiện đã làm việc thường xuyên từ đủ 12 tháng trở lên và phải thuộc trường hợp chấm dứt quy định, có các trường hợp loại trừ.

## TD001 — without_reranker — lần 1

Tôi muốn nghỉ việc, tôi phải báo trước cho công ty bao nhiêu ngày?

Thời gian: 14433.524 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, thời hạn hợp đồng, ngành nghề đặc thù và lý do nghỉ để xác định thời hạn báo trước hoặc quyền nghỉ không báo trước.

## TD002 — without_reranker — lần 1

Tôi được tuyển vào công ty, công ty có thể thử việc tôi tối đa bao lâu?

Thời gian: 4686.64 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết chức danh và trình độ chuyên môn kỹ thuật thực sự cần cho công việc; các nhóm có giới hạn thử việc khác nhau.

## TD003 — without_reranker — lần 1

Công ty trả tôi lương 6 triệu đồng một tháng, như vậy có thấp hơn mức lương tối thiểu không?

Thời gian: 5169.697 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết địa bàn vùng lương tối thiểu, kỳ áp dụng và cách trả lương; chỉ với số 6 triệu đồng chưa đủ để kết luận.

## TD004 — without_reranker — lần 1

Tôi đang làm tại một doanh nghiệp, năm nay tôi được nghỉ bao nhiêu ngày phép năm?

Thời gian: 4657.254 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thời gian làm việc, nhóm điều kiện công việc và thâm niên để tính số ngày nghỉ hằng năm.

## TD005 — without_reranker — lần 1

Sếp yêu cầu tăng ca nhưng tôi chưa rõ số giờ. Như vậy có vi phạm giới hạn làm thêm giờ không?

Thời gian: 127.105 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết giờ làm bình thường, số giờ làm thêm trong ngày/tháng/năm, sự đồng ý và có thuộc ngoại lệ hay không.

## TD006 — without_reranker — lần 1

Tôi tự ý nghỉ việc, công ty yêu cầu bồi thường. Tôi có phải bồi thường không?

Thời gian: 15848.616 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, lý do nghỉ, thời hạn báo trước và tình tiết được nghỉ không cần báo trước để xác định có nghỉ trái luật hay không.

## TD007 — without_reranker — lần 1

Sau khi nghỉ việc tôi có được nhận trợ cấp thôi việc hay không?

Thời gian: 18.582 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Cần biết cách chấm dứt hợp đồng, thời gian làm việc, thời gian đóng bảo hiểm thất nghiệp và các khoản trợ cấp đã nhận.

## TD008 — without_reranker — lần 1

Công ty điều chuyển tôi sang công việc khác 40 ngày. Như vậy có hợp pháp không?

Thời gian: 5201.524 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần làm rõ lý do điều chuyển, số ngày chuyển cộng dồn trong năm, thông báo trước và chế độ lương khi chuyển.

## TD009 — without_reranker — lần 1

Ngày nghỉ lễ tôi được hưởng khoản tiền làm thêm như thế nào?

Thời gian: 4141.157 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết bạn có thực tế làm việc vào ngày lễ không, có làm thêm giờ hay không và hình thức trả lương để áp dụng đúng mức.

## TD010 — without_reranker — lần 1

Tôi tăng ca vào thứ Bảy thì có được trả ít nhất 200% không?

Thời gian: 4648.067 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thứ Bảy có phải ngày nghỉ hằng tuần theo nội quy/lịch của bạn hay là ngày làm việc bình thường.

## TD011 — without_reranker — lần 1

Lương thử việc của tôi là 6 triệu đồng mỗi tháng, có hợp pháp không?

Thời gian: 5206.603 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết mức lương của chính công việc đó khi làm chính thức; lương thử việc phải từ 85% mức ấy trở lên.

## TD012 — without_reranker — lần 1

Công ty và tôi chỉ thỏa thuận miệng để làm việc; hợp đồng như vậy hợp lệ không?

Thời gian: 4121.347 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thời hạn hợp đồng và liệu công việc có thuộc trường hợp bắt buộc phải lập văn bản hay không.

## TD013 — without_reranker — lần 1

Vào ngày 01/01/2028, mức lương tối thiểu vùng I chính xác là bao nhiêu?

Thời gian: 4666.398 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Chưa thể khẳng định mức cụ thể cho ngày 01/01/2028 từ bộ dữ liệu được chốt năm 2026. Cần văn bản quy định mức lương tối thiểu có hiệu lực tại thời điểm tương lai này.

## TD014 — without_reranker — lần 1

Năm 2028 lịch nghỉ Tết Âm lịch chính thức theo quyết định của Thủ tướng sẽ rơi vào những ngày dương lịch nào?

Thời gian: 33894.345 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Nội dung nguồn có lỗi đọc chữ đáng ngờ. Cần đối chiếu bản gốc trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không đủ căn cứ để nêu lịch nghỉ cụ thể của năm 2028 từ bộ dữ liệu đang chốt năm 2026; lịch thực hiện phải đối chiếu quyết định chính thức áp dụng cho năm đó.

## TD015 — without_reranker — lần 1

Năm 2029 Chính phủ sẽ nâng số giờ làm thêm tối đa thông thường lên mức nào, nếu có thay đổi luật?

Thời gian: 4645.274 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không có căn cứ pháp lý đã ban hành và được xác minh về một sửa đổi giả định năm 2029; không thể đưa ra con số chính xác chỉ dựa vào dự báo.

## HD001 — without_auditor — lần 1

Tôi ký hợp đồng làm việc 20 ngày cho công việc thông thường bằng lời nói, có được không?

Thời gian: 236.423 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể giao kết bằng lời nói với hợp đồng dưới một tháng, nếu không thuộc các trường hợp luật bắt buộc lập bằng văn bản.

## HD002 — without_auditor — lần 1

Công ty ký hợp đồng lao động 6 tháng với tôi nhưng chỉ thỏa thuận miệng. Như vậy có đúng hình thức không?

Thời gian: 4713.561 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng 6 tháng phải được giao kết bằng văn bản, có thể bằng thông điệp dữ liệu điện tử đủ điều kiện pháp luật.

## HD003 — without_auditor — lần 1

Hợp đồng lao động ký qua phương tiện điện tử dưới dạng thông điệp dữ liệu có giá trị như hợp đồng giấy không?

Thời gian: 5133.928 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng lao động điện tử bằng thông điệp dữ liệu theo pháp luật giao dịch điện tử có giá trị như hợp đồng bằng văn bản.

## HD004 — without_auditor — lần 1

Khi ký hợp đồng lao động bằng văn bản, người lao động có phải giữ một bản không?

Thời gian: 4157.911 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng bằng văn bản được làm thành hai bản, mỗi bên giữ một bản.

## HD005 — without_auditor — lần 1

Công ty gọi giấy tờ của tôi là hợp đồng cộng tác viên nhưng tôi được trả lương và chịu quản lý giờ làm. Có thể là hợp đồng lao động không?

Thời gian: 4650.059 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được coi là hợp đồng lao động dù tên gọi khác, nếu có việc làm có trả công và chịu sự quản lý, điều hành, giám sát của một bên.

## HD006 — without_auditor — lần 1

Doanh nghiệp muốn ký hợp đồng lao động xác định thời hạn 48 tháng với nhân viên thông thường. Có hợp lệ về thời hạn không?

Thời gian: 4661.301 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng lao động xác định thời hạn theo quy định chung có thời hạn tối đa 36 tháng.

## HD007 — without_auditor — lần 1

Hợp đồng 24 tháng đã hết hạn, tôi tiếp tục làm việc 40 ngày và hai bên không ký hợp đồng mới. Hợp đồng trở thành loại nào?

Thời gian: 4652.918 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Hợp đồng xác định thời hạn đã giao kết chuyển thành hợp đồng lao động không xác định thời hạn sau khi quá 30 ngày mà hai bên không ký mới.

## HD008 — without_auditor — lần 1

Hợp đồng có thời hạn vừa hết 10 ngày, tôi vẫn làm mà chưa ký mới. Quyền lợi được áp dụng theo hợp đồng cũ không?

Thời gian: 4698.755 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Trong thời hạn 30 ngày từ khi hợp đồng hết hạn, nếu chưa ký mới thì quyền, nghĩa vụ và lợi ích vẫn theo hợp đồng đã giao kết.

## HD009 — without_auditor — lần 1

Tôi đã ký hai hợp đồng xác định thời hạn liên tiếp ở công ty tư nhân thông thường. Nếu tiếp tục làm việc, có thể ký lần thứ ba cùng loại không?

Thời gian: 5192.608 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường không. Sau lần ký thêm một hợp đồng xác định thời hạn, nếu tiếp tục làm việc thì phải ký hợp đồng không xác định thời hạn, trừ trường hợp luật quy định ngoại lệ.

## HD010 — without_auditor — lần 1

Tôi có thể cùng lúc ký hợp đồng lao động với hai công ty khác nhau không?

Thời gian: 4606.627 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người lao động có thể giao kết nhiều hợp đồng với nhiều người sử dụng lao động nếu bảo đảm thực hiện đầy đủ nội dung đã ký.

## HD011 — without_auditor — lần 1

Công ty giữ bản chính bằng đại học của tôi để bảo đảm tôi không nghỉ việc. Có được không?

Thời gian: 8608.065 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được giữ bản chính giấy tờ tùy thân, văn bằng hoặc chứng chỉ của người lao động.

## HD012 — without_auditor — lần 1

Công ty yêu cầu tôi đặt cọc hai triệu đồng để nhận việc theo hợp đồng lao động. Có được không?

Thời gian: 442.679 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được yêu cầu bảo đảm bằng tiền hoặc tài sản khác để thực hiện hợp đồng lao động.

## HD013 — without_auditor — lần 1

Công ty muốn gia hạn thời hạn hợp đồng bằng phụ lục thay vì ký hợp đồng lao động mới. Có được không?

Thời gian: 6009.542 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Phụ lục có thể sửa đổi, bổ sung một số nội dung nhưng không được sửa đổi thời hạn hợp đồng lao động.

## HD014 — without_auditor — lần 1

Nhân viên tiếp cận bí mật công nghệ thì doanh nghiệp có được thỏa thuận riêng bằng văn bản về bảo mật không?

Thời gian: 3326.189 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hai bên có thể thỏa thuận bằng văn bản về phạm vi, thời hạn, quyền lợi và bồi thường khi vi phạm bảo mật, nếu công việc trực tiếp liên quan bí mật kinh doanh/công nghệ.

## TV001 — without_auditor — lần 1

Công ty trả 70% lương của công việc trong thời gian thử việc. Có đúng luật không?

Thời gian: 691.702 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Lương thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc.

## TV002 — without_auditor — lần 1

Tôi và công ty thỏa thuận thử việc bằng 85% lương của công việc. Mức này có đáp ứng mức tối thiểu theo Bộ luật Lao động không?

Thời gian: 521.258 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. 85% bằng mức tối thiểu mà Điều 26 quy định cho lương thử việc.

## TV003 — without_auditor — lần 1

Mức lương của vị trí là 8 triệu đồng/tháng. Lương thử việc thấp nhất theo luật là bao nhiêu?

Thời gian: 448.322 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Ít nhất 6,8 triệu đồng/tháng, tương ứng 85% của 8 triệu đồng/tháng.

## TV004 — without_auditor — lần 1

Vị trí chuyên môn đòi hỏi trình độ cao đẳng, công ty thử việc 90 ngày có vượt giới hạn không?

Thời gian: 810.41 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Với công việc yêu cầu chuyên môn kỹ thuật từ cao đẳng trở lên, thời gian thử việc không quá 60 ngày, nếu không thuộc nhóm quản lý doanh nghiệp theo trường hợp riêng.

## TV005 — without_auditor — lần 1

Công việc yêu cầu trình độ cao đẳng và không phải chức danh quản lý, thử việc 45 ngày có nằm trong mức tối đa không?

Thời gian: 723.926 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Thời gian thử việc tối đa trong trường hợp này là 60 ngày.

## TV006 — without_auditor — lần 1

Công việc yêu cầu trình độ trung cấp và không phải quản lý doanh nghiệp, thử việc 45 ngày có phù hợp không?

Thời gian: 476.961 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Với nhóm công việc yêu cầu trình độ trung cấp hoặc nhân viên nghiệp vụ, thời gian thử việc tối đa là 30 ngày.

## TV007 — without_auditor — lần 1

Vị trí công nhân kỹ thuật thông thường bị thử việc 31 ngày. Có vượt giới hạn luật định không?

Thời gian: 875.318 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Đối với công việc công nhân kỹ thuật, giới hạn thử việc là 30 ngày.

## TV008 — without_auditor — lần 1

Một công việc phổ thông không thuộc các nhóm yêu cầu trình độ nêu trong Điều 25, thử việc sáu ngày làm việc có đúng mức tối đa không?

Thời gian: 412.01 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Nhóm công việc khác có thời gian thử việc tối đa 06 ngày làm việc.

## TV009 — without_auditor — lần 1

Lao động làm công việc phổ thông thông thường bị thử việc mười ngày làm việc. Có đúng không?

Thời gian: 4686.811 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Giới hạn đối với nhóm công việc khác là sáu ngày làm việc.

## TV010 — without_auditor — lần 1

Giám đốc doanh nghiệp thuộc diện người quản lý doanh nghiệp theo Điều 25 được yêu cầu thử việc 200 ngày. Có đúng không?

Thời gian: 473.799 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Đối với công việc của người quản lý doanh nghiệp thuộc quy định này, thời gian thử việc không quá 180 ngày.

## TV011 — without_auditor — lần 1

Công ty yêu cầu tôi thử việc hai lần cho cùng một công việc sau khi lần đầu đã kết thúc. Có phù hợp không?

Thời gian: 441.299 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Đối với một công việc, luật chỉ cho phép thử việc một lần.

## TV012 — without_auditor — lần 1

Tôi ký hợp đồng lao động thời hạn 20 ngày. Công ty có được áp dụng thử việc không?

Thời gian: 427.976 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không. Không áp dụng thử việc đối với người lao động giao kết hợp đồng lao động có thời hạn dưới một tháng.

## TV013 — without_auditor — lần 1

Đang trong thời gian thử việc, tôi muốn nghỉ ngay mà không báo trước. Theo Bộ luật Lao động có phải bồi thường không?

Thời gian: 633.025 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Trong thời gian thử việc, mỗi bên được hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường về việc hủy bỏ đó.

## TV014 — without_auditor — lần 1

Tôi thử việc đạt yêu cầu và trước đó ký hợp đồng thử việc riêng. Công ty phải làm gì sau khi hết thử việc?

Thời gian: 465.672 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải thông báo kết quả và giao kết hợp đồng lao động nếu đã giao kết hợp đồng thử việc riêng.

## TL001 — without_auditor — lần 1

Cùng công việc có giá trị như nhau, công ty trả lương thấp hơn chỉ vì người lao động là nữ. Có đúng luật không?

Thời gian: 4694.354 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động phải bảo đảm trả lương bình đẳng, không phân biệt giới tính với công việc có giá trị như nhau.

## TL002 — without_auditor — lần 1

Doanh nghiệp trả lương theo công việc thấp hơn mức lương tối thiểu áp dụng. Có được không?

Thời gian: 4639.151 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Mức lương theo công việc hoặc chức danh không được thấp hơn mức lương tối thiểu áp dụng.

## TL003 — without_auditor — lần 1

Người lao động hưởng lương tháng có thể được trả mỗi tháng một lần không?

Thời gian: 4679.741 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người hưởng lương theo tháng được trả một tháng một lần hoặc nửa tháng một lần, theo thời điểm có tính chu kỳ đã thỏa thuận.

## TL004 — without_auditor — lần 1

Người hưởng lương tháng được công ty trả hai tháng một lần, không có thỏa thuận đặc biệt nào. Có đúng kỳ hạn luật định không?

Thời gian: 5202.86 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Lương tháng phải được trả một tháng một lần hoặc nửa tháng một lần.

## TL005 — without_auditor — lần 1

Công ty vì bất khả kháng, đã khắc phục nhưng vẫn chậm trả lương 20 ngày. Có phải đền bù do chậm trả không?

Thời gian: 4179.995 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Khi trả lương chậm từ 15 ngày trở lên trong trường hợp này, công ty phải đền bù ít nhất theo mức lãi được Điều 97 khoản 4 quy định.

## TL006 — without_auditor — lần 1

Do bất khả kháng đã tìm mọi biện pháp khắc phục, doanh nghiệp vẫn trả lương trễ 40 ngày. Có vượt giới hạn không?

Thời gian: 5116.178 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngay cả trong tình huống bất khả kháng theo khoản 4 Điều 97, thời hạn trả lương chậm không được quá 30 ngày.

## TL007 — without_auditor — lần 1

Công ty trả lương qua ngân hàng và bắt nhân viên chịu phí mở tài khoản, phí chuyển lương. Ai phải trả?

Thời gian: 4130.352 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải trả các loại phí liên quan đến mở tài khoản và chuyển tiền lương khi trả lương qua tài khoản cá nhân.

## TL008 — without_auditor — lần 1

Tiền lương trả qua tài khoản ngân hàng đứng tên người lao động có được không?

Thời gian: 4656.835 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Tiền lương có thể trả bằng tiền mặt hoặc qua tài khoản cá nhân của người lao động được mở tại ngân hàng.

## TL009 — without_auditor — lần 1

Doanh nghiệp ép nhân viên dùng lương mua sản phẩm do chính công ty bán. Có phù hợp không?

Thời gian: 4687.833 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được ép buộc người lao động dùng tiền lương để mua hàng hóa, dịch vụ do họ chỉ định.

## TL010 — without_auditor — lần 1

Tiền lương làm thêm vào ngày làm việc bình thường tối thiểu bằng bao nhiêu phần trăm mức lương giờ tương ứng?

Thời gian: 689.222 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Ít nhất bằng 150% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL011 — without_auditor — lần 1

Tôi làm thêm vào ngày nghỉ hằng tuần, mức lương làm thêm thấp nhất là bao nhiêu phần trăm?

Thời gian: 9.176 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 200% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL012 — without_auditor — lần 1

Tôi làm thêm vào ngày lễ, tết: mức lương làm thêm tối thiểu theo Điều 98 là bao nhiêu?

Thời gian: 9.172 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 300% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm; đối với người hưởng lương ngày, mức này chưa kể tiền lương ngày lễ được hưởng.

## TL013 — without_auditor — lần 1

Làm việc vào ban đêm nhưng không làm thêm giờ, có khoản trả thêm tối thiểu bao nhiêu?

Thời gian: 642.773 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Được trả thêm ít nhất 30% tiền lương tính theo đơn giá hoặc tiền lương thực trả của ngày làm việc bình thường.

## TL014 — without_auditor — lần 1

Nhà máy phải ngừng việc hoàn toàn do lỗi của người sử dụng lao động. Người lao động có được trả đủ lương hợp đồng không?

Thời gian: 5180.725 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu ngừng việc do lỗi của người sử dụng lao động thì người lao động được trả đủ tiền lương theo hợp đồng lao động.

## TG001 — without_auditor — lần 1

Theo chế độ thời giờ làm việc bình thường tính theo ngày, luật giới hạn tối đa mấy giờ một ngày và một tuần?

Thời gian: 4666.263 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 8 giờ/ngày và 48 giờ/tuần theo chế độ làm việc bình thường.

## TG002 — without_auditor — lần 1

Nếu doanh nghiệp tổ chức giờ làm việc bình thường theo tuần, có thể bố trí 10 giờ một ngày và tối đa 48 giờ một tuần không?

Thời gian: 4149.42 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có, nếu áp dụng chế độ tính theo tuần, thông báo cho người lao động và không vượt 10 giờ/ngày, 48 giờ/tuần.

## TG003 — without_auditor — lần 1

Nhà nước có khuyến khích doanh nghiệp áp dụng tuần làm việc 40 giờ không?

Thời gian: 4636.33 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Bộ luật khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ.

## TG004 — without_auditor — lần 1

Thời gian từ 23 giờ đến 5 giờ sáng hôm sau có thuộc giờ làm việc ban đêm không?

Thời gian: 4702.983 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau.

## TG005 — without_auditor — lần 1

Trong trường hợp làm thêm giờ thông thường, công ty có cần được sự đồng ý của người lao động không?

Thời gian: 4639.64 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người sử dụng lao động phải có sự đồng ý của người lao động, trừ những trường hợp làm thêm đặc biệt do luật quy định.

## TG006 — without_auditor — lần 1

Theo cách bố trí giờ làm việc bình thường theo ngày, giới hạn làm thêm trong ngày theo Điều 107 là bao nhiêu?

Thời gian: 4687.34 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Số giờ làm thêm không quá 50% số giờ làm việc bình thường trong ngày, đồng thời phải tuân thủ các giới hạn tháng và năm tương ứng.

## TG007 — without_auditor — lần 1

Trong trường hợp làm thêm giờ thông thường, một người lao động được làm thêm tối đa bao nhiêu giờ trong một tháng?

Thời gian: 725.029 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không quá 40 giờ làm thêm trong một tháng.

## TG008 — without_auditor — lần 1

Theo giới hạn làm thêm giờ chung, một năm được làm thêm tối đa bao nhiêu giờ nếu không thuộc ngoại lệ?

Thời gian: 531.662 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không quá 200 giờ trong một năm, trừ các trường hợp luật cho phép tối đa 300 giờ.

## TG009 — without_auditor — lần 1

Trong một số ngành sản xuất như dệt may xuất khẩu, luật có cho phép làm thêm đến 300 giờ một năm không?

Thời gian: 4633.43 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được bố trí làm thêm đến 300 giờ trong năm khi thuộc trường hợp được luật cho phép và đáp ứng các điều kiện liên quan.

## TG010 — without_auditor — lần 1

Một người làm ban đêm theo thời giờ bình thường 7 giờ trong ngày được nghỉ giữa giờ ít nhất bao lâu?

Thời gian: 4659.817 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 45 phút liên tục khi làm việc ban đêm từ 6 giờ trở lên trong ngày.

## TG011 — without_auditor — lần 1

Người làm việc ban ngày 8 giờ/ngày được nghỉ giữa giờ ít nhất bao nhiêu phút?

Thời gian: 4673.596 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 30 phút liên tục khi thời gian làm việc trong ngày từ 6 giờ trở lên.

## TG012 — without_auditor — lần 1

Người làm ca liên tục 8 giờ/ngày, thời gian nghỉ giữa giờ có được tính vào giờ làm việc không?

Thời gian: 4637.179 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu làm việc theo ca liên tục từ 6 giờ trở lên, thời gian nghỉ giữa giờ được tính vào giờ làm việc.

## TG013 — without_auditor — lần 1

Người lao động làm việc theo ca cần được nghỉ ít nhất bao nhiêu giờ trước khi chuyển sang ca khác?

Thời gian: 4683.989 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 12 giờ trước khi chuyển sang ca làm việc khác.

## TG014 — without_auditor — lần 1

Trong thiên tai cần bảo vệ ngay tính mạng con người, doanh nghiệp có thể yêu cầu làm thêm giờ đặc biệt vượt giới hạn thông thường không?

Thời gian: 658.978 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có thể yêu cầu làm thêm giờ trong trường hợp bảo vệ tính mạng và khắc phục hậu quả theo Điều 108, trừ khi có nguy cơ ảnh hưởng tính mạng, sức khỏe của người lao động theo pháp luật an toàn, vệ sinh lao động.

## NP001 — without_auditor — lần 1

Theo quy định chung, một tuần người lao động phải được nghỉ ít nhất bao nhiêu giờ liên tục?

Thời gian: 4664.69 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 24 giờ liên tục trong một tuần.

## NP002 — without_auditor — lần 1

Doanh nghiệp có thể chọn ngày nghỉ hằng tuần là thứ Hai thay vì Chủ nhật không?

Thời gian: 5205.333 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngày nghỉ hằng tuần có thể là Chủ nhật hoặc một ngày khác xác định trong tuần và phải ghi trong nội quy lao động.

## NP003 — without_auditor — lần 1

Nếu ngày nghỉ hằng tuần trùng ngày nghỉ lễ, người lao động có được nghỉ bù không?

Thời gian: 4630.22 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ bù ngày nghỉ hằng tuần vào ngày làm việc kế tiếp.

## NP004 — without_auditor — lần 1

Do chu kỳ lao động đặc biệt không thể bố trí nghỉ hằng tuần, người lao động phải được nghỉ bình quân ít nhất bao nhiêu ngày một tháng?

Thời gian: 4658.527 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải bảo đảm bình quân một tháng ít nhất bốn ngày nghỉ trong trường hợp đặc biệt đó.

## NP005 — without_auditor — lần 1

Người làm đủ 12 tháng trong điều kiện bình thường có bao nhiêu ngày nghỉ hằng năm hưởng nguyên lương?

Thời gian: 4146.568 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 12 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP006 — without_auditor — lần 1

Người làm nghề nặng nhọc, độc hại, nguy hiểm đủ 12 tháng được nghỉ phép năm bao nhiêu ngày?

Thời gian: 478.02 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** 14 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP007 — without_auditor — lần 1

Người làm nghề đặc biệt nặng nhọc, độc hại, nguy hiểm đủ 12 tháng có bao nhiêu ngày phép năm?

Thời gian: 501.06 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** 16 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP008 — without_auditor — lần 1

Người làm việc chưa đủ 12 tháng có được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc không?

Thời gian: 1078.186 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Số ngày nghỉ hằng năm được tính theo tỷ lệ tương ứng với số tháng làm việc.

## NP009 — without_auditor — lần 1

Tôi đã làm việc đủ 5 năm cho cùng một công ty. Số ngày nghỉ hằng năm có tăng thêm không?

Thời gian: 1030.984 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Cứ đủ 5 năm làm việc cho một người sử dụng lao động, số ngày nghỉ hằng năm tăng thêm một ngày.

## NP010 — without_auditor — lần 1

Người lao động thôi việc mà chưa sử dụng hết ngày nghỉ hằng năm có được thanh toán ngày chưa nghỉ không?

Thời gian: 26.091 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Khi thôi việc hoặc bị mất việc mà còn ngày nghỉ hằng năm chưa nghỉ, người sử dụng lao động phải thanh toán tiền lương cho những ngày đó.

## NP011 — without_auditor — lần 1

Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa mấy năm một lần?

Thời gian: 500.984 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có thể thỏa thuận nghỉ gộp tối đa ba năm một lần.

## NP012 — without_auditor — lần 1

Tôi kết hôn thì được nghỉ việc riêng hưởng nguyên lương mấy ngày?

Thời gian: 5206.943 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ ba ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP013 — without_auditor — lần 1

Con đẻ của tôi kết hôn thì tôi được nghỉ hưởng nguyên lương bao nhiêu ngày?

Thời gian: 4145.429 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ một ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP014 — without_auditor — lần 1

Anh ruột của tôi qua đời, tôi có quyền nghỉ một ngày không hưởng lương không?

Thời gian: 4604.429 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ một ngày không hưởng lương và phải thông báo cho người sử dụng lao động.

## CD001 — without_auditor — lần 1

Tôi làm theo hợp đồng không xác định thời hạn, muốn đơn phương nghỉ việc bình thường. Cần báo trước tối thiểu bao nhiêu ngày?

Thời gian: 460.044 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Thông thường phải báo trước ít nhất 45 ngày, trừ ngành nghề/công việc đặc thù hoặc trường hợp được nghỉ không báo trước.

## CD002 — without_auditor — lần 1

Tôi có hợp đồng xác định thời hạn 24 tháng, muốn đơn phương nghỉ việc trong trường hợp thông thường. Phải báo trước bao lâu?

Thời gian: 411.57 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Ít nhất 30 ngày, trừ trường hợp được quyền nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD003 — without_auditor — lần 1

Tôi có hợp đồng xác định thời hạn 9 tháng, đơn phương nghỉ bình thường. Phải báo trước tối thiểu mấy ngày?

Thời gian: 4660.163 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 3 ngày làm việc, trừ trường hợp được nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD004 — without_auditor — lần 1

Công ty không trả lương đúng hạn mà không thuộc ngoại lệ bất khả kháng của khoản 4 Điều 97. Tôi có quyền nghỉ mà không báo trước không?

Thời gian: 18.426 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động được đơn phương chấm dứt hợp đồng không cần báo trước nếu không được trả đủ hoặc đúng hạn, trừ trường hợp ngoại lệ quy định ở khoản 4 Điều 97.

## CD005 — without_auditor — lần 1

Người lao động bị người sử dụng lao động đánh đập, nhục mạ thì có thể chấm dứt hợp đồng không cần báo trước không?

Thời gian: 933.182 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Đây là trường hợp người lao động được đơn phương chấm dứt hợp đồng mà không cần báo trước.

## CD006 — without_auditor — lần 1

Công ty không bố trí đúng công việc đã thỏa thuận và không thuộc trường hợp điều chuyển hợp pháp ở Điều 29. Người lao động có được nghỉ không cần báo trước không?

Thời gian: 20.527 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có quyền đơn phương chấm dứt không cần báo trước nếu không được bố trí đúng công việc, địa điểm hoặc điều kiện đã thỏa thuận, trừ ngoại lệ Điều 29.

## CD007 — without_auditor — lần 1

Doanh nghiệp có thể đơn phương cho thôi việc do nhân viên thường xuyên không hoàn thành công việc theo tiêu chí đánh giá hợp lệ không?

Thời gian: 4163.549 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể, nếu thật sự thường xuyên không hoàn thành công việc theo tiêu chí quy chế đánh giá hợp lệ, bảo đảm nghĩa vụ tham khảo ý kiến khi áp dụng và thời hạn báo trước tương ứng.

## CD008 — without_auditor — lần 1

Người lao động tự ý bỏ việc không lý do chính đáng trong 5 ngày làm việc liên tục. Công ty có cần báo trước khi đơn phương chấm dứt không?

Thời gian: 4658.472 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Đây là trường hợp người sử dụng lao động có thể đơn phương chấm dứt không cần báo trước theo Điều 36.

## CD009 — without_auditor — lần 1

Người lao động nữ đang mang thai, công ty có được đơn phương chấm dứt hợp đồng chỉ vì lý do mang thai không?

Thời gian: 18.896 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Bộ luật Lao động có quy định bảo vệ người lao động nữ mang thai, không cho người sử dụng lao động thực hiện quyền đơn phương chấm dứt trong trường hợp này.

## CD010 — without_auditor — lần 1

Người lao động đang nghỉ phép năm đã được công ty chấp thuận, công ty có được đơn phương chấm dứt hợp đồng trong thời gian nghỉ đó không?

Thời gian: 19.629 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được thực hiện quyền đơn phương chấm dứt khi người lao động đang nghỉ hằng năm, nghỉ việc riêng hoặc nghỉ khác được chấp thuận.

## CD011 — without_auditor — lần 1

Người lao động tự ý đơn phương nghỉ việc trái luật và không báo trước. Người đó có thể phải bồi thường nửa tháng lương cộng phần tiền của ngày không báo trước không?

Thời gian: 20.15 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Trường hợp đơn phương chấm dứt trái pháp luật, người lao động phải bồi thường nửa tháng tiền lương theo hợp đồng và khoản tương ứng các ngày không báo trước.

## CD012 — without_auditor — lần 1

Công ty đơn phương chấm dứt hợp đồng trái pháp luật và người lao động muốn quay lại làm việc. Công ty có nghĩa vụ bồi thường ít nhất hai tháng tiền lương không?

Thời gian: 29.841 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Theo khoản 1 Điều 41, công ty phải nhận lại người lao động, thanh toán quyền lợi liên quan trong thời gian không làm việc và trả thêm ít nhất hai tháng lương hợp đồng.

## CD013 — without_auditor — lần 1

Sau khi chấm dứt hợp đồng thông thường, thời hạn thanh toán các khoản quyền lợi liên quan là bao nhiêu ngày làm việc?

Thời gian: 4118.344 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường hai bên phải thanh toán đầy đủ trong 14 ngày làm việc kể từ ngày chấm dứt hợp đồng.

## CD014 — without_auditor — lần 1

Trong trường hợp thuộc ngoại lệ luật định khi doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng có thể kéo dài tối đa bao nhiêu ngày?

Thời gian: 4675.098 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể kéo dài nhưng không quá 30 ngày nếu đúng trường hợp ngoại lệ thuộc Điều 48 khoản 1.

## CD015 — without_auditor — lần 1

Người lao động làm việc thường xuyên 8 tháng rồi chấm dứt hợp đồng: có đương nhiên đủ điều kiện thời gian để nhận trợ cấp thôi việc theo Điều 46 không?

Thời gian: 686.467 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Chưa. Điều 46 đặt điều kiện đã làm việc thường xuyên từ đủ 12 tháng trở lên và phải thuộc trường hợp chấm dứt quy định, có các trường hợp loại trừ.

## TD001 — without_auditor — lần 1

Tôi muốn nghỉ việc, tôi phải báo trước cho công ty bao nhiêu ngày?

Thời gian: 883.351 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, thời hạn hợp đồng, ngành nghề đặc thù và lý do nghỉ để xác định thời hạn báo trước hoặc quyền nghỉ không báo trước.

## TD002 — without_auditor — lần 1

Tôi được tuyển vào công ty, công ty có thể thử việc tôi tối đa bao lâu?

Thời gian: 723.631 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết chức danh và trình độ chuyên môn kỹ thuật thực sự cần cho công việc; các nhóm có giới hạn thử việc khác nhau.

## TD003 — without_auditor — lần 1

Công ty trả tôi lương 6 triệu đồng một tháng, như vậy có thấp hơn mức lương tối thiểu không?

Thời gian: 5268.173 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết địa bàn vùng lương tối thiểu, kỳ áp dụng và cách trả lương; chỉ với số 6 triệu đồng chưa đủ để kết luận.

## TD004 — without_auditor — lần 1

Tôi đang làm tại một doanh nghiệp, năm nay tôi được nghỉ bao nhiêu ngày phép năm?

Thời gian: 1049.988 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết thời gian làm việc, nhóm điều kiện công việc và thâm niên để tính số ngày nghỉ hằng năm.

## TD005 — without_auditor — lần 1

Sếp yêu cầu tăng ca nhưng tôi chưa rõ số giờ. Như vậy có vi phạm giới hạn làm thêm giờ không?

Thời gian: 498.158 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết giờ làm bình thường, số giờ làm thêm trong ngày/tháng/năm, sự đồng ý và có thuộc ngoại lệ hay không.

## TD006 — without_auditor — lần 1

Tôi tự ý nghỉ việc, công ty yêu cầu bồi thường. Tôi có phải bồi thường không?

Thời gian: 587.726 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, lý do nghỉ, thời hạn báo trước và tình tiết được nghỉ không cần báo trước để xác định có nghỉ trái luật hay không.

## TD007 — without_auditor — lần 1

Sau khi nghỉ việc tôi có được nhận trợ cấp thôi việc hay không?

Thời gian: 18.116 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Cần biết cách chấm dứt hợp đồng, thời gian làm việc, thời gian đóng bảo hiểm thất nghiệp và các khoản trợ cấp đã nhận.

## TD008 — without_auditor — lần 1

Công ty điều chuyển tôi sang công việc khác 40 ngày. Như vậy có hợp pháp không?

Thời gian: 4674.427 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần làm rõ lý do điều chuyển, số ngày chuyển cộng dồn trong năm, thông báo trước và chế độ lương khi chuyển.

## TD009 — without_auditor — lần 1

Ngày nghỉ lễ tôi được hưởng khoản tiền làm thêm như thế nào?

Thời gian: 4674.384 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết bạn có thực tế làm việc vào ngày lễ không, có làm thêm giờ hay không và hình thức trả lương để áp dụng đúng mức.

## TD010 — without_auditor — lần 1

Tôi tăng ca vào thứ Bảy thì có được trả ít nhất 200% không?

Thời gian: 4629.658 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thứ Bảy có phải ngày nghỉ hằng tuần theo nội quy/lịch của bạn hay là ngày làm việc bình thường.

## TD011 — without_auditor — lần 1

Lương thử việc của tôi là 6 triệu đồng mỗi tháng, có hợp pháp không?

Thời gian: 850.896 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết mức lương của chính công việc đó khi làm chính thức; lương thử việc phải từ 85% mức ấy trở lên.

## TD012 — without_auditor — lần 1

Công ty và tôi chỉ thỏa thuận miệng để làm việc; hợp đồng như vậy hợp lệ không?

Thời gian: 4671.583 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thời hạn hợp đồng và liệu công việc có thuộc trường hợp bắt buộc phải lập văn bản hay không.

## TD013 — without_auditor — lần 1

Vào ngày 01/01/2028, mức lương tối thiểu vùng I chính xác là bao nhiêu?

Thời gian: 4666.105 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Chưa thể khẳng định mức cụ thể cho ngày 01/01/2028 từ bộ dữ liệu được chốt năm 2026. Cần văn bản quy định mức lương tối thiểu có hiệu lực tại thời điểm tương lai này.

## TD014 — without_auditor — lần 1

Năm 2028 lịch nghỉ Tết Âm lịch chính thức theo quyết định của Thủ tướng sẽ rơi vào những ngày dương lịch nào?

Thời gian: 604.527 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không đủ căn cứ để nêu lịch nghỉ cụ thể của năm 2028 từ bộ dữ liệu đang chốt năm 2026; lịch thực hiện phải đối chiếu quyết định chính thức áp dụng cho năm đó.

## TD015 — without_auditor — lần 1

Năm 2029 Chính phủ sẽ nâng số giờ làm thêm tối đa thông thường lên mức nào, nếu có thay đổi luật?

Thời gian: 1036.518 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không có căn cứ pháp lý đã ban hành và được xác minh về một sửa đổi giả định năm 2029; không thể đưa ra con số chính xác chỉ dựa vào dự báo.

## HD001 — without_review — lần 1

Tôi ký hợp đồng làm việc 20 ngày cho công việc thông thường bằng lời nói, có được không?

Thời gian: 241.454 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể giao kết bằng lời nói với hợp đồng dưới một tháng, nếu không thuộc các trường hợp luật bắt buộc lập bằng văn bản.

## HD002 — without_review — lần 1

Công ty ký hợp đồng lao động 6 tháng với tôi nhưng chỉ thỏa thuận miệng. Như vậy có đúng hình thức không?

Thời gian: 4667.989 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng 6 tháng phải được giao kết bằng văn bản, có thể bằng thông điệp dữ liệu điện tử đủ điều kiện pháp luật.

## HD003 — without_review — lần 1

Hợp đồng lao động ký qua phương tiện điện tử dưới dạng thông điệp dữ liệu có giá trị như hợp đồng giấy không?

Thời gian: 4668.965 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng lao động điện tử bằng thông điệp dữ liệu theo pháp luật giao dịch điện tử có giá trị như hợp đồng bằng văn bản.

## HD004 — without_review — lần 1

Khi ký hợp đồng lao động bằng văn bản, người lao động có phải giữ một bản không?

Thời gian: 4665.298 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hợp đồng bằng văn bản được làm thành hai bản, mỗi bên giữ một bản.

## HD005 — without_review — lần 1

Công ty gọi giấy tờ của tôi là hợp đồng cộng tác viên nhưng tôi được trả lương và chịu quản lý giờ làm. Có thể là hợp đồng lao động không?

Thời gian: 4650.573 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được coi là hợp đồng lao động dù tên gọi khác, nếu có việc làm có trả công và chịu sự quản lý, điều hành, giám sát của một bên.

## HD006 — without_review — lần 1

Doanh nghiệp muốn ký hợp đồng lao động xác định thời hạn 48 tháng với nhân viên thông thường. Có hợp lệ về thời hạn không?

Thời gian: 5190.808 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Hợp đồng lao động xác định thời hạn theo quy định chung có thời hạn tối đa 36 tháng.

## HD007 — without_review — lần 1

Hợp đồng 24 tháng đã hết hạn, tôi tiếp tục làm việc 40 ngày và hai bên không ký hợp đồng mới. Hợp đồng trở thành loại nào?

Thời gian: 4624.366 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Hợp đồng xác định thời hạn đã giao kết chuyển thành hợp đồng lao động không xác định thời hạn sau khi quá 30 ngày mà hai bên không ký mới.

## HD008 — without_review — lần 1

Hợp đồng có thời hạn vừa hết 10 ngày, tôi vẫn làm mà chưa ký mới. Quyền lợi được áp dụng theo hợp đồng cũ không?

Thời gian: 4163.615 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Trong thời hạn 30 ngày từ khi hợp đồng hết hạn, nếu chưa ký mới thì quyền, nghĩa vụ và lợi ích vẫn theo hợp đồng đã giao kết.

## HD009 — without_review — lần 1

Tôi đã ký hai hợp đồng xác định thời hạn liên tiếp ở công ty tư nhân thông thường. Nếu tiếp tục làm việc, có thể ký lần thứ ba cùng loại không?

Thời gian: 4686.805 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường không. Sau lần ký thêm một hợp đồng xác định thời hạn, nếu tiếp tục làm việc thì phải ký hợp đồng không xác định thời hạn, trừ trường hợp luật quy định ngoại lệ.

## HD010 — without_review — lần 1

Tôi có thể cùng lúc ký hợp đồng lao động với hai công ty khác nhau không?

Thời gian: 4630.519 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người lao động có thể giao kết nhiều hợp đồng với nhiều người sử dụng lao động nếu bảo đảm thực hiện đầy đủ nội dung đã ký.

## HD011 — without_review — lần 1

Công ty giữ bản chính bằng đại học của tôi để bảo đảm tôi không nghỉ việc. Có được không?

Thời gian: 8728.813 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 1 Điều 17: Điều 17. Hành vi người sử dụng lao động không được làm khi giao kết, thực hiện hợp đồng lao động 1. Giữ bản chính giấy tờ tùy thân, văn bằng, chứng chỉ của người lao động. [prov_e401e65d2e15b2ac]
- Việc người sử dụng lao động giữ bản chính giấy tờ tùy thân, văn bằng, chứng chỉ để ràng buộc người lao động là hành vi bị cấm tại khoản 1 Điều 17; cần phân biệt với việc xuất trình để đối chiếu rồi trả lại. [prov_e401e65d2e15b2ac]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được giữ bản chính giấy tờ tùy thân, văn bằng hoặc chứng chỉ của người lao động.

## HD012 — without_review — lần 1

Công ty yêu cầu tôi đặt cọc hai triệu đồng để nhận việc theo hợp đồng lao động. Có được không?

Thời gian: 427.762 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Khoản 2 Điều 17: Điều 17. Hành vi người sử dụng lao động không được làm khi giao kết, thực hiện hợp đồng lao động 2. Yêu cầu người lao động phải thực hiện biện pháp bảo đảm bằng tiền hoặc tài sản khác cho việc thực hiện hợp đồng lao động. [prov_b44555d589adb6e2]
- Nếu khoản tiền hoặc tài sản thực chất là biện pháp bảo đảm cho việc thực hiện hợp đồng lao động thì thuộc hành vi bị cấm tại khoản 2 Điều 17. Đổi tên thành “phí bảo đảm uy tín” không làm thay đổi bản chất; cần kiểm tra mục đích và điều kiện nộp, hoàn trả thực tế. [prov_b44555d589adb6e2]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được yêu cầu bảo đảm bằng tiền hoặc tài sản khác để thực hiện hợp đồng lao động.

## HD013 — without_review — lần 1

Công ty muốn gia hạn thời hạn hợp đồng bằng phụ lục thay vì ký hợp đồng lao động mới. Có được không?

Thời gian: 4633.072 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Phụ lục có thể sửa đổi, bổ sung một số nội dung nhưng không được sửa đổi thời hạn hợp đồng lao động.

## HD014 — without_review — lần 1

Nhân viên tiếp cận bí mật công nghệ thì doanh nghiệp có được thỏa thuận riêng bằng văn bản về bảo mật không?

Thời gian: 4664.765 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Hai bên có thể thỏa thuận bằng văn bản về phạm vi, thời hạn, quyền lợi và bồi thường khi vi phạm bảo mật, nếu công việc trực tiếp liên quan bí mật kinh doanh/công nghệ.

## TV001 — without_review — lần 1

Công ty trả 70% lương của công việc trong thời gian thử việc. Có đúng luật không?

Thời gian: 662.482 ms. Trạng thái: PARTIAL_ALLOWED.

Thời gian và tiền lương thử việc phải được kiểm tra riêng theo các căn cứ sau:
- Với mức lương của công việc đó như bạn nêu, tỷ lệ 70% thấp hơn tối thiểu 85%, nên không đáp ứng quy định về tiền lương thử việc. Điều 26 (18/VBHN-VPQH): “Điều 26. Tiền lương thử việc Tiền lương của người lao động trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó.” [prov_38ac614a6bf6bd16]
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không. Lương thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc.

## TV002 — without_review — lần 1

Tôi và công ty thỏa thuận thử việc bằng 85% lương của công việc. Mức này có đáp ứng mức tối thiểu theo Bộ luật Lao động không?

Thời gian: 518.78 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 26: tiền lương trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó. Với mức lương của công việc đó như bạn nêu, tỷ lệ 85% đáp ứng mức tối thiểu 85%; điều này không xác nhận các điều kiện thử việc khác. [prov_38ac614a6bf6bd16]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. 85% bằng mức tối thiểu mà Điều 26 quy định cho lương thử việc.

## TV003 — without_review — lần 1

Mức lương của vị trí là 8 triệu đồng/tháng. Lương thử việc thấp nhất theo luật là bao nhiêu?

Thời gian: 429.504 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 26: tiền lương trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó. [prov_38ac614a6bf6bd16]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Ít nhất 6,8 triệu đồng/tháng, tương ứng 85% của 8 triệu đồng/tháng.

## TV004 — without_review — lần 1

Vị trí chuyên môn đòi hỏi trình độ cao đẳng, công ty thử việc 90 ngày có vượt giới hạn không?

Thời gian: 878.398 ms. Trạng thái: PARTIAL_ALLOWED.

Chưa thể kết luận chỉ từ thời gian 90 ngày. Cần biết nhóm công việc và công việc đó yêu cầu trình độ nào; bằng cấp của cá nhân không tự xác định nhóm công việc. Ví dụ 60 ngày không vượt mức 60 ngày của nhóm từ cao đẳng trở lên hoặc mức 180 ngày của quản lý doanh nghiệp, nhưng vượt mức 30 ngày và 06 ngày làm việc của các nhóm còn lại. Thời gian thử việc tối đa theo từng nhóm công việc được quy định như sau. Chỉ mức 06 ngày được tính theo ngày làm việc; các mức còn lại là ngày:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Có. Với công việc yêu cầu chuyên môn kỹ thuật từ cao đẳng trở lên, thời gian thử việc không quá 60 ngày, nếu không thuộc nhóm quản lý doanh nghiệp theo trường hợp riêng.

## TV005 — without_review — lần 1

Công việc yêu cầu trình độ cao đẳng và không phải chức danh quản lý, thử việc 45 ngày có nằm trong mức tối đa không?

Thời gian: 652.036 ms. Trạng thái: PARTIAL_ALLOWED.

Về thời gian: với nhóm công việc bạn nêu, 45 ngày không vượt mức tối đa 60 ngày. Kết luận này chỉ xét giới hạn thời gian, không xác nhận các điều kiện thử việc khác. Các căn cứ là:
- Về thời gian: với nhóm công việc bạn nêu, thử việc 45 ngày không vượt mức tối đa 60 ngày. Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Có. Thời gian thử việc tối đa trong trường hợp này là 60 ngày.

## TV006 — without_review — lần 1

Công việc yêu cầu trình độ trung cấp và không phải quản lý doanh nghiệp, thử việc 45 ngày có phù hợp không?

Thời gian: 483.577 ms. Trạng thái: PARTIAL_ALLOWED.

Về thời gian: với nhóm công việc bạn nêu, 45 ngày vượt mức tối đa 30 ngày. Kết luận này chỉ xét giới hạn thời gian, không xác nhận các điều kiện thử việc khác. Các căn cứ là:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không. Với nhóm công việc yêu cầu trình độ trung cấp hoặc nhân viên nghiệp vụ, thời gian thử việc tối đa là 30 ngày.

## TV007 — without_review — lần 1

Vị trí công nhân kỹ thuật thông thường bị thử việc 31 ngày. Có vượt giới hạn luật định không?

Thời gian: 861.014 ms. Trạng thái: PARTIAL_ALLOWED.

Về thời gian: với nhóm công việc bạn nêu, 31 ngày vượt mức tối đa 30 ngày. Kết luận này chỉ xét giới hạn thời gian, không xác nhận các điều kiện thử việc khác. Các căn cứ là:
- Về thời gian: với nhóm công việc bạn nêu, thử việc 31 ngày vượt mức tối đa 30 ngày. Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Có. Đối với công việc công nhân kỹ thuật, giới hạn thử việc là 30 ngày.

## TV008 — without_review — lần 1

Một công việc phổ thông không thuộc các nhóm yêu cầu trình độ nêu trong Điều 25, thử việc sáu ngày làm việc có đúng mức tối đa không?

Thời gian: 416.387 ms. Trạng thái: PARTIAL_ALLOWED.

Thời gian thử việc tối đa theo từng nhóm công việc được quy định như sau. Chỉ mức 06 ngày được tính theo ngày làm việc; các mức còn lại là ngày:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Có. Nhóm công việc khác có thời gian thử việc tối đa 06 ngày làm việc.

## TV009 — without_review — lần 1

Lao động làm công việc phổ thông thông thường bị thử việc mười ngày làm việc. Có đúng không?

Thời gian: 721.868 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Giới hạn đối với nhóm công việc khác là sáu ngày làm việc.

## TV010 — without_review — lần 1

Giám đốc doanh nghiệp thuộc diện người quản lý doanh nghiệp theo Điều 25 được yêu cầu thử việc 200 ngày. Có đúng không?

Thời gian: 469.267 ms. Trạng thái: PARTIAL_ALLOWED.

Chưa thể kết luận chỉ từ thời gian 200 ngày. Cần biết nhóm công việc và công việc đó yêu cầu trình độ nào; bằng cấp của cá nhân không tự xác định nhóm công việc. Ví dụ 60 ngày không vượt mức 60 ngày của nhóm từ cao đẳng trở lên hoặc mức 180 ngày của quản lý doanh nghiệp, nhưng vượt mức 30 ngày và 06 ngày làm việc của các nhóm còn lại. Thời gian thử việc tối đa theo từng nhóm công việc được quy định như sau. Chỉ mức 06 ngày được tính theo ngày làm việc; các mức còn lại là ngày:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không. Đối với công việc của người quản lý doanh nghiệp thuộc quy định này, thời gian thử việc không quá 180 ngày.

## TV011 — without_review — lần 1

Công ty yêu cầu tôi thử việc hai lần cho cùng một công việc sau khi lần đầu đã kết thúc. Có phù hợp không?

Thời gian: 13321.127 ms. Trạng thái: PARTIAL_ALLOWED.

Kết quả tra cứu dựa trên các căn cứ sau:
- Theo Điều 25 của Bộ luật Lao động, thời gian thử việc chỉ được thực hiện một lần đối với một công việc. [prov_0d899ce39134b1a5]
- Sau khi kết thúc thời gian thử việc, nếu đạt yêu cầu, người sử dụng lao động phải tiếp tục thực hiện hợp đồng lao động hoặc giao kết hợp đồng lao động mới. [prov_e984d1788a357c56]
- Trong thời gian thử việc, mỗi bên có quyền hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường. [prov_9e2818163eeff843]
- Do đó, việc công ty yêu cầu bạn thử việc hai lần cho cùng một công việc là không phù hợp với quy định pháp luật. [prov_0d899ce39134b1a5] [prov_e984d1788a357c56] [prov_9e2818163eeff843]
Kết quả chỉ là một phần vì còn thiếu bằng chứng bắt buộc được nêu trong limitations.

**Đáp án tham khảo (DRAFT):** Không. Đối với một công việc, luật chỉ cho phép thử việc một lần.

## TV012 — without_review — lần 1

Tôi ký hợp đồng lao động thời hạn 20 ngày. Công ty có được áp dụng thử việc không?

Thời gian: 404.902 ms. Trạng thái: PARTIAL_ALLOWED.

Thời gian thử việc tối đa theo từng nhóm công việc được quy định như sau. Chỉ mức 06 ngày được tính theo ngày làm việc; các mức còn lại là ngày:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không. Không áp dụng thử việc đối với người lao động giao kết hợp đồng lao động có thời hạn dưới một tháng.

## TV013 — without_review — lần 1

Đang trong thời gian thử việc, tôi muốn nghỉ ngay mà không báo trước. Theo Bộ luật Lao động có phải bồi thường không?

Thời gian: 47779.188 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- 18/VBHN-VPQH Điều 25 Khoản 1: Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp; [prov_d3c76fc9dfd1296a]
- 18/VBHN-VPQH Điều 25 Khoản 2: Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên; [prov_900510b9768da439]
- 18/VBHN-VPQH Điều 25 Khoản 3: Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ; [prov_82b3c0a297633594]
- 18/VBHN-VPQH Điều 25 Khoản 4: Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác. [prov_d9651e6941d38a25]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Đây là kết quả hỗ trợ tra cứu; cần đối chiếu hồ sơ thực tế trước khi đưa ra kết luận pháp lý cuối cùng.

**Đáp án tham khảo (DRAFT):** Trong thời gian thử việc, mỗi bên được hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã giao kết mà không cần báo trước và không phải bồi thường về việc hủy bỏ đó.

## TV014 — without_review — lần 1

Tôi thử việc đạt yêu cầu và trước đó ký hợp đồng thử việc riêng. Công ty phải làm gì sau khi hết thử việc?

Thời gian: 10787.987 ms. Trạng thái: PARTIAL_ALLOWED.

Kết quả tra cứu dựa trên các căn cứ sau:
- Sau khi hết thời gian thử việc, nếu người lao động đạt yêu cầu, công ty phải thông báo kết quả thử việc và tiếp tục thực hiện hợp đồng lao động đã ký kết hoặc phải ký kết hợp đồng lao động mới. [prov_e984d1788a357c56]
- Trong thời gian thử việc, công ty có quyền hủy bỏ hợp đồng thử việc hoặc hợp đồng lao động đã ký kết mà không cần báo trước và không phải bồi thường. [prov_9e2818163eeff843]
- Công ty phải thông báo kết quả thử việc cho người lao động khi kết thúc thời gian thử việc. [prov_e984d1788a357c56]
- Nếu người lao động đạt yêu cầu thử việc, công ty phải tiếp tục thực hiện hợp đồng lao động đã ký kết hoặc ký kết hợp đồng lao động mới. [prov_e984d1788a357c56]
Kết quả chỉ là một phần vì còn thiếu bằng chứng bắt buộc được nêu trong limitations.

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải thông báo kết quả và giao kết hợp đồng lao động nếu đã giao kết hợp đồng thử việc riêng.

## TL001 — without_review — lần 1

Cùng công việc có giá trị như nhau, công ty trả lương thấp hơn chỉ vì người lao động là nữ. Có đúng luật không?

Thời gian: 4663.233 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động phải bảo đảm trả lương bình đẳng, không phân biệt giới tính với công việc có giá trị như nhau.

## TL002 — without_review — lần 1

Doanh nghiệp trả lương theo công việc thấp hơn mức lương tối thiểu áp dụng. Có được không?

Thời gian: 5236.042 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Mức lương theo công việc hoặc chức danh không được thấp hơn mức lương tối thiểu áp dụng.

## TL003 — without_review — lần 1

Người lao động hưởng lương tháng có thể được trả mỗi tháng một lần không?

Thời gian: 4614.859 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người hưởng lương theo tháng được trả một tháng một lần hoặc nửa tháng một lần, theo thời điểm có tính chu kỳ đã thỏa thuận.

## TL004 — without_review — lần 1

Người hưởng lương tháng được công ty trả hai tháng một lần, không có thỏa thuận đặc biệt nào. Có đúng kỳ hạn luật định không?

Thời gian: 4688.296 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Lương tháng phải được trả một tháng một lần hoặc nửa tháng một lần.

## TL005 — without_review — lần 1

Công ty vì bất khả kháng, đã khắc phục nhưng vẫn chậm trả lương 20 ngày. Có phải đền bù do chậm trả không?

Thời gian: 4232.904 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Khi trả lương chậm từ 15 ngày trở lên trong trường hợp này, công ty phải đền bù ít nhất theo mức lãi được Điều 97 khoản 4 quy định.

## TL006 — without_review — lần 1

Do bất khả kháng đã tìm mọi biện pháp khắc phục, doanh nghiệp vẫn trả lương trễ 40 ngày. Có vượt giới hạn không?

Thời gian: 4548.03 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngay cả trong tình huống bất khả kháng theo khoản 4 Điều 97, thời hạn trả lương chậm không được quá 30 ngày.

## TL007 — without_review — lần 1

Công ty trả lương qua ngân hàng và bắt nhân viên chịu phí mở tài khoản, phí chuyển lương. Ai phải trả?

Thời gian: 4645.649 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải trả các loại phí liên quan đến mở tài khoản và chuyển tiền lương khi trả lương qua tài khoản cá nhân.

## TL008 — without_review — lần 1

Tiền lương trả qua tài khoản ngân hàng đứng tên người lao động có được không?

Thời gian: 5202.307 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Tiền lương có thể trả bằng tiền mặt hoặc qua tài khoản cá nhân của người lao động được mở tại ngân hàng.

## TL009 — without_review — lần 1

Doanh nghiệp ép nhân viên dùng lương mua sản phẩm do chính công ty bán. Có phù hợp không?

Thời gian: 4118.72 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được ép buộc người lao động dùng tiền lương để mua hàng hóa, dịch vụ do họ chỉ định.

## TL010 — without_review — lần 1

Tiền lương làm thêm vào ngày làm việc bình thường tối thiểu bằng bao nhiêu phần trăm mức lương giờ tương ứng?

Thời gian: 676.615 ms. Trạng thái: PARTIAL_ALLOWED.

Tiền lương làm thêm giờ là nghĩa vụ theo các mức tối thiểu dưới đây. Việc đồng ý làm thêm không tự thay thế nghĩa vụ trả tiền lương làm thêm:
- Điều 98 khoản 1 (18/VBHN-VPQH): “Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau:” [prov_ecbe024a3498e5dc]
- Điều 98 khoản 1 điểm a (45/2019/QH14): “Điều 98. Tỉền Iương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền luơng hoặc tiền lương thực trả theo công việc đang làm như sau: a) Vào ngày thường, ít nhất bằng 150%;” [prov_5285a6e4366d573f]
- Điều 98 khoản 1 điểm b (18/VBHN-VPQH): “Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau: b) Vào ngày nghỉ hằng tuần, ít nhất bằng 200%;” [prov_5f5938ce9a5cc319]
- Điều 98 khoản 1 điểm c (18/VBHN-VPQH): “Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau: c) Vào ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương, ít nhất bằng 300% chưa kể tiền lương ngày lễ, tết, ngày nghỉ có hưởng lương đối với người lao động hưởng lương ngày.” [prov_1b27c4459a712e61]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Ít nhất bằng 150% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL011 — without_review — lần 1

Tôi làm thêm vào ngày nghỉ hằng tuần, mức lương làm thêm thấp nhất là bao nhiêu phần trăm?

Thời gian: 10.498 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 200% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm.

## TL012 — without_review — lần 1

Tôi làm thêm vào ngày lễ, tết: mức lương làm thêm tối thiểu theo Điều 98 là bao nhiêu?

Thời gian: 9.487 ms. Trạng thái: NEED_MORE_FACTS.

Cần xác định chủ đề của câu hỏi nối tiếp trước khi tra cứu.

**Đáp án tham khảo (DRAFT):** Ít nhất 300% đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm; đối với người hưởng lương ngày, mức này chưa kể tiền lương ngày lễ được hưởng.

## TL013 — without_review — lần 1

Làm việc vào ban đêm nhưng không làm thêm giờ, có khoản trả thêm tối thiểu bao nhiêu?

Thời gian: 40968.563 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- 18/VBHN-VPQH Điều 98 Khoản 1: Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau: [prov_ecbe024a3498e5dc]
- 45/2019/QH14 Điều 98 Khoản 1 Điểm a: Điều 98. Tỉền Iương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền luơng hoặc tiền lương thực trả theo công việc đang làm như sau: a) Vào ngày thường, ít nhất bằng 150%; [prov_5285a6e4366d573f]
- 18/VBHN-VPQH Điều 98 Khoản 1 Điểm b: Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau: b) Vào ngày nghỉ hằng tuần, ít nhất bằng 200%; [prov_5f5938ce9a5cc319]
- 18/VBHN-VPQH Điều 98 Khoản 1 Điểm c: Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 1. Người lao động làm thêm giờ được trả lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc đang làm như sau: c) Vào ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương, ít nhất bằng 300% chưa kể tiền lương ngày lễ, tết, ngày nghỉ có hưởng lương đối với người lao động hưởng lương ngày. [prov_1b27c4459a712e61]
- 145/2020/NĐ-CP Điều 57 Khoản 1: Điều 57. Tiền lương làm thêm giờ vào ban đêm Người lao động làm thêm giờ vào ban đêm theo khoản 3 Điều 98 của Bộ luật Lao động, được hưởng tiền lương tính theo công thức sau: 1. Đối với người lao động hưởng lương theo thời gian, tiền lương làm thêm giờ vào ban đêm được tính như sau: Tiền lương làm thêm giờ vào ban đêm Tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường x Mức ít nhất 150% hoặc 200% hoặc 300% + Tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường x Mức ít nhất 30% + 20% x Tiền lương giờ vào ban ngày của ngày làm việc bình thường hoặc của ngày nghỉ hằng tuần hoặc của ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương x Số giờ làm thêm vào ban đêm Trong đó: [prov_b334588616d9bed9]
- 145/2020/NĐ-CP Điều 57 Khoản 1 Điểm b: Điều 57. Tiền lương làm thêm giờ vào ban đêm Người lao động làm thêm giờ vào ban đêm theo khoản 3 Điều 98 của Bộ luật Lao động, được hưởng tiền lương tính theo công thức sau: 1. Đối với người lao động hưởng lương theo thời gian, tiền lương làm thêm giờ vào ban đêm được tính như sau: Tiền lương làm thêm giờ vào ban đêm = Tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường x Mức ít nhất 150% hoặc 200% hoặc 300% + Tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường x Mức ít nhất 30% + 20% x Tiền lương giờ vào ban ngày của ngày làm việc bình thường hoặc của ngày nghỉ hằng tuần hoặc của ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương x Số giờ làm thêm vào ban đêm Trong đó: b) Tiền lương giờ vào ban ngày của ngày làm việc bình thường hoặc của ngày nghỉ hằng tuần hoặc của ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương được xác định như sau: b1) Tiền lương giờ vào ban ngày của ngày làm việc bình thường, được tính ít nhất bằng 100% so với tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường đối với trường hợp người lao động không làm thêm giờ vào ban ngày của ngày đó (trước khi làm thêm giờ vào ban đêm); ít nhất bằng 150% so với tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường đối với trường hợp người lao động có làm thêm giờ vào ban ngày của ngày đó (trước khi làm thêm giờ vào ban đêm); b2) Tiền lương giờ vào ban ngày của ngày nghỉ hằng tuần, được tính ít nhất bằng 200% so với tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường; b3) Tiền lương giờ vào ban ngày của ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương, được tính ít nhất bằng 300% so với tiền lương giờ thực trả của công việc đang làm vào ngày làm việc bình thường. [prov_90042ecaa85ffeef]
- 145/2020/NĐ-CP Điều 57 Khoản 2: Điều 57. Tiền lương làm thêm giờ vào ban đêm Người lao động làm thêm giờ vào ban đêm theo khoản 3 Điều 98 của Bộ luật Lao động, được hưởng tiền lương tính theo công thức sau: 2. Đối với người lao động hưởng lương theo sản phẩm, tiền lương làm thêm giờ vào ban đêm được tính như sau: Tiền lương làm thêm giờ vào ban đêm Đơn giá tiền lương sản phẩm của ngày làm việc bình thường x Mức ít nhất 150% hoặc 200% hoặc 300% + Đơn giá tiền lương sản phẩm của ngày làm việc bình thường x Mức ít nhất 30% + 20% x Đơn giá tiền lương sản phẩm vào ban ngày của ngày làm việc bình thường hoặc của ngày nghỉ hằng tuần hoặc của ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương x Số sản phẩm làm thêm vào ban đêm Trong đó, đơn giá tiền lương sản phẩm vào ban ngày của ngày làm việc bình thường hoặc của ngày nghỉ hằng tuần hoặc của ngày nghỉ lễ, tết, ngày nghỉ có hưởng lương được xác định như sau: [prov_a5aa1fc5c437b7a5]
- 18/VBHN-VPQH Điều 98 Khoản 2: Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 2. Người lao động làm việc vào ban đêm thì được trả thêm ít nhất bằng 30% tiền lương tính theo đơn giá tiền lương hoặc tiền lương thực trả theo công việc của ngày làm việc bình thường. [prov_2f6168d4affe1f8e]
- 18/VBHN-VPQH Điều 98 Khoản 3: Điều 98. Tiền lương làm thêm giờ, làm việc vào ban đêm 3. Người lao động làm thêm giờ vào ban đêm thì ngoài việc trả lương theo quy định tại khoản 1 và khoản 2 Điều này, người lao động còn được trả thêm 20% tiền lương tính theo đơn giá tiền lương hoặc tiền lương theo công việc làm vào ban ngày của ngày làm việc bình thường hoặc của ngày nghỉ hằng tuần hoặc của ngày nghỉ lễ, tết. [prov_2cc57893b123d3a8]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Đây là kết quả hỗ trợ tra cứu; cần đối chiếu hồ sơ thực tế trước khi đưa ra kết luận pháp lý cuối cùng.

**Đáp án tham khảo (DRAFT):** Được trả thêm ít nhất 30% tiền lương tính theo đơn giá hoặc tiền lương thực trả của ngày làm việc bình thường.

## TL014 — without_review — lần 1

Nhà máy phải ngừng việc hoàn toàn do lỗi của người sử dụng lao động. Người lao động có được trả đủ lương hợp đồng không?

Thời gian: 4672.735 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu ngừng việc do lỗi của người sử dụng lao động thì người lao động được trả đủ tiền lương theo hợp đồng lao động.

## TG001 — without_review — lần 1

Theo chế độ thời giờ làm việc bình thường tính theo ngày, luật giới hạn tối đa mấy giờ một ngày và một tuần?

Thời gian: 4656.41 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không quá 8 giờ/ngày và 48 giờ/tuần theo chế độ làm việc bình thường.

## TG002 — without_review — lần 1

Nếu doanh nghiệp tổ chức giờ làm việc bình thường theo tuần, có thể bố trí 10 giờ một ngày và tối đa 48 giờ một tuần không?

Thời gian: 4639.063 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có, nếu áp dụng chế độ tính theo tuần, thông báo cho người lao động và không vượt 10 giờ/ngày, 48 giờ/tuần.

## TG003 — without_review — lần 1

Nhà nước có khuyến khích doanh nghiệp áp dụng tuần làm việc 40 giờ không?

Thời gian: 4673.263 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Bộ luật khuyến khích người sử dụng lao động thực hiện tuần làm việc 40 giờ.

## TG004 — without_review — lần 1

Thời gian từ 23 giờ đến 5 giờ sáng hôm sau có thuộc giờ làm việc ban đêm không?

Thời gian: 4687.266 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Giờ làm việc ban đêm được tính từ 22 giờ đến 06 giờ sáng ngày hôm sau.

## TG005 — without_review — lần 1

Trong trường hợp làm thêm giờ thông thường, công ty có cần được sự đồng ý của người lao động không?

Thời gian: 4659.491 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Người sử dụng lao động phải có sự đồng ý của người lao động, trừ những trường hợp làm thêm đặc biệt do luật quy định.

## TG006 — without_review — lần 1

Theo cách bố trí giờ làm việc bình thường theo ngày, giới hạn làm thêm trong ngày theo Điều 107 là bao nhiêu?

Thời gian: 4643.378 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Số giờ làm thêm không quá 50% số giờ làm việc bình thường trong ngày, đồng thời phải tuân thủ các giới hạn tháng và năm tương ứng.

## TG007 — without_review — lần 1

Trong trường hợp làm thêm giờ thông thường, một người lao động được làm thêm tối đa bao nhiêu giờ trong một tháng?

Thời gian: 767.445 ms. Trạng thái: PARTIAL_ALLOWED.

Giới hạn làm thêm giờ gồm điều kiện đồng ý, giới hạn theo ngày/tháng/năm và điều kiện áp dụng mức đến 300 giờ/năm. Đây là quy tắc trong phiên bản dữ liệu được tra cứu:
- Điều 107 khoản 2 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: a) Phải được sự đồng ý của người lao động;” [prov_2315c425c1eaa518]
- Điều 107 khoản 2 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: b) Bảo đảm số giờ làm thêm của người lao động không quá 50% số giờ làm việc bình thường trong 01 ngày; trường hợp áp dụng quy định thời giờ làm việc bình thường theo tuần thì tổng số giờ làm việc bình thường và số giờ làm thêm không quá 12 giờ trong 01 ngày; không quá 40 giờ trong 01 tháng;” [prov_4ae9d3f661c91bf1]
- Điều 107 khoản 2 điểm c (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: c) Bảo đảm số giờ làm thêm của người lao động không quá 200 giờ trong 01 năm, trừ trường hợp quy định tại khoản 3 Điều này.” [prov_7ebbd1a871c548bc]
- Điều 107 khoản 3 (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây:” [prov_ea4944bd15922c19]
- Điều 107 khoản 3 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: a) Sản xuất, gia công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông, lâm, diêm nghiệp, thủy sản;” [prov_26921bbfe43debe0]
- Điều 107 khoản 3 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: b) Sản xuất, cung cấp điện, viễn thông, lọc dầu; cấp, thoát nước;” [prov_0328018d8169ca6e]
- Điều 107 khoản 3 điểm c (45/2019/QH14): “Điều 107. Làm thêm giờ 3. Nguời sử dụng lao động được sử dụng nguời lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc truờng hợp sau đây: công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông; lâm; diêm nghiệp, thủy sản; c) Trường hợp giải quyết công việc đòi hỏi lao động có trình độ chuyên môn, kỹ thuật cao mà thị trường lao động không cung ứng đầy đủ, kịp thời;” [prov_07018d0a70f8d54b]
- Điều 107 khoản 3 điểm d (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: d) Trường hợp phải giải quyết công việc cấp bách, không thể trì hoãn do tính chất thời vụ, thời điểm của nguyên liệu, sản phẩm hoặc để giải quyết công việc phát sinh do yếu tố khách quan không dự liệu trước, do hậu quả thời tiết, thiên tai, hỏa hoạn, địch họa, thiếu điện, thiếu nguyên liệu, sự cố kỹ thuật của dây chuyền sản xuất;” [prov_99f19670e4f6b29c]
- Điều 107 khoản 3 điểm đ (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: đ) Trường hợp khác do Chính phủ quy định.” [prov_ef37b4b2ec39c720]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không quá 40 giờ làm thêm trong một tháng.

## TG008 — without_review — lần 1

Theo giới hạn làm thêm giờ chung, một năm được làm thêm tối đa bao nhiêu giờ nếu không thuộc ngoại lệ?

Thời gian: 509.034 ms. Trạng thái: PARTIAL_ALLOWED.

Giới hạn làm thêm giờ gồm điều kiện đồng ý, giới hạn theo ngày/tháng/năm và điều kiện áp dụng mức đến 300 giờ/năm. Đây là quy tắc trong phiên bản dữ liệu được tra cứu:
- Điều 107 khoản 2 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: a) Phải được sự đồng ý của người lao động;” [prov_2315c425c1eaa518]
- Điều 107 khoản 2 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: b) Bảo đảm số giờ làm thêm của người lao động không quá 50% số giờ làm việc bình thường trong 01 ngày; trường hợp áp dụng quy định thời giờ làm việc bình thường theo tuần thì tổng số giờ làm việc bình thường và số giờ làm thêm không quá 12 giờ trong 01 ngày; không quá 40 giờ trong 01 tháng;” [prov_4ae9d3f661c91bf1]
- Điều 107 khoản 2 điểm c (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: c) Bảo đảm số giờ làm thêm của người lao động không quá 200 giờ trong 01 năm, trừ trường hợp quy định tại khoản 3 Điều này.” [prov_7ebbd1a871c548bc]
- Điều 107 khoản 3 (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây:” [prov_ea4944bd15922c19]
- Điều 107 khoản 3 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: a) Sản xuất, gia công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông, lâm, diêm nghiệp, thủy sản;” [prov_26921bbfe43debe0]
- Điều 107 khoản 3 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: b) Sản xuất, cung cấp điện, viễn thông, lọc dầu; cấp, thoát nước;” [prov_0328018d8169ca6e]
- Điều 107 khoản 3 điểm c (45/2019/QH14): “Điều 107. Làm thêm giờ 3. Nguời sử dụng lao động được sử dụng nguời lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc truờng hợp sau đây: công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông; lâm; diêm nghiệp, thủy sản; c) Trường hợp giải quyết công việc đòi hỏi lao động có trình độ chuyên môn, kỹ thuật cao mà thị trường lao động không cung ứng đầy đủ, kịp thời;” [prov_07018d0a70f8d54b]
- Điều 107 khoản 3 điểm d (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: d) Trường hợp phải giải quyết công việc cấp bách, không thể trì hoãn do tính chất thời vụ, thời điểm của nguyên liệu, sản phẩm hoặc để giải quyết công việc phát sinh do yếu tố khách quan không dự liệu trước, do hậu quả thời tiết, thiên tai, hỏa hoạn, địch họa, thiếu điện, thiếu nguyên liệu, sự cố kỹ thuật của dây chuyền sản xuất;” [prov_99f19670e4f6b29c]
- Điều 107 khoản 3 điểm đ (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: đ) Trường hợp khác do Chính phủ quy định.” [prov_ef37b4b2ec39c720]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không quá 200 giờ trong một năm, trừ các trường hợp luật cho phép tối đa 300 giờ.

## TG009 — without_review — lần 1

Trong một số ngành sản xuất như dệt may xuất khẩu, luật có cho phép làm thêm đến 300 giờ một năm không?

Thời gian: 4668.333 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể được bố trí làm thêm đến 300 giờ trong năm khi thuộc trường hợp được luật cho phép và đáp ứng các điều kiện liên quan.

## TG010 — without_review — lần 1

Một người làm ban đêm theo thời giờ bình thường 7 giờ trong ngày được nghỉ giữa giờ ít nhất bao lâu?

Thời gian: 4683.577 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 45 phút liên tục khi làm việc ban đêm từ 6 giờ trở lên trong ngày.

## TG011 — without_review — lần 1

Người làm việc ban ngày 8 giờ/ngày được nghỉ giữa giờ ít nhất bao nhiêu phút?

Thời gian: 4643.118 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 30 phút liên tục khi thời gian làm việc trong ngày từ 6 giờ trở lên.

## TG012 — without_review — lần 1

Người làm ca liên tục 8 giờ/ngày, thời gian nghỉ giữa giờ có được tính vào giờ làm việc không?

Thời gian: 4627.155 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Nếu làm việc theo ca liên tục từ 6 giờ trở lên, thời gian nghỉ giữa giờ được tính vào giờ làm việc.

## TG013 — without_review — lần 1

Người lao động làm việc theo ca cần được nghỉ ít nhất bao nhiêu giờ trước khi chuyển sang ca khác?

Thời gian: 4690.648 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 12 giờ trước khi chuyển sang ca làm việc khác.

## TG014 — without_review — lần 1

Trong thiên tai cần bảo vệ ngay tính mạng con người, doanh nghiệp có thể yêu cầu làm thêm giờ đặc biệt vượt giới hạn thông thường không?

Thời gian: 641.79 ms. Trạng thái: PARTIAL_ALLOWED.

Giới hạn làm thêm giờ gồm điều kiện đồng ý, giới hạn theo ngày/tháng/năm và điều kiện áp dụng mức đến 300 giờ/năm. Đây là quy tắc trong phiên bản dữ liệu được tra cứu:
- Điều 107 khoản 2 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: a) Phải được sự đồng ý của người lao động;” [prov_2315c425c1eaa518]
- Điều 107 khoản 2 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: b) Bảo đảm số giờ làm thêm của người lao động không quá 50% số giờ làm việc bình thường trong 01 ngày; trường hợp áp dụng quy định thời giờ làm việc bình thường theo tuần thì tổng số giờ làm việc bình thường và số giờ làm thêm không quá 12 giờ trong 01 ngày; không quá 40 giờ trong 01 tháng;” [prov_4ae9d3f661c91bf1]
- Điều 107 khoản 2 điểm c (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: c) Bảo đảm số giờ làm thêm của người lao động không quá 200 giờ trong 01 năm, trừ trường hợp quy định tại khoản 3 Điều này.” [prov_7ebbd1a871c548bc]
- Điều 107 khoản 3 (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây:” [prov_ea4944bd15922c19]
- Điều 107 khoản 3 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: a) Sản xuất, gia công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông, lâm, diêm nghiệp, thủy sản;” [prov_26921bbfe43debe0]
- Điều 107 khoản 3 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: b) Sản xuất, cung cấp điện, viễn thông, lọc dầu; cấp, thoát nước;” [prov_0328018d8169ca6e]
- Điều 107 khoản 3 điểm c (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: c) Trường hợp giải quyết công việc đòi hỏi lao động có trình độ chuyên môn, kỹ thuật cao mà thị trường lao động không cung ứng đầy đủ, kịp thời;” [prov_7b192f8c0aa99b89]
- Điều 107 khoản 3 điểm d (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: d) Trường hợp phải giải quyết công việc cấp bách, không thể trì hoãn do tính chất thời vụ, thời điểm của nguyên liệu, sản phẩm hoặc để giải quyết công việc phát sinh do yếu tố khách quan không dự liệu trước, do hậu quả thời tiết, thiên tai, hỏa hoạn, địch họa, thiếu điện, thiếu nguyên liệu, sự cố kỹ thuật của dây chuyền sản xuất;” [prov_99f19670e4f6b29c]
- Điều 107 khoản 3 điểm đ (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: đ) Trường hợp khác do Chính phủ quy định.” [prov_ef37b4b2ec39c720]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Có thể yêu cầu làm thêm giờ trong trường hợp bảo vệ tính mạng và khắc phục hậu quả theo Điều 108, trừ khi có nguy cơ ảnh hưởng tính mạng, sức khỏe của người lao động theo pháp luật an toàn, vệ sinh lao động.

## NP001 — without_review — lần 1

Theo quy định chung, một tuần người lao động phải được nghỉ ít nhất bao nhiêu giờ liên tục?

Thời gian: 4621.148 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 24 giờ liên tục trong một tuần.

## NP002 — without_review — lần 1

Doanh nghiệp có thể chọn ngày nghỉ hằng tuần là thứ Hai thay vì Chủ nhật không?

Thời gian: 4692.061 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Ngày nghỉ hằng tuần có thể là Chủ nhật hoặc một ngày khác xác định trong tuần và phải ghi trong nội quy lao động.

## NP003 — without_review — lần 1

Nếu ngày nghỉ hằng tuần trùng ngày nghỉ lễ, người lao động có được nghỉ bù không?

Thời gian: 4659.508 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ bù ngày nghỉ hằng tuần vào ngày làm việc kế tiếp.

## NP004 — without_review — lần 1

Do chu kỳ lao động đặc biệt không thể bố trí nghỉ hằng tuần, người lao động phải được nghỉ bình quân ít nhất bao nhiêu ngày một tháng?

Thời gian: 4663.949 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Người sử dụng lao động phải bảo đảm bình quân một tháng ít nhất bốn ngày nghỉ trong trường hợp đặc biệt đó.

## NP005 — without_review — lần 1

Người làm đủ 12 tháng trong điều kiện bình thường có bao nhiêu ngày nghỉ hằng năm hưởng nguyên lương?

Thời gian: 4663.925 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** 12 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP006 — without_review — lần 1

Người làm nghề nặng nhọc, độc hại, nguy hiểm đủ 12 tháng được nghỉ phép năm bao nhiêu ngày?

Thời gian: 449.127 ms. Trạng thái: PARTIAL_ALLOWED.

Mức nghỉ cơ sở được xác định theo nhóm áp dụng tại khoản 1 Điều 113; không cộng chồng các mức nghỉ vì tuổi, khuyết tật và điều kiện công việc. Mức nền phù hợp là 14 ngày; thâm niên 0 năm làm tăng 0 ngày theo từng chu kỳ đủ 05 năm. Tổng tối thiểu là 14 ngày. [prov_42bcd849a0a30ecd]

**Đáp án tham khảo (DRAFT):** 14 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP007 — without_review — lần 1

Người làm nghề đặc biệt nặng nhọc, độc hại, nguy hiểm đủ 12 tháng có bao nhiêu ngày phép năm?

Thời gian: 441.188 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không thể tạo câu trả lời có trích dẫn được xác minh.

**Đáp án tham khảo (DRAFT):** 16 ngày làm việc nghỉ hằng năm hưởng nguyên lương.

## NP008 — without_review — lần 1

Người làm việc chưa đủ 12 tháng có được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc không?

Thời gian: 32092.867 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Người lao động làm việc chưa đủ 12 tháng được tính số ngày nghỉ phép năm theo tỷ lệ số tháng làm việc. [prov_1c22b690b094979c]
- Số ngày nghỉ hằng năm của người lao động làm việc chưa đủ 12 tháng được tính bằng cách lấy số ngày nghỉ hằng năm cộng với số ngày được nghỉ tăng thêm theo thâm niên (nếu có), chia cho 12 tháng, nhân với số tháng làm việc thực tế trong năm. [prov_5dfc4b46a7ec5560]
- Người lao động làm việc đủ 12 tháng được nghỉ 12 ngày làm việc đối với người làm công việc trong điều kiện bình thường. [prov_3bb8e6ed783463fe]
- Người lao động chưa thành niên, lao động là người khuyết tật, người làm nghề, công việc nặng nhọc, độc hại, nguy hiểm được nghỉ 14 ngày làm việc. [prov_42bcd849a0a30ecd]
- Người lao động làm nghề, công việc đặc biệt nặng nhọc, độc hại, nguy hiểm được nghỉ 16 ngày làm việc. [prov_1fab8366c4ce639b]
- Người lao động làm việc chưa đủ 12 tháng được tính số ngày nghỉ hằng năm theo tỷ lệ tương ứng với số tháng làm việc. [prov_1c22b690b094979c]
- Người lao động làm việc chưa đủ 12 tháng được tính số ngày nghỉ hằng năm theo tỷ lệ số tháng làm việc. [prov_1c22b690b094979c]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Có. Số ngày nghỉ hằng năm được tính theo tỷ lệ tương ứng với số tháng làm việc.

## NP009 — without_review — lần 1

Tôi đã làm việc đủ 5 năm cho cùng một công ty. Số ngày nghỉ hằng năm có tăng thêm không?

Thời gian: 1031.772 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Có. Cứ đủ 5 năm làm việc cho một người sử dụng lao động, số ngày nghỉ hằng năm tăng thêm một ngày.

## NP010 — without_review — lần 1

Người lao động thôi việc mà chưa sử dụng hết ngày nghỉ hằng năm có được thanh toán ngày chưa nghỉ không?

Thời gian: 24.803 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Khi thôi việc hoặc bị mất việc mà còn ngày nghỉ hằng năm chưa nghỉ, người sử dụng lao động phải thanh toán tiền lương cho những ngày đó.

## NP011 — without_review — lần 1

Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa mấy năm một lần?

Thời gian: 9331.56 ms. Trạng thái: PARTIAL_ALLOWED.

Kết quả tra cứu dựa trên các căn cứ sau:
- Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa 12 ngày làm việc một lần đối với người làm công việc trong điều kiện bình thường. [prov_3bb8e6ed783463fe]
- Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa 14 ngày làm việc một lần đối với người lao động chưa thành niên, lao động là người khuyết tật, người làm nghề, công việc nặng nhọc, độc hại, nguy hiểm. [prov_42bcd849a0a30ecd]
- Người lao động và doanh nghiệp có thể thỏa thuận nghỉ gộp phép năm tối đa 16 ngày làm việc một lần đối với người làm nghề, công việc đặc biệt nặng nhọc, độc hại, nguy hiểm. [prov_1fab8366c4ce639b]
Kết quả chỉ là một phần vì còn thiếu bằng chứng bắt buộc được nêu trong limitations.

**Đáp án tham khảo (DRAFT):** Có thể thỏa thuận nghỉ gộp tối đa ba năm một lần.

## NP012 — without_review — lần 1

Tôi kết hôn thì được nghỉ việc riêng hưởng nguyên lương mấy ngày?

Thời gian: 4652.302 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ ba ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP013 — without_review — lần 1

Con đẻ của tôi kết hôn thì tôi được nghỉ hưởng nguyên lương bao nhiêu ngày?

Thời gian: 4662.799 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Được nghỉ một ngày hưởng nguyên lương và phải thông báo cho người sử dụng lao động.

## NP014 — without_review — lần 1

Anh ruột của tôi qua đời, tôi có quyền nghỉ một ngày không hưởng lương không?

Thời gian: 4652.161 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có. Được nghỉ một ngày không hưởng lương và phải thông báo cho người sử dụng lao động.

## CD001 — without_review — lần 1

Tôi làm theo hợp đồng không xác định thời hạn, muốn đơn phương nghỉ việc bình thường. Cần báo trước tối thiểu bao nhiêu ngày?

Thời gian: 11498.858 ms. Trạng thái: PARTIAL_ALLOWED.

Kết quả tra cứu dựa trên các căn cứ sau:
- Người lao động làm theo hợp đồng không xác định thời hạn có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước ít nhất 45 ngày. [prov_e091631d0168c360]
- Theo Điều 35, khoản 1, điểm a của Bộ luật Lao động, người lao động phải báo trước ít nhất 45 ngày khi đơn phương chấm dứt hợp đồng lao động không xác định thời hạn. [prov_e091631d0168c360]
- Người lao động cần báo trước ít nhất 45 ngày trước khi đơn phương nghỉ việc theo hợp đồng không xác định thời hạn. [prov_e091631d0168c360]
- Theo quy định tại Điều 35, khoản 1, điểm a của Văn bản hợp nhất Bộ luật Lao động, người lao động làm theo hợp đồng không xác định thời hạn phải báo trước ít nhất 45 ngày khi đơn phương chấm dứt hợp đồng lao động. [prov_e091631d0168c360]
Kết quả chỉ là một phần vì còn thiếu bằng chứng bắt buộc được nêu trong limitations.

**Đáp án tham khảo (DRAFT):** Thông thường phải báo trước ít nhất 45 ngày, trừ ngành nghề/công việc đặc thù hoặc trường hợp được nghỉ không báo trước.

## CD002 — without_review — lần 1

Tôi có hợp đồng xác định thời hạn 24 tháng, muốn đơn phương nghỉ việc trong trường hợp thông thường. Phải báo trước bao lâu?

Thời gian: 38754.236 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm a: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: a) Ít nhất 45 ngày nếu làm việc theo hợp đồng lao động không xác định thời hạn; [prov_e091631d0168c360]
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm b: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: b) Ít nhất 30 ngày nếu làm việc theo hợp đồng lao động xác định thời hạn có thời hạn từ 12 tháng đến 36 tháng; [prov_c75b6504b5c1069f]
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm c: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: c) Ít nhất 03 ngày làm việc nếu làm việc theo hợp đồng lao động xác định thời hạn có thời hạn dưới 12 tháng; [prov_85a2c41c4237c73d]
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm d: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: d) Đối với một số ngành, nghề, công việc đặc thù thì thời hạn báo trước được thực hiện theo quy định của Chính phủ. [prov_bfc5906f1e003421]
- 18/VBHN-VPQH Điều 35 Khoản 2: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 2. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động không cần báo trước trong trường hợp sau đây: [prov_186d81901fe081bc]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Đây là kết quả hỗ trợ tra cứu; cần đối chiếu hồ sơ thực tế trước khi đưa ra kết luận pháp lý cuối cùng.

**Đáp án tham khảo (DRAFT):** Ít nhất 30 ngày, trừ trường hợp được quyền nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD003 — without_review — lần 1

Tôi có hợp đồng xác định thời hạn 9 tháng, đơn phương nghỉ bình thường. Phải báo trước tối thiểu mấy ngày?

Thời gian: 4666.944 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Ít nhất 3 ngày làm việc, trừ trường hợp được nghỉ không báo trước hoặc ngành nghề/công việc đặc thù.

## CD004 — without_review — lần 1

Công ty không trả lương đúng hạn mà không thuộc ngoại lệ bất khả kháng của khoản 4 Điều 97. Tôi có quyền nghỉ mà không báo trước không?

Thời gian: 20.73 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động được đơn phương chấm dứt hợp đồng không cần báo trước nếu không được trả đủ hoặc đúng hạn, trừ trường hợp ngoại lệ quy định ở khoản 4 Điều 97.

## CD005 — without_review — lần 1

Người lao động bị người sử dụng lao động đánh đập, nhục mạ thì có thể chấm dứt hợp đồng không cần báo trước không?

Thời gian: 33376.074 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm a: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: a) Ít nhất 45 ngày nếu làm việc theo hợp đồng lao động không xác định thời hạn; [prov_e091631d0168c360]
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm b: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: b) Ít nhất 30 ngày nếu làm việc theo hợp đồng lao động xác định thời hạn có thời hạn từ 12 tháng đến 36 tháng; [prov_c75b6504b5c1069f]
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm c: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: c) Ít nhất 03 ngày làm việc nếu làm việc theo hợp đồng lao động xác định thời hạn có thời hạn dưới 12 tháng; [prov_85a2c41c4237c73d]
- 18/VBHN-VPQH Điều 35 Khoản 1 Điểm d: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 1. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động nhưng phải báo trước cho người sử dụng lao động như sau: d) Đối với một số ngành, nghề, công việc đặc thù thì thời hạn báo trước được thực hiện theo quy định của Chính phủ. [prov_bfc5906f1e003421]
- 18/VBHN-VPQH Điều 35 Khoản 2: Điều 35. Quyền đơn phương chấm dứt hợp đồng lao động của người lao động 2. Người lao động có quyền đơn phương chấm dứt hợp đồng lao động không cần báo trước trong trường hợp sau đây: [prov_186d81901fe081bc]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.
Đây là kết quả hỗ trợ tra cứu; cần đối chiếu hồ sơ thực tế trước khi đưa ra kết luận pháp lý cuối cùng.

**Đáp án tham khảo (DRAFT):** Có. Đây là trường hợp người lao động được đơn phương chấm dứt hợp đồng mà không cần báo trước.

## CD006 — without_review — lần 1

Công ty không bố trí đúng công việc đã thỏa thuận và không thuộc trường hợp điều chuyển hợp pháp ở Điều 29. Người lao động có được nghỉ không cần báo trước không?

Thời gian: 20.523 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Người lao động có quyền đơn phương chấm dứt không cần báo trước nếu không được bố trí đúng công việc, địa điểm hoặc điều kiện đã thỏa thuận, trừ ngoại lệ Điều 29.

## CD007 — without_review — lần 1

Doanh nghiệp có thể đơn phương cho thôi việc do nhân viên thường xuyên không hoàn thành công việc theo tiêu chí đánh giá hợp lệ không?

Thời gian: 4627.452 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể, nếu thật sự thường xuyên không hoàn thành công việc theo tiêu chí quy chế đánh giá hợp lệ, bảo đảm nghĩa vụ tham khảo ý kiến khi áp dụng và thời hạn báo trước tương ứng.

## CD008 — without_review — lần 1

Người lao động tự ý bỏ việc không lý do chính đáng trong 5 ngày làm việc liên tục. Công ty có cần báo trước khi đơn phương chấm dứt không?

Thời gian: 4661.541 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Không. Đây là trường hợp người sử dụng lao động có thể đơn phương chấm dứt không cần báo trước theo Điều 36.

## CD009 — without_review — lần 1

Người lao động nữ đang mang thai, công ty có được đơn phương chấm dứt hợp đồng chỉ vì lý do mang thai không?

Thời gian: 32.134 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Bộ luật Lao động có quy định bảo vệ người lao động nữ mang thai, không cho người sử dụng lao động thực hiện quyền đơn phương chấm dứt trong trường hợp này.

## CD010 — without_review — lần 1

Người lao động đang nghỉ phép năm đã được công ty chấp thuận, công ty có được đơn phương chấm dứt hợp đồng trong thời gian nghỉ đó không?

Thời gian: 21.316 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Không. Người sử dụng lao động không được thực hiện quyền đơn phương chấm dứt khi người lao động đang nghỉ hằng năm, nghỉ việc riêng hoặc nghỉ khác được chấp thuận.

## CD011 — without_review — lần 1

Người lao động tự ý đơn phương nghỉ việc trái luật và không báo trước. Người đó có thể phải bồi thường nửa tháng lương cộng phần tiền của ngày không báo trước không?

Thời gian: 20.022 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Trường hợp đơn phương chấm dứt trái pháp luật, người lao động phải bồi thường nửa tháng tiền lương theo hợp đồng và khoản tương ứng các ngày không báo trước.

## CD012 — without_review — lần 1

Công ty đơn phương chấm dứt hợp đồng trái pháp luật và người lao động muốn quay lại làm việc. Công ty có nghĩa vụ bồi thường ít nhất hai tháng tiền lương không?

Thời gian: 28.412 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Có. Theo khoản 1 Điều 41, công ty phải nhận lại người lao động, thanh toán quyền lợi liên quan trong thời gian không làm việc và trả thêm ít nhất hai tháng lương hợp đồng.

## CD013 — without_review — lần 1

Sau khi chấm dứt hợp đồng thông thường, thời hạn thanh toán các khoản quyền lợi liên quan là bao nhiêu ngày làm việc?

Thời gian: 4669.629 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Thông thường hai bên phải thanh toán đầy đủ trong 14 ngày làm việc kể từ ngày chấm dứt hợp đồng.

## CD014 — without_review — lần 1

Trong trường hợp thuộc ngoại lệ luật định khi doanh nghiệp giải thể, thời hạn thanh toán quyền lợi khi chấm dứt hợp đồng có thể kéo dài tối đa bao nhiêu ngày?

Thời gian: 4658.129 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Có thể kéo dài nhưng không quá 30 ngày nếu đúng trường hợp ngoại lệ thuộc Điều 48 khoản 1.

## CD015 — without_review — lần 1

Người lao động làm việc thường xuyên 8 tháng rồi chấm dứt hợp đồng: có đương nhiên đủ điều kiện thời gian để nhận trợ cấp thôi việc theo Điều 46 không?

Thời gian: 677.339 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Chưa. Điều 46 đặt điều kiện đã làm việc thường xuyên từ đủ 12 tháng trở lên và phải thuộc trường hợp chấm dứt quy định, có các trường hợp loại trừ.

## TD001 — without_review — lần 1

Tôi muốn nghỉ việc, tôi phải báo trước cho công ty bao nhiêu ngày?

Thời gian: 13620.025 ms. Trạng thái: PARTIAL_ALLOWED.

Kết quả tra cứu dựa trên các căn cứ sau:
- Theo Điều 35, người lao động làm việc theo hợp đồng lao động không xác định thời hạn phải báo trước ít nhất 45 ngày nếu muốn nghỉ việc. [prov_e091631d0168c360]
- Người lao động làm việc theo hợp đồng lao động xác định thời hạn có thời hạn từ 12 tháng đến 36 tháng phải báo trước ít nhất 30 ngày nếu muốn nghỉ việc. [prov_c75b6504b5c1069f]
- Người lao động làm việc theo hợp đồng lao động xác định thời hạn có thời hạn dưới 12 tháng phải báo trước ít nhất 03 ngày làm việc nếu muốn nghỉ việc. [prov_85a2c41c4237c73d]
- Trong một số ngành, nghề, công việc đặc thù, thời hạn báo trước được thực hiện theo quy định của Chính phủ. [prov_bfc5906f1e003421]
- Người lao động có quyền đơn phương chấm dứt hợp đồng lao động không cần báo trước trong một số trường hợp cụ thể. [prov_186d81901fe081bc]
Kết quả chỉ là một phần vì còn thiếu bằng chứng bắt buộc được nêu trong limitations.

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, thời hạn hợp đồng, ngành nghề đặc thù và lý do nghỉ để xác định thời hạn báo trước hoặc quyền nghỉ không báo trước.

## TD002 — without_review — lần 1

Tôi được tuyển vào công ty, công ty có thể thử việc tôi tối đa bao lâu?

Thời gian: 708.393 ms. Trạng thái: PARTIAL_ALLOWED.

Thời gian thử việc tối đa theo từng nhóm công việc được quy định như sau. Chỉ mức 06 ngày được tính theo ngày làm việc; các mức còn lại là ngày:
- Điều 25 khoản 1 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 1. Không quá 180 ngày đối với công việc của người quản lý doanh nghiệp theo quy định của Luật Doanh nghiệp, Luật Quản lý, sử dụng vốn nhà nước đầu tư vào sản xuất, kinh doanh tại doanh nghiệp;” [prov_d3c76fc9dfd1296a]
- Điều 25 khoản 2 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 2. Không quá 60 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật từ cao đẳng trở lên;” [prov_900510b9768da439]
- Điều 25 khoản 3 (18/VBHN-VPQH): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhưng chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 3. Không quá 30 ngày đối với công việc có chức danh nghề nghiệp cần trình độ chuyên môn, kỹ thuật trung cấp, công nhân kỹ thuật, nhân viên nghiệp vụ;” [prov_82b3c0a297633594]
- Điều 25 khoản 4 (45/2019/QH14): “Điều 25. Thời gian thử việc Thời gian thử việc do hai bên thỏa thuận căn cứ vào tính chất và mức độ phức tạp của công việc nhung chỉ được thử việc một lần đối với một công việc và bảo đảm điều kiện sau đây: 4. Không quá 06 ngày làm việc đối với công việc khác.” [prov_0048079adf411ec2]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Cần biết chức danh và trình độ chuyên môn kỹ thuật thực sự cần cho công việc; các nhóm có giới hạn thử việc khác nhau.

## TD003 — without_review — lần 1

Công ty trả tôi lương 6 triệu đồng một tháng, như vậy có thấp hơn mức lương tối thiểu không?

Thời gian: 4675.335 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết địa bàn vùng lương tối thiểu, kỳ áp dụng và cách trả lương; chỉ với số 6 triệu đồng chưa đủ để kết luận.

## TD004 — without_review — lần 1

Tôi đang làm tại một doanh nghiệp, năm nay tôi được nghỉ bao nhiêu ngày phép năm?

Thời gian: 1065.584 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Câu trả lời còn thiếu nội dung pháp lý bắt buộc của câu hỏi. Cần bổ sung chuỗi căn cứ trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết thời gian làm việc, nhóm điều kiện công việc và thâm niên để tính số ngày nghỉ hằng năm.

## TD005 — without_review — lần 1

Sếp yêu cầu tăng ca nhưng tôi chưa rõ số giờ. Như vậy có vi phạm giới hạn làm thêm giờ không?

Thời gian: 517.077 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Không đủ bằng chứng đã xác minh để kết luận.

**Đáp án tham khảo (DRAFT):** Cần biết giờ làm bình thường, số giờ làm thêm trong ngày/tháng/năm, sự đồng ý và có thuộc ngoại lệ hay không.

## TD006 — without_review — lần 1

Tôi tự ý nghỉ việc, công ty yêu cầu bồi thường. Tôi có phải bồi thường không?

Thời gian: 10741.597 ms. Trạng thái: PARTIAL_ALLOWED.

Kết quả tra cứu dựa trên các căn cứ sau:
- Theo Điều 39 của Bộ luật Lao động, việc bạn tự ý nghỉ việc mà không có lý do hợp pháp được coi là đơn phương chấm dứt hợp đồng lao động trái pháp luật. [prov_3b1d15590711065e]
- Theo Điều 40, khoản 1, bạn không được hưởng trợ cấp thôi việc. [prov_9af862b61486f6a1]
- Theo Điều 40, khoản 2, bạn phải bồi thường cho công ty nửa tháng tiền lương theo hợp đồng lao động và một khoản tiền tương ứng với tiền lương trong những ngày không báo trước. [prov_ef06e74f0e045edb]
- Theo Điều 40, khoản 3, bạn phải hoàn trả cho công ty chi phí đào tạo quy định tại Điều 62 của Bộ luật Lao động. [prov_d198a164e4e1cf1b]
Kết quả chỉ là một phần vì còn thiếu bằng chứng bắt buộc được nêu trong limitations.

**Đáp án tham khảo (DRAFT):** Cần biết loại hợp đồng, lý do nghỉ, thời hạn báo trước và tình tiết được nghỉ không cần báo trước để xác định có nghỉ trái luật hay không.

## TD007 — without_review — lần 1

Sau khi nghỉ việc tôi có được nhận trợ cấp thôi việc hay không?

Thời gian: 16.706 ms. Trạng thái: NEED_MORE_FACTS.

Cần bổ sung dữ kiện trước khi tra cứu chuyên sâu.

**Đáp án tham khảo (DRAFT):** Cần biết cách chấm dứt hợp đồng, thời gian làm việc, thời gian đóng bảo hiểm thất nghiệp và các khoản trợ cấp đã nhận.

## TD008 — without_review — lần 1

Công ty điều chuyển tôi sang công việc khác 40 ngày. Như vậy có hợp pháp không?

Thời gian: 4677.168 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần làm rõ lý do điều chuyển, số ngày chuyển cộng dồn trong năm, thông báo trước và chế độ lương khi chuyển.

## TD009 — without_review — lần 1

Ngày nghỉ lễ tôi được hưởng khoản tiền làm thêm như thế nào?

Thời gian: 4672.439 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết bạn có thực tế làm việc vào ngày lễ không, có làm thêm giờ hay không và hình thức trả lương để áp dụng đúng mức.

## TD010 — without_review — lần 1

Tôi tăng ca vào thứ Bảy thì có được trả ít nhất 200% không?

Thời gian: 4644.081 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thứ Bảy có phải ngày nghỉ hằng tuần theo nội quy/lịch của bạn hay là ngày làm việc bình thường.

## TD011 — without_review — lần 1

Lương thử việc của tôi là 6 triệu đồng mỗi tháng, có hợp pháp không?

Thời gian: 857.332 ms. Trạng thái: PARTIAL_ALLOWED.

Các quy định liên quan tìm được:
- Điều 26: tiền lương trong thời gian thử việc do hai bên thỏa thuận nhưng ít nhất phải bằng 85% mức lương của công việc đó. [prov_38ac614a6bf6bd16]
Kết quả còn giới hạn vì một số bằng chứng bắt buộc chưa đầy đủ.

**Đáp án tham khảo (DRAFT):** Cần biết mức lương của chính công việc đó khi làm chính thức; lương thử việc phải từ 85% mức ấy trở lên.

## TD012 — without_review — lần 1

Công ty và tôi chỉ thỏa thuận miệng để làm việc; hợp đồng như vậy hợp lệ không?

Thời gian: 4685.32 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Cần biết thời hạn hợp đồng và liệu công việc có thuộc trường hợp bắt buộc phải lập văn bản hay không.

## TD013 — without_review — lần 1

Vào ngày 01/01/2028, mức lương tối thiểu vùng I chính xác là bao nhiêu?

Thời gian: 4631.437 ms. Trạng thái: ERROR.

ProviderRateLimited

**Đáp án tham khảo (DRAFT):** Chưa thể khẳng định mức cụ thể cho ngày 01/01/2028 từ bộ dữ liệu được chốt năm 2026. Cần văn bản quy định mức lương tối thiểu có hiệu lực tại thời điểm tương lai này.

## TD014 — without_review — lần 1

Năm 2028 lịch nghỉ Tết Âm lịch chính thức theo quyết định của Thủ tướng sẽ rơi vào những ngày dương lịch nào?

Thời gian: 34221.542 ms. Trạng thái: INSUFFICIENT_EVIDENCE.

Nội dung nguồn có lỗi đọc chữ đáng ngờ. Cần đối chiếu bản gốc trước khi kết luận.

**Đáp án tham khảo (DRAFT):** Không đủ căn cứ để nêu lịch nghỉ cụ thể của năm 2028 từ bộ dữ liệu đang chốt năm 2026; lịch thực hiện phải đối chiếu quyết định chính thức áp dụng cho năm đó.

## TD015 — without_review — lần 1

Năm 2029 Chính phủ sẽ nâng số giờ làm thêm tối đa thông thường lên mức nào, nếu có thay đổi luật?

Thời gian: 1033.525 ms. Trạng thái: PARTIAL_ALLOWED.

Giới hạn làm thêm giờ gồm điều kiện đồng ý, giới hạn theo ngày/tháng/năm và điều kiện áp dụng mức đến 300 giờ/năm. Đây là quy tắc trong phiên bản dữ liệu được tra cứu:
- Điều 107 khoản 2 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: a) Phải được sự đồng ý của người lao động;” [prov_2315c425c1eaa518]
- Điều 107 khoản 2 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: b) Bảo đảm số giờ làm thêm của người lao động không quá 50% số giờ làm việc bình thường trong 01 ngày; trường hợp áp dụng quy định thời giờ làm việc bình thường theo tuần thì tổng số giờ làm việc bình thường và số giờ làm thêm không quá 12 giờ trong 01 ngày; không quá 40 giờ trong 01 tháng;” [prov_4ae9d3f661c91bf1]
- Điều 107 khoản 2 điểm c (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 2. Người sử dụng lao động được sử dụng người lao động làm thêm giờ khi đáp ứng đầy đủ các yêu cầu sau đây: c) Bảo đảm số giờ làm thêm của người lao động không quá 200 giờ trong 01 năm, trừ trường hợp quy định tại khoản 3 Điều này.” [prov_7ebbd1a871c548bc]
- Điều 107 khoản 3 (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây:” [prov_ea4944bd15922c19]
- Điều 107 khoản 3 điểm a (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: a) Sản xuất, gia công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông, lâm, diêm nghiệp, thủy sản;” [prov_26921bbfe43debe0]
- Điều 107 khoản 3 điểm b (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: b) Sản xuất, cung cấp điện, viễn thông, lọc dầu; cấp, thoát nước;” [prov_0328018d8169ca6e]
- Điều 107 khoản 3 điểm c (45/2019/QH14): “Điều 107. Làm thêm giờ 3. Nguời sử dụng lao động được sử dụng nguời lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc truờng hợp sau đây: công xuất khẩu sản phẩm hàng dệt, may, da, giày, điện, điện tử, chế biến nông; lâm; diêm nghiệp, thủy sản; c) Trường hợp giải quyết công việc đòi hỏi lao động có trình độ chuyên môn, kỹ thuật cao mà thị trường lao động không cung ứng đầy đủ, kịp thời;” [prov_07018d0a70f8d54b]
- Điều 107 khoản 3 điểm d (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: d) Trường hợp phải giải quyết công việc cấp bách, không thể trì hoãn do tính chất thời vụ, thời điểm của nguyên liệu, sản phẩm hoặc để giải quyết công việc phát sinh do yếu tố khách quan không dự liệu trước, do hậu quả thời tiết, thiên tai, hỏa hoạn, địch họa, thiếu điện, thiếu nguyên liệu, sự cố kỹ thuật của dây chuyền sản xuất;” [prov_99f19670e4f6b29c]
- Điều 107 khoản 3 điểm đ (18/VBHN-VPQH): “Điều 107. Làm thêm giờ 3. Người sử dụng lao động được sử dụng người lao động làm thêm không quá 300 giờ trong 01 năm trong một số ngành, nghề, công việc hoặc trường hợp sau đây: đ) Trường hợp khác do Chính phủ quy định.” [prov_ef37b4b2ec39c720]
Metadata nguồn hoặc hiệu lực điều khoản còn chờ duyệt; kết quả hỗ trợ tra cứu theo bộ dữ liệu hiện có.

**Đáp án tham khảo (DRAFT):** Không có căn cứ pháp lý đã ban hành và được xác minh về một sửa đổi giả định năm 2029; không thể đưa ra con số chính xác chỉ dựa vào dự báo.
