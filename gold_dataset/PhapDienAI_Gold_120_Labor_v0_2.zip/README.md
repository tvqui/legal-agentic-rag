# Gold ứng viên v0.2

Chỉ đo trên snapshot 15/09/2026 của result_28-10. Không giải nén vào corpus.
Các nhãn/đáp án chỉ dùng để chấm sau khi hỏi, không đưa vào prompt hoặc retrieval.
Bản 100 có 88 câu có căn cứ để trả lời và 12 câu cần hỏi thêm; bản 120 bổ sung 20 câu.
Tên member labor_gold_100.jsonl được giữ vì tương thích reader; size trong manifest là số câu thật.
Ba câu tương lai gốc giữ trong file NOT_IN_MAIN_SCORE, không dùng làm qrels dương tính.
Không phải Gold được chuyên gia duyệt, không phải hold-out, không chứng minh model luôn trả lời được.
